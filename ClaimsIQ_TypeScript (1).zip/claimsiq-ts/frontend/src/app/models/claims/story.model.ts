export type StoryCategory = 'High Priority' | 'Cost Driver' | 'Opportunity' | 'Demographics' | 'Premium' | 'Utilization';
export type StoryCatClass = 'cat-hp' | 'cat-cd' | 'cat-op' | 'cat-dm' | 'cat-pl' | 'cat-ut';

export interface Story {
  id: string;
  icon: string;
  label: string;
  desc?: string;
  cat?: StoryCategory;
  catCls?: StoryCatClass;
  premium: boolean;
  avatars?: number;
}

export interface Narrative {
  headline?: string;
  insight?: string;
  so_what?: string;
  talking_points?: string[];
  metrics?: AiMetric[];
}

export interface AiMetric {
  label: string;
  value: string;
  delta?: string;
  dir?: 'bad' | 'good' | 'neutral';
  bench?: string;
  benchLabel?: string;
}

export interface AiAnalysis {
  headline?: string;
  insight?: string;
  so_what?: string;
  talking_points?: string[];
  ai_metrics?: AiMetric[];
  fromCache?: boolean;
}
