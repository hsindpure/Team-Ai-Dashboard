// ── ClaimsIQ Client Models ────────────────────────────────────

export interface RiskColor {
  bg: string;
  border: string;
  badge: string;
  label: 'High' | 'Medium' | 'Low';
  glow: string;
}

export interface DiagnosisEntry {
  name: string;
  count: number;
  pct: number;
  cost?: number;
}

export interface Analytics {
  totalApproved: number;
  totalBilled?: number;
  totalClaims: number;
  totalMembers?: number;
  pmpm: number;
  pmpy: number;
  avgAge: number;
  trendPct: number;
  chronicPct?: number;
  femalePct?: number;
  dependentRatio?: number;
  claimsPerMember?: number;
  highCostMembers?: number;
  highCostPct?: number;
  topMemberCost?: number;
  mbl?: number;
  billedApprovedRatio?: number;
  top5Diagnoses: DiagnosisEntry[];
  monthlyChart: { labels: string[]; pmpm: number[]; count: number[] };
  diagnosisChart?: { labels: string[]; costs: number[]; counts: number[] };
  quarterChart?: { labels: string[]; costs: number[]; counts: number[] };
  claimTypeCosts: Record<string, number>;
  claimTypeCounts?: Record<string, number>;
  illnessCostMap?: Record<string, number>;
  ageGroups?: Record<string, number>;
  genderCounts?: Record<string, number>;
  facilityTypeCounts?: Record<string, number>;
  memberCostBands?: Record<string, number>;
  planLevelPmpm?: Record<string, number>;
  planLevelCounts?: Record<string, number>;
  costByPolicyYear?: Record<string, number>;
}

export interface Client {
  id: string;
  name: string;
  members: number;
  pmpy: number;
  pmpm?: number;
  trendPct: number;
  chronicPct: number;
  riskScore: number;
  totalCost: number;
  totalClaims?: number;
  industry: string;
  country: string;
  currency: string;
  meetingDate?: string;
  manager?: string;
  renewalDate?: string;
  renewalOverdue?: boolean;
  planType?: string;
  analytics?: Analytics;
  [key: string]: unknown;
}
