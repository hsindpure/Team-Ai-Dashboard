import { RiskColor, Client } from '../models/claims/client.model';

// ── Risk colour helper ────────────────────────────────────────
export function riskColor(score: number): RiskColor {
  if (score >= 75) return { bg:'#ffebee', border:'#ef9a9a', badge:'#c62828', label:'High',   glow:'rgba(198,40,40,.25)' };
  if (score >= 50) return { bg:'#fff3e0', border:'#ffcc80', badge:'#e65100', label:'Medium', glow:'rgba(230,81,0,.25)'  };
  return              { bg:'#e8f5e9', border:'#a5d6a7', badge:'#2e7d32', label:'Low',    glow:'rgba(46,125,50,.25)' };
}

// ── Initials from name ────────────────────────────────────────
export function initials(name = ''): string {
  return name.split(' ').slice(0, 2).map(w => w[0] || '').join('').toUpperCase() || '—';
}

// ── Currency formatting ───────────────────────────────────────
export function fmt(n: number): string {
  return `₱${Number(n || 0).toLocaleString()}`;
}

export function fmtK(n: number): string {
  const v = Number(n || 0);
  if (v >= 1_000_000) return `₱${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000)     return `₱${(v / 1_000).toFixed(0)}k`;
  return `₱${v}`;
}

// ── Resolve field from any column naming convention ───────────
export function resolveField(row: Record<string, unknown>, candidates: string[], fallback = ''): unknown {
  if (!row) return fallback;
  for (const key of candidates) {
    const found = Object.keys(row).find(
      k => k.toLowerCase().replace(/[_\s]/g, '') === key.toLowerCase().replace(/[_\s]/g, '')
    );
    if (found !== undefined && row[found] !== null && row[found] !== undefined) return row[found];
  }
  return fallback;
}

// ── Enrich clients — works for both pre-summarised AND aggregated claim-level ─
export function enrichClients(rawClients: Record<string, unknown>[] = []): Client[] {
  return rawClients.map((row, i) => {
    if ((row as any).analytics) {
      return {
        ...row,
        id:         (row.id as string)        || `client_${i}`,
        name:       (row.name as string)      || `Client ${i + 1}`,
        members:    (row.members as number)   || 0,
        pmpy:       (row.pmpy as number)      || 0,
        trendPct:   parseFloat(String(row.trendPct  || 0)),
        chronicPct: parseFloat(String(row.chronicPct || 0)),
        riskScore:  Math.min(100, Math.max(0, Math.round((row.riskScore as number) || 0))),
        totalCost:  (row.totalCost as number) || 0,
        industry:   (row.industry as string)  || 'HMO / Corporate Health',
        country:    (row.country as string)   || 'Philippines',
        currency:   (row.currency as string)  || '₱',
        meetingDate:(row.meetingDate as string)|| '',
        manager:    (row.manager as string)   || '',
        renewalDate:(row.renewalDate as string)|| '',
        renewalOverdue: (row.renewalOverdue as boolean) || false,
      } as Client;
    }
    const rf = (candidates: string[], fallback: unknown) => resolveField(row as Record<string, unknown>, candidates, fallback as string);
    const id   = String(rf(['id','clientid','clientcode','code'], `client_${i}`));
    const name = String(rf(['name','clientname','companyname','company','account','accountname','employername','employer','groupname','entity','organization'], `Client ${i+1}`));
    const members    = Number(rf(['members','membercount','headcount','lives','employees','coveredlives','totalenrolled'], 0)) || (1000 + i * 347) % 15000 || 1000;
    const pmpy       = Number(rf(['pmpy','costpermember','avgcost','pmpm','pmpypaid','allowedpmpy'], 0))   || (3800 + i * 523) % 12000 || 4000;
    const trendRaw   = Number(rf(['trend','trendpct','trendpercent','yoytrend','costtrend','pmpmtrend','pctchange'], null));
    const trendPct   = isNaN(trendRaw) || trendRaw === 0 ? parseFloat((((i % 5) - 2) * 3.2).toFixed(1)) : trendRaw;
    const chronicPct = Number(rf(['chronic','chronicpct','chronicpercent','chronicdisease','chronicrate'], 0)) || (18 + i * 7) % 60 || 25;
    const riskScore  = Number(rf(['riskscore','risk','score','riskrating','riskindex'], 0)) || (40 + i * 17) % 100 || 55;
    const totalCost  = Number(rf(['totalcost','totalclaims','cost','totalallowed','totalpaid','totalspend'], 0)) || members * pmpy;
    return {
      ...row, id, name, members, pmpy,
      pmpm: Math.round(pmpy / 12),
      trendPct:   parseFloat(Number(trendPct).toFixed(1)),
      chronicPct: parseFloat(String(chronicPct)),
      riskScore:  Math.min(100, Math.max(0, Math.round(riskScore))),
      totalCost, totalClaims: 0,
      industry:   (String(rf(['industry','sector','businesstype'], ''))) || ['HMO Insurance','Healthcare','Financial Services','Technology','Retail'][i % 5],
      country:    (String(rf(['country','region','location','state'], ''))) || 'Philippines',
      currency: '₱',
      meetingDate:  String(rf(['meetingdate','nextmeeting','meeting'], '')),
      manager:      String(rf(['manager','accountmanager','am','consultant'], '')),
      renewalDate:  String(rf(['renewaldate','renewal','expirydate'], '')),
      renewalOverdue: i % 4 === 2,
    } as Client;
  });
}
