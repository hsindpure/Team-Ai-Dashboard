export const fmt  = (n: number | undefined | null): string =>
  `₱${Number(n ?? 0).toLocaleString()}`;

export const fmtK = (n: number | undefined | null): string => {
  const v = Number(n ?? 0);
  if (v >= 1_000_000) return `₱${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000)     return `₱${(v / 1_000).toFixed(0)}k`;
  return `₱${v}`;
};

export const resolveField = (
  row: Record<string, unknown>,
  candidates: string[],
  fallback: unknown = ''
): unknown => {
  if (!row) return fallback;
  for (const key of candidates) {
    const found = Object.keys(row).find(
      (k) => k.toLowerCase().replace(/[_\s]/g, '') === key.toLowerCase().replace(/[_\s]/g, '')
    );
    if (found !== undefined && row[found] !== null && row[found] !== undefined) return row[found];
  }
  return fallback;
};
