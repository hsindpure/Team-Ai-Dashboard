import type { RiskColor } from '../models/claims/client.model';

export function riskColor(score: number): RiskColor {
  if (score >= 75) return { bg: '#ffebee', border: '#ef9a9a', badge: '#c62828', label: 'High',   glow: 'rgba(198,40,40,.25)' };
  if (score >= 50) return { bg: '#fff3e0', border: '#ffcc80', badge: '#e65100', label: 'Medium', glow: 'rgba(230,81,0,.25)' };
  return                  { bg: '#e8f5e9', border: '#a5d6a7', badge: '#2e7d32', label: 'Low',    glow: 'rgba(46,125,50,.25)' };
}
