import { useState, useMemo, useEffect, useCallback, type FC } from 'react';
import { fetchAll, reloadData } from './services/claims.service';
import { enrichClients } from './utils/enrich-clients.util';
import LandingPage  from './components/landing-page/landing-page';
import ClientBrief  from './components/client-brief/client-brief';
import AnalysisView from './components/analysis-view/analysis-view';
import type { AppData, DataSource } from './models/claims/api.model';
import type { Client } from './models/claims/client.model';

type ViewType = 'landing' | 'brief' | 'analysis';

const LoadingScreen: FC = () => (
  <div className="loading-screen">
    <div className="loading-logo">C</div>
    <p className="loading-text">Loading Marsh Claims Analytics…</p>
    <div className="loading-bar"><div className="loading-bar-fill" /></div>
  </div>
);

const ErrorScreen: FC<{ error: string; onRetry: () => void }> = ({ error, onRetry }) => (
  <div className="loading-screen">
    <div style={{ fontSize: 44 }}>⚠️</div>
    <p style={{ fontSize: 20, fontWeight: 800, color: 'var(--ink)' }}>Could not load data</p>
    <p style={{ fontSize: 13, color: 'var(--red)', background: 'var(--red-lt)', padding: '8px 20px', borderRadius: 6 }}>{error}</p>
    <p style={{ fontSize: 12, color: 'var(--ink-muted)', maxWidth: 400, textAlign: 'center', lineHeight: 1.7 }}>
      Ensure the backend is running on port 3001 and an xlsx file exists at <code>backend/dataFile/</code>
    </p>
    <button className="btn-primary" onClick={onRetry}>↺ Retry</button>
  </div>
);

const App: FC = () => {
  const [view,              setView]              = useState<ViewType>('landing');
  const [selectedClientId,  setSelectedClientId]  = useState<string | null>(null);
  const [selectedStoryId,   setSelectedStoryId]   = useState<string | null>(null);
  const [appData,           setAppData]           = useState<AppData | null>(null);
  const [loading,           setLoading]           = useState(true);
  const [error,             setError]             = useState<string | null>(null);
  const [reloading,         setReloading]         = useState(false);
  const [dataSource,        setDataSource]        = useState<DataSource>('excel');

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await fetchAll();
      if (data.dataSource)       setDataSource(data.dataSource);
      else if (data.meta?.source) setDataSource(data.meta.source);
      setAppData(data);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetchData(); }, [fetchData]);

  const clients    = useMemo(() => enrichClients((appData?.clients ?? []) as Record<string, unknown>[]), [appData]);
  const stories    = appData?.stories    ?? [];
  const narratives = appData?.narratives ?? {};

  const client = useMemo(
    () => clients.find((c: Client) => c.id === selectedClientId) ?? null,
    [clients, selectedClientId]
  );

  const handleSelectClient = (id: string) => { setSelectedClientId(id); setSelectedStoryId(null); setView('brief'); };
  const handleSelectStory  = (storyId: string) => { setSelectedStoryId(storyId); setView('analysis'); };
  const handleReload = async () => {
    setReloading(true);
    try { await reloadData(); await fetchData(); }
    catch (e) { console.error('Reload failed:', e); }
    finally { setReloading(false); }
  };

  if (loading) return <LoadingScreen />;
  if (error)   return <ErrorScreen error={error} onRetry={fetchData} />;

  const navProps = {
    client, clients, reloading,
    onClientChange: (id: string) => { setSelectedClientId(id); setSelectedStoryId(null); setView('brief'); },
    onReload: handleReload,
    onLogoClick: () => setView('landing'),
  };

  if (view === 'landing') return <LandingPage clients={clients} onSelectClient={handleSelectClient} dataSource={dataSource} />;
  if (view === 'brief')   return <ClientBrief {...navProps} stories={stories} narratives={narratives} onSelectStory={handleSelectStory} />;
  if (view === 'analysis' && client && selectedStoryId) return <AnalysisView {...navProps} storyId={selectedStoryId} narratives={narratives} stories={stories} onBack={() => setView('brief')} />;
  if (view === 'analysis') return <ClientBrief {...navProps} stories={stories} narratives={narratives} onSelectStory={handleSelectStory} />;

  return <LandingPage clients={clients} onSelectClient={handleSelectClient} dataSource={dataSource} />;
};

export default App;
