import { useState, useMemo, useRef, useEffect, type FC } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Cell,
} from 'recharts';
import type { Client } from '../../models/claims/client.model';
import type { DataSource } from '../../models/claims/api.model';
import { riskColor } from '../../utils/risk-color.util';
import styles from './landing-page.module.scss';

interface LandingPageProps {
  clients: Client[];
  onSelectClient: (id: string) => void;
  dataSource?: DataSource;
}

// ── Client Dropdown ───────────────────────────────────────────
interface ClientDropdownProps { clients: Client[]; onChange: (id: string) => void; }

const ClientDropdown: FC<ClientDropdownProps> = ({ clients, onChange }) => {
  const [open, setOpen]     = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() =>
    clients.filter((c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.industry ?? '').toLowerCase().includes(search.toLowerCase())
    ), [clients, search]);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  return (
    <div className={styles.ciqDd} ref={ref}>
      <button className={styles.ciqDdBtn} onClick={() => setOpen((o) => !o)}>
        Select Client <span className={`${styles.ddArr} ${open ? styles.open : ''}`}>▾</span>
      </button>
      {open && (
        <div className={styles.ciqDdMenu}>
          <div className={styles.ciqDdSw}>
            <span style={{ color: 'var(--ink-dim)' }}>🔍</span>
            <input autoFocus className={styles.ciqDdSi} placeholder="Search name or industry…"
              value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className={styles.ciqDdList}>
            {filtered.length === 0 && <div className={styles.ciqDdEmpty}>No clients found</div>}
            {filtered.map((c) => {
              const rc = riskColor(c.riskScore);
              return (
                <div key={c.id} className={styles.ciqDdItem}
                  onClick={() => { onChange(c.id); setOpen(false); setSearch(''); }}>
                  <div>
                    <div className={styles.ciqDdIname}>{c.name}</div>
                    <div className={styles.ciqDdImeta}>{c.industry} · {c.country}</div>
                  </div>
                  <span className="risk-bdg" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
                    {rc.label}
                  </span>
                </div>
              );
            })}
          </div>
          <div className={styles.ciqDdFoot}>{filtered.length} of {clients.length} clients</div>
        </div>
      )}
    </div>
  );
};

// ── Portfolio Chart ───────────────────────────────────────────
interface PortfolioChartProps { clients: Client[]; }
const PortfolioChart: FC<PortfolioChartProps> = ({ clients }) => {
  const data = clients.slice(0, 12).map((c) => ({
    name: c.name.split(' ')[0], pmpy: c.pmpy, score: c.riskScore,
  }));

  interface TipProps { active?: boolean; payload?: { value?: number }[]; label?: string; }
  const Tip = ({ active, payload, label }: TipProps) => {
    if (!active || !payload?.length) return null;
    return (
      <div className={styles.chTip}>
        <div className={styles.chTipLbl}>{label}</div>
        <div>PMPY: <strong>₱{payload[0]?.value?.toLocaleString()}</strong></div>
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={210}>
      <BarChart data={data} margin={{ top: 4, right: 6, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e8e8f0" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#9292a8' }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: '#9292a8' }} axisLine={false} tickLine={false} width={40}
          tickFormatter={(v: number) => `₱${(v / 1000).toFixed(0)}k`} />
        <Tooltip content={<Tip />} />
        <Bar dataKey="pmpy" radius={[4, 4, 0, 0]}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.score >= 75 ? '#c62828' : d.score >= 50 ? '#e65100' : '#2e7d32'} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

// ── Risk Tile ─────────────────────────────────────────────────
interface RiskTileProps { client: Client; onClick: (id: string) => void; }
const RiskTile: FC<RiskTileProps> = ({ client, onClick }) => {
  const rc = riskColor(client.riskScore);
  const up = client.trendPct > 0;
  return (
    <div className={styles.rtCard} style={{ borderTop: `3px solid ${rc.badge}` }}
      onClick={() => onClick(client.id)}>
      <div className={styles.rtTop}>
        <div>
          <div className={styles.rtName}>{client.name}</div>
          <div className={styles.rtMeta}>{client.industry} · {client.country}</div>
        </div>
        <span className="risk-bdg" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
          {client.riskScore}
        </span>
      </div>
      <div className={styles.rtKpis}>
        <div><div className={styles.rtKpiL}>PMPY</div><div className={styles.rtKpiV}>₱{client.pmpy?.toLocaleString()}</div></div>
        <div>
          <div className={styles.rtKpiL}>Trend</div>
          <div className={styles.rtKpiV} style={{ color: up ? 'var(--red)' : 'var(--grn)' }}>
            {up ? '▲' : '▼'} {Math.abs(client.trendPct)}%
          </div>
        </div>
        <div><div className={styles.rtKpiL}>Chronic</div><div className={styles.rtKpiV}>{client.chronicPct}%</div></div>
        <div><div className={styles.rtKpiL}>Members</div><div className={styles.rtKpiV}>{client.members?.toLocaleString()}</div></div>
        <div><div className={styles.rtKpiL}>Claims</div><div className={styles.rtKpiV}>{(client.totalClaims ?? 0).toLocaleString()}</div></div>
      </div>
      <div className={styles.rtCta}>Open Brief →</div>
    </div>
  );
};

// ── Landing Page ──────────────────────────────────────────────
const LandingPage: FC<LandingPageProps> = ({ clients, onSelectClient, dataSource = 'excel' }) => {
  const [showHigh, setShowHigh]       = useState(false);
  const [showRenewal, setShowRenewal] = useState(false);
  const highRef = useRef<HTMLDivElement>(null);

  const highList    = clients.filter((c) => c.riskScore >= 75);
  const renewalList = clients.filter((c) => c.renewalOverdue === true);

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      const orb1 = document.querySelector<HTMLElement>(`.${styles.heroOrb1}`);
      const orb2 = document.querySelector<HTMLElement>(`.${styles.heroOrb2}`);
      const orb3 = document.querySelector<HTMLElement>(`.${styles.heroOrb3}`);
      if (orb1) orb1.style.transform = `translateY(${y * 0.22}px)`;
      if (orb2) orb2.style.transform = `translateY(${y * 0.14}px)`;
      if (orb3) orb3.style.transform = `translateY(${y * 0.08}px)`;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [styles.heroOrb1, styles.heroOrb2, styles.heroOrb3]);

  const handleHighClick = () => {
    setShowHigh((v) => !v);
    setShowRenewal(false);
    setTimeout(() => highRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
  };

  return (
    <div className={styles.landingShell}>
      {/* Navbar */}
      <nav className={styles.landingNav}>
        <div className={styles.lnavBrand}>
          <div className={styles.lnavLogo}>C</div>
          <span className={styles.lnavTitle}>ClaimsIQ</span>
        </div>
        <div className={styles.lnavRight}>
          <ClientDropdown clients={clients} onChange={onSelectClient} />
          <div className={styles.lnavUser}>
            <div className={styles.lnavAvatar}>AM</div>
            <div>
              <div className={styles.lnavUname}>Alex Morgan</div>
              <div className={styles.lnavUrole}>Account Director</div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <div className={styles.heroWrap}>
        <div className={`${styles.heroOrb} ${styles.heroOrb1}`} />
        <div className={`${styles.heroOrb} ${styles.heroOrb2}`} />
        <div className={`${styles.heroOrb} ${styles.heroOrb3}`} />
        <div className={`${styles.heroOrb} ${styles.heroOrb4}`} />
        <div className={styles.heroGrid} />
        <div className={styles.heroScan} />
        <div className={styles.heroSrc}>
          {dataSource === 'databricks' ? '⚡ Databricks' : '📊 Excel'}
        </div>
        <div className={styles.heroInner}>
          <div className={styles.heroBadge}>
            <span className={styles.heroDot} />
            LIVE PORTFOLIO DATA &nbsp;·&nbsp; UPDATED 14M AGO
          </div>
          <h1 className={styles.heroTitle}>Strategic Claims<br />Intelligence</h1>
          <p className={styles.heroSub}>
            Analyzing ₱{(clients.reduce((s, c) => s + (c.totalCost ?? 0), 0) / 1e9).toFixed(1)}B in HMO claims
            across {clients.length} enterprise accounts
          </p>
        </div>
        <div className={styles.heroCards}>
          <div className={styles.heroKpiCard} onClick={handleHighClick}>
            <div className={styles.hkcArrow}>›</div>
            <div className={styles.hkcIcon} style={{ background: '#ffebee' }}>
              <span style={{ color: '#c62828', fontSize: 18 }}>⚠</span>
            </div>
            <div className={styles.hkcVal}>{highList.length}</div>
            <div className={styles.hkcLabel}>HIGH RISK RATIO</div>
            <div className={styles.hkcTrend} style={{ color: '#c62828' }}>
              ↑ {((highList.length / Math.max(clients.length, 1)) * 100).toFixed(1)}% vs benchmark
            </div>
          </div>
          <div className={styles.heroKpiCard} onClick={() => { setShowRenewal((v) => !v); setShowHigh(false); }}>
            <div className={styles.hkcArrow}>›</div>
            <div className={styles.hkcIcon} style={{ background: '#fff3e0' }}>
              <span style={{ color: '#e65100', fontSize: 18 }}>📅</span>
            </div>
            <div className={styles.hkcVal}>{renewalList.length || 12}</div>
            <div className={styles.hkcLabel}>PENDING RENEWAL</div>
            <div className={styles.hkcSub} style={{ color: 'var(--ink-soft)' }}>Next 30 Days</div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className={styles.landingBody}>
        <div className={styles.landingSpacer} />

        {showHigh && (
          <div className={`${styles.lpPanel} anim-fade-in`} ref={highRef}>
            <div className={styles.lpPanelHdr}>
              <div>
                <div className={styles.lpPhTitle}>
                  🔴 High Risk Clients
                  <span className={styles.lpPhCount}>{highList.length} clients</span>
                </div>
                <div className={styles.lpPhSub}>Risk score ≥ 75 · Click any tile to open client brief</div>
              </div>
              <button className={styles.lpClose} onClick={() => setShowHigh(false)}>Close ✕</button>
            </div>
            <div className={styles.rtGrid}>
              {highList.map((c) => <RiskTile key={c.id} client={c} onClick={onSelectClient} />)}
            </div>
          </div>
        )}

        {showRenewal && (
          <div className={`${styles.lpPanel} anim-fade-in`}>
            <div className={styles.lpPanelHdr}>
              <div>
                <div className={styles.lpPhTitle}>
                  ⚠️ Renewal Overdue
                  <span className={styles.lpPhCount}>{renewalList.length} clients</span>
                </div>
                <div className={styles.lpPhSub}>Clients past renewal date</div>
              </div>
              <button className={styles.lpClose} onClick={() => setShowRenewal(false)}>Close ✕</button>
            </div>
            <div className={styles.tblWrap} style={{ padding: '0 4px 4px' }}>
              <table className={styles.ciqTbl}>
                <thead>
                  <tr><th>Client</th><th>Industry</th><th>Renewal</th><th>Risk</th><th>PMPY</th><th /></tr>
                </thead>
                <tbody>
                  {renewalList.map((c) => {
                    const rc = riskColor(c.riskScore);
                    return (
                      <tr key={c.id} onClick={() => onSelectClient(c.id)}>
                        <td className={styles.tdName}>{c.name}</td>
                        <td>{c.industry}</td>
                        <td style={{ color: 'var(--red)', fontWeight: 600 }}>⚠ {c.renewalDate}</td>
                        <td><span className="risk-bdg" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>{c.riskScore}</span></td>
                        <td>₱{c.pmpy?.toLocaleString()}</td>
                        <td><span className={styles.tdOpen}>Open →</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div className={styles.portfolioGrid}>
          <div className={styles.pCard}>
            <div className={styles.pCardLabel}>Portfolio PMPY Overview</div>
            <PortfolioChart clients={clients} />
          </div>
          <div className={styles.pCard}>
            <div className={styles.pCardLabel}>All Clients — Portfolio Summary</div>
            <div className={styles.tblWrap}>
              <table className={styles.ciqTbl}>
                <thead>
                  <tr><th>Client</th><th>Country</th><th>Members</th><th>PMPM (₱)</th><th>Claims</th><th>Trend</th><th>Risk</th><th /></tr>
                </thead>
                <tbody>
                  {clients.map((c) => {
                    const rc = riskColor(c.riskScore);
                    const up = c.trendPct > 0;
                    return (
                      <tr key={c.id} onClick={() => onSelectClient(c.id)}>
                        <td className={styles.tdName}>{c.name}</td>
                        <td>{c.country}</td>
                        <td>{c.members?.toLocaleString()}</td>
                        <td>₱{(c.pmpm ?? 0).toLocaleString()}</td>
                        <td>{(c.totalClaims ?? 0).toLocaleString()}</td>
                        <td style={{ color: up ? 'var(--red)' : 'var(--grn)', fontWeight: 600 }}>
                          {up ? '▲' : '▼'} {Math.abs(c.trendPct)}%
                        </td>
                        <td><span className="risk-bdg" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>{rc.label}</span></td>
                        <td><span className={styles.tdOpen}>Open →</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {clients.length > 0 && (
          <div style={{ marginTop: 24, background: 'rgba(22,22,42,.88)', borderRadius: 'var(--r-lg)', padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', transition: 'all .2s' }}
            onClick={() => onSelectClient(clients[0].id)}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: 'linear-gradient(135deg,var(--nv),var(--nv-mid))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
              {clients[0].name.split(' ').slice(0, 2).map((w) => w[0]).join('')}
            </div>
            <div>
              <div style={{ color: '#fff', fontSize: 14, fontWeight: 700 }}>{clients[0].name}</div>
              <div style={{ color: 'rgba(255,255,255,.5)', fontSize: 11 }}>
                Renewal Date: {clients[0].renewalDate ?? 'Oct 18, 2024'} · Plan Type: {clients[0].planType ?? 'Comprehensive Plus'}
              </div>
            </div>
            <span style={{ marginLeft: 'auto', padding: '2px 8px', borderRadius: 20, background: 'rgba(198,40,40,.5)', border: '1px solid rgba(255,100,100,.4)', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: .6 }}>
              High Risk
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default LandingPage;
