import type { FC } from 'react';
import type { Client } from '../../models/claims/client.model';
import type { Story, Narrative } from '../../models/claims/story.model';
import NavbarCiq from '../navbar-ciq/navbar-ciq';
import { fmt } from '../../utils/format.util';
import styles from './client-brief.module.scss';

const DEFAULT_STORIES: Story[] = [
  { id: 'cost_trend',      icon: '📈', label: 'Cost Trend',         desc: 'How costs moved vs prior year and benchmark',                premium: false },
  { id: 'top5_diagnosis',  icon: '🩺', label: 'Top 5 Diagnosis',    desc: 'Leading diagnosis categories driving claim spend',           premium: false },
  { id: 'high_cost',       icon: '🔴', label: 'High-Cost Claimants',desc: 'Top cost drivers and impact on total spend',                 premium: false },
  { id: 'census_analysis', icon: '📊', label: 'Census Analysis',    desc: 'Member demographics, age bands and dependency trends',      premium: false },
  { id: 'utilization',     icon: '🏥', label: 'Utilization Shifts', desc: 'ER, inpatient, and preventive care patterns',               premium: true  },
  { id: 'plan_perf',       icon: '⚖️', label: 'Plan Performance',   desc: 'HDHP vs PPO enrollment, OOP, and engagement',              premium: true  },
];

interface AnalyticsStripProps { client: Client; }
const AnalyticsStrip: FC<AnalyticsStripProps> = ({ client }) => {
  const a = client?.analytics;
  if (!a) return null;
  return (
    <div className={styles.cbStrip}>
      <div className={styles.cbKpi}><div className={styles.cbKl}>TOTAL CLAIMS</div><div className={styles.cbKv}>{(a.totalClaims ?? 0).toLocaleString()}</div></div>
      <div className={styles.cbKpi}><div className={styles.cbKl}>TOTAL APPROVED</div><div className={styles.cbKv}>{fmt(a.totalApproved)}</div></div>
      <div className={styles.cbKpi}><div className={styles.cbKl}>PMPM</div><div className={styles.cbKv}>{fmt(a.pmpm)}</div></div>
      <div className={styles.cbKpi}>
        <div className={styles.cbKl}>YoY TREND</div>
        <div className={`${styles.cbKv} ${a.trendPct > 0 ? styles.cbKvBad : styles.cbKvGood}`}>
          {a.trendPct > 0 ? '▲' : '▼'} {Math.abs(a.trendPct)}%
        </div>
      </div>
      <div className={styles.cbKpi}><div className={styles.cbKl}>AVG AGE</div><div className={styles.cbKv}>{a.avgAge} yrs</div></div>
      <div className={styles.cbKpi}><div className={styles.cbKl}>TOP DIAGNOSIS</div><div className={`${styles.cbKv} ${styles.cbKvDiag}`}>{a.top5Diagnoses?.[0]?.name ?? '—'}</div></div>
    </div>
  );
};

interface ClientBriefProps {
  client?: Client | null;
  clients?: Client[];
  stories?: Story[];
  narratives?: Record<string, Narrative>;
  reloading?: boolean;
  isPremium?: boolean;
  onSelectStory: (storyId: string) => void;
  onClientChange?: (id: string) => void;
  onReload?: () => void;
  onLogoClick?: () => void;
}

const ClientBrief: FC<ClientBriefProps> = ({
  client, clients, stories, narratives, reloading,
  isPremium = false, onSelectStory, onClientChange, onReload, onLogoClick,
}) => {
  if (!client) {
    return (
      <div className="loading-screen">
        <div style={{ fontSize: 44 }}>📋</div>
        <p style={{ fontSize: 18, fontWeight: 700, color: 'var(--ink)' }}>No client selected</p>
        <p style={{ color: 'var(--ink-muted)' }}>Select a client from the dropdown above</p>
      </div>
    );
  }

  const storyList = Array.isArray(stories) && stories.length > 0 ? stories : DEFAULT_STORIES;
  const initials  = client.name.split(' ').slice(0, 2).map((w) => w[0]).join('').toUpperCase();

  return (
    <div className="screen-shell">
      <NavbarCiq
        client={client} clients={clients} reloading={reloading}
        onClientChange={onClientChange} onReload={onReload} onLogoClick={onLogoClick}
      />

      {/* Hero band */}
      <div className={styles.briefHero}>
        <div className={styles.bhOrb} />
        <div className={styles.bhGrid} />
        <div className={styles.briefClientRow}>
          <div className={styles.bcAvatar}>{initials}</div>
          <div>
            <div className={styles.bcName}>{client.name}</div>
            <div className={styles.bcMeta}>
              {client.members?.toLocaleString()} members
              {client.industry ? ` · ${client.industry}` : ''}
              {client.country  ? ` · ${client.country}`  : ''}
            </div>
          </div>
        </div>
      </div>

      <AnalyticsStrip client={client} />

      <div className={styles.briefBody}>
        <div className={styles.headerRow}>
          <div className={styles.headerLeft}>
            <div className={styles.eyebrow}><span className={styles.eyebrowBar} />CLIENT BRIEF</div>
            <h1 className={styles.clientName}>{client.name}</h1>
            <p className={styles.clientMeta}>
              {client.members?.toLocaleString()} members
              {client.industry ? ` · ${client.industry}` : ''}
              {client.country  ? ` · ${client.country}`  : ''}
            </p>
          </div>
          {(client.meetingDate || client.manager) && (
            <div className={styles.meetingBadge}>
              <div className={styles.meetingLabel}>NEXT MEETING</div>
              {client.meetingDate && <div className={styles.meetingDate}>{client.meetingDate}</div>}
              {client.manager    && <div className={styles.meetingWith}>with {client.manager}</div>}
            </div>
          )}
        </div>

        <div className={styles.divider} />

        <div className={styles.storiesHead}>
          <span className={styles.sectionLabel}>CHOOSE A STORY TO BUILD</span>
          {!isPremium && <span className={styles.premiumNotice}>🔒 Some stories require a Premium plan</span>}
        </div>

        <div className={styles.storyGrid}>
          {storyList.map((t, idx) => {
            const isLocked    = t.premium && !isPremium;
            const hasXlsxData = !!narratives?.[t.id];
            return (
              <div
                key={t.id}
                className={`${styles.storyCard} ${isLocked ? styles.storyLocked : ''}`}
                style={{ animationDelay: `${idx * 0.04}s` }}
                onClick={() => !isLocked && onSelectStory(t.id)}
                title={isLocked ? 'Upgrade to Premium to unlock this story' : ''}
              >
                <div className={`${styles.cardTopbar} ${isLocked ? styles.cardTopbarLocked : styles.cardTopbarActive}`} />
                <div className={styles.iconRow}>
                  <span className={styles.storyIcon}>{t.icon ?? '📊'}</span>
                  {isLocked && <span className={styles.lockBadge}>🔒</span>}
                  {t.premium && isPremium && <span className={styles.premiumBadge}>PREMIUM</span>}
                </div>
                <div className={`${styles.storyTitle} ${isLocked ? styles.storyTitleLocked : ''}`}>{t.label}</div>
                <div className={styles.storyDesc}>{t.desc}</div>
                <div className={styles.storyFooter}>
                  {isLocked
                    ? <span className={styles.storyUpgrade}>Upgrade to unlock →</span>
                    : <span className={styles.storyCta}>{hasXlsxData ? 'Build →' : 'AI Brief →'}</span>}
                </div>
              </div>
            );
          })}
        </div>

        {storyList === DEFAULT_STORIES && Object.keys(narratives ?? {}).length === 0 && (
          <div style={{ marginTop: 32 }}>
            <div className={styles.sectionLabel}>CLIENT DATA FROM EXCEL</div>
            <div className={styles.rawDataCard}>
              <table className={styles.dataTable}>
                <thead><tr><th>Field</th><th>Value</th></tr></thead>
                <tbody>
                  {Object.entries(client)
                    .filter(([k]) => k !== 'id')
                    .map(([k, v]) => (
                      <tr key={k}>
                        <td style={{ fontWeight: 600, textTransform: 'capitalize', color: 'var(--navy)' }}>{k.replace(/_/g, ' ')}</td>
                        <td>{v !== null && v !== undefined ? String(v) : '—'}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientBrief;
