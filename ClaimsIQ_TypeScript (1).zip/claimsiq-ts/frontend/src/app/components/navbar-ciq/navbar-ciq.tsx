import type { FC } from 'react';
import type { Client } from '../../models/claims/client.model';
import styles from './navbar-ciq.module.scss';

interface NavbarCiqProps {
  client?: Client | null;
  clients?: Client[];
  reloading?: boolean;
  onClientChange?: (id: string) => void;
  onReload?: () => void;
  onLogoClick?: () => void;
}

const NavbarCiq: FC<NavbarCiqProps> = ({
  client, clients = [], reloading,
  onClientChange, onReload, onLogoClick,
}) => {
  const initials = client?.name
    ? client.name.split(' ').slice(0, 2).map((w) => w[0]).join('').toUpperCase()
    : '–';

  return (
    <nav className={styles.navbar}>
      <div className={styles.brand} onClick={onLogoClick}>
        <div className={styles.logo}>C</div>
        <span className={styles.brandName}>ClaimsIQ</span>
      </div>

      <div className={styles.navCompany}>
        <div className={styles.coIcon}>{initials.slice(0, 2)}</div>
        <select
          className={styles.navSel}
          value={client?.id ?? ''}
          onChange={(e) => onClientChange?.(e.target.value)}
        >
          {clients.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <span className={styles.coChev}>▾</span>
      </div>

      <div className={styles.navRight}>
        <button
          className={`${styles.reload} ${reloading ? styles.busy : ''}`}
          onClick={onReload}
          disabled={reloading}
        >
          <span className={reloading ? styles.spinIcon : ''}>⟳</span>
          {reloading ? ' Reloading…' : ' Reload'}
        </button>
        <div className={styles.user}>
          <div className={styles.avatar}>AM</div>
          <div>
            <div className={styles.userName}>Alex Morgan</div>
            <div className={styles.userRole}>Account Director</div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavbarCiq;
