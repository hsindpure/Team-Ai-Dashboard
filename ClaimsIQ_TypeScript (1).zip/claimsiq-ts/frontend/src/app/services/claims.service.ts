import type { AppData } from '../models/claims/api.model';
import type { AiAnalysis } from '../models/claims/story.model';

const BASE = (import.meta as { env?: Record<string, string> }).env?.VITE_API_URL ?? '/api';

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({})) as { error?: string; hint?: string };
    throw new Error(body.error ?? body.hint ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const fetchAll         = (): Promise<AppData>    => apiFetch<AppData>('/all');
export const fetchSource      = (): Promise<unknown>    => apiFetch('/source');
export const reloadData       = (): Promise<unknown>    => apiFetch('/reload',             { method: 'POST' });
export const reloadExcel      = (): Promise<unknown>    => apiFetch('/reload/excel',       { method: 'POST' });
export const reloadDatabricks = (): Promise<unknown>    => apiFetch('/reload/databricks',  { method: 'POST' });
export const testDatabricks   = (): Promise<unknown>    => apiFetch('/databricks/status');

export const fetchAiAnalysis = (
  clientId: string,
  storyId: string,
  forceRefresh = false
): Promise<AiAnalysis> =>
  apiFetch<{ analysis: AiAnalysis }>('/ai/analyze', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ clientId, storyId, forceRefresh }),
  }).then((r) => r.analysis);
