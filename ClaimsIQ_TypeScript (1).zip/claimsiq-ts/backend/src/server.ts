// @ts-nocheck
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { parseXlsx, getCache, clearCache, startWatcher } = require('./dataParser');
const { generateAiAnalysis, clearAiCache, getAiCacheStatus, deleteAiCacheEntry } = require('./aiAnalyzer');
const { loadDatabricksData, testDatabricksConnection, isDatabricksConfigured } = require('./databricksConnector');

const app       = express();
const PORT      = process.env.PORT        || 3001;
const XLSX_PATH = process.env.XLSX_FILE   || 'dataFile/claimsiq_data.xlsx';
const FORCE_DB  = process.env.FORCE_DATABRICKS === 'true';

let activeSource    = 'none';
let databricksCache = null;

app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'],
  credentials: true,
}));
app.use(express.json());

if (process.env.NODE_ENV !== 'production') {
  app.use((req, _res, next) => {
    console.log(`[${new Date().toTimeString().slice(0,8)}] ${req.method} ${req.url}`);
    next();
  });
}

function getActiveCache() {
  if (activeSource === 'databricks' && databricksCache) return databricksCache;
  return getCache();
}

function loadExcel() {
  const absPath = path.resolve(XLSX_PATH);
  if (!fs.existsSync(absPath)) return false;
  try {
    parseXlsx(XLSX_PATH);
    activeSource = 'excel';
    console.log(`[boot] [ok] Excel loaded: ${absPath}`);
    return true;
  } catch (e) {
    console.error('[boot] Excel parse failed:', e.message);
    return false;
  }
}

async function loadDatabricks() {
  if (!isDatabricksConfigured()) {
    console.warn('[boot] Databricks not configured -- skipping');
    return false;
  }
  try {
    databricksCache = await loadDatabricksData();
    activeSource = 'databricks';
    console.log(`[boot] [ok] Databricks loaded: ${databricksCache.meta.totalClients} clients`);
    return true;
  } catch (e) {
    console.error('[boot] Databricks load failed:', e.message);
    return false;
  }
}

// -- Routes: System --------------------------------------------
app.get('/api/health', (_req, res) => {
  res.json({ success: true, status: 'ok', time: new Date().toISOString(), dataSource: activeSource });
});

app.get('/api/source', (_req, res) => {
  let meta = {};
  try { meta = getActiveCache().meta || {}; } catch (e) {}
  res.json({
    success: true, activeSource,
    xlsxAvailable:        fs.existsSync(path.resolve(XLSX_PATH)),
    databricksConfigured: isDatabricksConfigured(),
    meta,
  });
});

app.get('/api/databricks/status', async (_req, res) => {
  const result = await testDatabricksConnection();
  res.json(result);
});

// -- Routes: Data ----------------------------------------------
app.get('/api/all', (_req, res) => {
  try {
    const { clients, stories, narratives, meta } = getActiveCache();
    res.json({ success: true, clients, stories, narratives, meta, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get('/api/clients', (_req, res) => {
  try {
    const { clients } = getActiveCache();
    res.json({ success: true, count: clients.length, data: clients, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get('/api/client/:id', (req, res) => {
  try {
    const { clients } = getActiveCache();
    const client = clients.find(c => String(c.id).toLowerCase() === req.params.id.toLowerCase());
    if (!client) return res.status(404).json({ success: false, error: `Client "${req.params.id}" not found.` });
    res.json({ success: true, data: client, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get('/api/sheets', (_req, res) => {
  try {
    const { sheets } = getActiveCache();
    res.json({
      success: true, dataSource: activeSource,
      sheets: Object.keys(sheets).map(key => ({ key, count: sheets[key].length })),
    });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.post('/api/reload', async (req, res) => {
  try {
    clearAiCache();
    if (activeSource === 'databricks') {
      databricksCache = null;
      await loadDatabricks();
    } else {
      clearCache();
      parseXlsx(XLSX_PATH);
    }
    res.json({ success: true, message: `Reloaded from ${activeSource}.`, meta: getActiveCache().meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/reload/excel', (req, res) => {
  try {
    clearCache(); clearAiCache();
    const ok = loadExcel();
    if (!ok) return res.status(404).json({ success: false, error: `Excel not found: ${path.resolve(XLSX_PATH)}` });
    res.json({ success: true, message: 'Reloaded from Excel.', meta: getActiveCache().meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/reload/databricks', async (req, res) => {
  try {
    clearAiCache(); databricksCache = null;
    const ok = await loadDatabricks();
    if (!ok) return res.status(500).json({ success: false, error: 'Databricks load failed -- check logs.' });
    res.json({ success: true, message: 'Reloaded from Databricks.', meta: databricksCache.meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// -- Routes: AI ------------------------------------------------
app.post('/api/ai/analyze', async (req, res) => {
  const { clientId, storyId, forceRefresh = false } = req.body;
  if (!clientId || !storyId) {
    return res.status(400).json({ success: false, error: 'Both clientId and storyId are required.' });
  }

  let cacheData;
  try { cacheData = getActiveCache(); }
  catch (e) { return res.status(503).json({ success: false, error: e.message }); }

  const client = cacheData.clients.find(c => String(c.id).toLowerCase() === String(clientId).toLowerCase());
  if (!client) return res.status(404).json({ success: false, error: `Client "${clientId}" not found.` });

  const xlsxMetrics = cacheData.narratives?.[storyId]?.metrics || [];
  if (forceRefresh) deleteAiCacheEntry(`${clientId}_${storyId}`);

  try {
    const result = await generateAiAnalysis({ client, storyId, xlsxMetrics });
    res.json({ success: true, clientId, storyId, fromCache: result.fromCache, dataSource: activeSource, analysis: result });
  } catch (e) {
    console.error('[ai/analyze]', e.message);
    res.status(500).json({
      success: false, error: e.message,
      hint: e.message.includes('OPENROUTER_API_KEY')
        ? 'Add your key to backend/.env -- free at https://openrouter.ai'
        : 'AI generation failed -- check backend logs.',
    });
  }
});

app.get('/api/ai/cache', (_req, res) => res.json({ success: true, ...getAiCacheStatus() }));
app.delete('/api/ai/cache', (_req, res) => { clearAiCache(); res.json({ success: true, message: 'AI cache cleared.' }); });

// -- Debug -----------------------------------------------------
app.get('/api/debug/columns', (_req, res) => {
  try {
    const cache = getActiveCache();
    const result = {};
    Object.entries(cache.sheets || {}).forEach(([k, rows]) => {
      result[k] = { rowCount: rows.length, columns: rows.length ? Object.keys(rows[0]) : [], sample: rows[0] };
    });
    res.json({
      success: true, dataSource: activeSource,
      totalClients: cache.clients.length,
      firstClientName: cache.clients[0]?.name,
      sheets: result, meta: cache.meta,
    });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.use((req, res) => res.status(404).json({ success: false, error: `Route not found: ${req.method} ${req.url}` }));
app.use((err, _req, res, _next) => {
  console.error('[server]', err);
  res.status(500).json({ success: false, error: 'Internal server error.' });
});

// -- Boot ------------------------------------------------------
async function boot() {
  console.log('\n-------------------------------------------');
  console.log('  Marsh ClaimsIQ -- API Server (TypeScript)');
  console.log('-------------------------------------------\n');

  const xlsxExists = fs.existsSync(path.resolve(XLSX_PATH));

  if (!FORCE_DB && xlsxExists) {
    console.log(`[boot] ? Excel file found -- Databricks skipped`);
    const ok = loadExcel();
    if (!ok) { console.error('[x]  Excel file found but failed to parse.'); process.exit(1); }
    startWatcher(XLSX_PATH);
  } else {
    console.log(FORCE_DB ? '[boot] ? FORCE_DATABRICKS=true' : `[boot] !?  No Excel at: ${path.resolve(XLSX_PATH)}`);
    const ok = await loadDatabricks();
    if (!ok) {
      console.error('[x]  Databricks failed. No Excel file present either.');
      console.error(`    Place .xlsx at backend/${XLSX_PATH}`);
      process.exit(1);
    }
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey || apiKey === 'your_openrouter_api_key_here') {
    console.warn('!?   OPENROUTER_API_KEY not set -- AI analysis disabled');
  } else {
    console.log(`?  AI model: ${process.env.OPENROUTER_MODEL || 'mistralai/mistral-7b-instruct'}`);
  }

  app.listen(PORT, () => {
    console.log(`\n[ok]  Server running -> http://localhost:${PORT}`);
    console.log(`?  Data source: ${String(activeSource).toUpperCase()}\n`);
  });
}

boot();
