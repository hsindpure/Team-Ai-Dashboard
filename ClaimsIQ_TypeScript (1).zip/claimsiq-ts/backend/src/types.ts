// @ts-nocheck
/**
 * types.ts -- Shared TypeScript interfaces for ClaimsIQ backend
 */

// -------------------------------------------------------------
// RAW CLAIM ROW (after normalization)
// -------------------------------------------------------------
export interface ClaimRow {
  entity?: string;
  policy_year?: string | number;
  month?: string | number;
  month_name?: string;
  month_year?: string;
  quarter?: string;
  fund?: string;
  claim_type?: string;
  member_type?: string;
  relationship?: string;
  icd_code?: string;
  illness?: string;
  illness_group?: string;
  facility?: string;
  facility_type?: string;
  case_tag?: string;
  case_count?: number;
  claim_no?: string;
  plan_level?: string;
  plan_description?: string;
  age?: number;
  age_group?: string;
  year_of_birth?: number;
  gender?: string;
  civil_status?: string;
  billed_amount?: number;
  covered_amount?: number;
  approved_amount?: number;
  member_id?: string;
  branch?: string;
  status?: string;
  mbl?: number;
  filename?: string;
  category?: string;
  [key: string]: unknown;
}

// -------------------------------------------------------------
// ANALYTICS (computed per client)
// -------------------------------------------------------------
export interface MonthlyChart {
  labels: string[];
  pmpm: number[];
  count: number[];
}

export interface DiagnosisChart {
  labels: string[];
  costs: number[];
  counts: number[];
}

export interface AgeDistribution {
  [band: string]: number;
}

export interface Analytics {
  totalApproved: number;
  totalBilled: number;
  totalClaims: number;
  pmpm: number;
  pmpy: number;
  avgAge: number;
  memberCount: number;
  dependentCount: number;
  femaleCount: number;
  maleCount: number;
  chronicCount: number;
  chronicPct: number;
  trendPct: number;
  top5Diagnoses: { name: string; count: number; pct: number; cost: number }[];
  claimTypeCosts: Record<string, number>;
  claimTypeCounts: Record<string, number>;
  facilityTypeSplit: Record<string, number>;
  costByPolicyYear: Record<string, number>;
  planLevelCosts: Record<string, number>;
  ageDistribution: AgeDistribution;
  monthlyChart: MonthlyChart;
  diagnosisChart: DiagnosisChart;
  nearMblCount: number;
  highCostMembers: number;
}

// -------------------------------------------------------------
// CLIENT
// -------------------------------------------------------------
export interface Client {
  id: string;
  name: string;
  members: number;
  pmpy: number;
  pmpm: number;
  trendPct: number;
  chronicPct: number;
  riskScore: number;
  totalCost: number;
  totalClaims: number;
  industry: string;
  country: string;
  currency: string;
  meetingDate: string;
  manager: string;
  renewalDate: string;
  renewalOverdue: boolean;
  planType?: string;
  analytics?: Analytics;
  [key: string]: unknown;
}

// -------------------------------------------------------------
// STORY / NARRATIVE
// -------------------------------------------------------------
export interface Story {
  id: string;
  icon: string;
  label: string;
  desc: string;
}

export interface MetricEntry {
  label: string;
  value: string;
  delta?: string;
  bench?: string;
  benchLabel?: string;
  dir: string;
}

export interface Narrative {
  headline: string;
  insight: string;
  so_what: string;
  talking_points: string[];
  metrics: MetricEntry[];
  chart: { labels: string[]; values: number[]; bench?: number[] };
  chartColor: string;
}

// -------------------------------------------------------------
// CACHE / APP DATA
// -------------------------------------------------------------
export interface CacheMeta {
  sheetNames: string[];
  primaryKey: string;
  parsedAt: string;
  filePath: string;
  totalClients: number;
  totalClaims: number | null;
  dataFormat: 'hmo-claims-level' | 'summarised';
  source?: string;
  currency: string;
}

export interface DataCache {
  clients: Client[];
  stories: Story[];
  narratives: Record<string, Narrative>;
  claimsData: ClaimRow[] | null;
  sheets: Record<string, Record<string, unknown>[]>;
  meta: CacheMeta;
}

// -------------------------------------------------------------
// AI ANALYSIS
// -------------------------------------------------------------
export interface AiKpi {
  label: string;
  value: string;
  dir: string;
  delta?: string;
}

export interface AiAnalysis {
  headline: string;
  so_what: string;
  talking_points: string[];
  kpis: AiKpi[];
  confidence: string;
  fromCache: boolean;
}

export interface AiAnalysisInput {
  client: Client;
  storyId: string;
  xlsxMetrics?: MetricEntry[];
}
