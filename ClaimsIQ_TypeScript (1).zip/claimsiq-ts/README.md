# ClaimsIQ — TypeScript + Vite + SCSS Edition

Marsh Philippines HMO Claims Analytics Platform  
Converted from JSX/CSS → TypeScript/SCSS with Vite

## Project Structure

```
claimsiq-ts/
├── frontend/                    ← Vite + React + TypeScript
│   ├── src/
│   │   ├── app/
│   │   │   ├── components/
│   │   │   │   ├── landing-page/        ← landing-page.tsx + landing-page.module.scss
│   │   │   │   ├── client-brief/        ← client-brief.tsx + client-brief.module.scss
│   │   │   │   ├── analysis-view/       ← analysis-view.tsx + analysis-view.module.scss
│   │   │   │   └── navbar-ciq/          ← navbar-ciq.tsx + navbar-ciq.module.scss
│   │   │   ├── models/claims/           ← client.model.ts, story.model.ts, api.model.ts
│   │   │   ├── services/               ← claims.service.ts
│   │   │   ├── utils/                  ← risk-color.util.ts, format.util.ts, enrich-clients.util.ts
│   │   │   └── app.tsx                 ← main app component
│   │   ├── styles/
│   │   │   ├── _variables.scss         ← design tokens (colours, shadows, radii)
│   │   │   └── global.scss             ← reset + shared styles
│   │   └── main.tsx                    ← entry point
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   └── package.json
│
└── backend/                     ← Express + TypeScript
    ├── src/
    │   ├── server.ts
    │   ├── dataParser.ts
    │   ├── claimsCalculator.ts
    │   ├── aiAnalyzer.ts
    │   └── databricksConnector.ts
    ├── dataFile/                ← place your .xlsx here
    ├── .env
    ├── tsconfig.json
    └── package.json
```

## Setup & Run

### 1. Backend
```bash
cd backend
npm install
# Add your .xlsx file to backend/dataFile/claimsiq_data.xlsx
npm run dev
# Server starts on http://localhost:3001
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
# App starts on http://localhost:3000
```

## Adding to Your Office Project

Copy these folders into your office project's Nx workspace:

| ClaimsIQ folder | Office project destination |
|---|---|
| `frontend/src/app/components/*` | `apps/ui/src/app/components/` |
| `frontend/src/app/models/claims/` | `apps/ui/src/app/models/claims/` |
| `frontend/src/app/services/claims.service.ts` | `apps/ui/src/app/services/` |
| `frontend/src/app/utils/*.ts` | `apps/ui/src/app/utils/` |
| `frontend/src/styles/_variables.scss` | `apps/ui/src/app/components/landing-page/` |
| `frontend/src/styles/global.scss` | add `@import` to `apps/ui/src/styles.scss` |

## Environment Variables (frontend)
```
VITE_API_URL=http://localhost:3001/api
```
