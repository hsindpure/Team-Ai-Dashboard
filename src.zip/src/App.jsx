import { useState } from "react";
import C from "./styles/colors";
import CLIENTS from "./data/clients";
import NavBar from "./components/NavBar";
import ClientHome from "./components/ClientHome";
import BriefView from "./components/BriefView";

export default function App() {
  const [client,      setClient]      = useState(CLIENTS[0]);
  const [storyId,     setStoryId]     = useState(null);
  const [exportCount, setExportCount] = useState(0);

  const handleClientChange = id => {
    setClient(CLIENTS.find(c => c.id === id));
    setStoryId(null);
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg }}>
      <NavBar client={client} exportCount={exportCount} onClientChange={handleClientChange} />
      <div style={{ maxWidth: 960, margin: "0 auto", padding: "36px 24px" }}>
        {storyId
          ? <BriefView client={client} storyId={storyId} onBack={() => setStoryId(null)} onExport={() => setExportCount(n => n + 1)} />
          : <ClientHome client={client} onSelectStory={setStoryId} />
        }
      </div>
    </div>
  );
}