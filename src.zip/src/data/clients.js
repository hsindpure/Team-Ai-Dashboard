const CLIENTS = [
    {
      id:          "C001",
      name:        "Meridian Manufacturing",
      industry:    "Manufacturing",
      members:     4820,
      meetingDate: "Mar 4, 2026",
      manager:     "Sarah Chen",
    },
    {
      id:          "C002",
      name:        "Crestview Health Systems",
      industry:    "Healthcare",
      members:     12340,
      meetingDate: "Mar 11, 2026",
      manager:     "James Okafor",
    },
    {
      id:          "C003",
      name:        "Hartwell Financial Group",
      industry:    "Financial Services",
      members:     2190,
      meetingDate: "Mar 18, 2026",
      manager:     "Sarah Chen",
    },
  ];
  
  export default CLIENTS;