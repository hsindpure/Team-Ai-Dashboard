const STORY_TEMPLATES = [
    { id: "cost_trend",  icon: "📈", label: "Cost Trend",          desc: "How costs moved vs prior year and benchmark" },
    { id: "rx_story",    icon: "💊", label: "Rx Opportunity",      desc: "Generic conversion and specialty exposure" },
    { id: "high_cost",   icon: "🔴", label: "High-Cost Claimants", desc: "Top cost drivers and impact on total spend" },
    { id: "utilization", icon: "🏥", label: "Utilization Shifts",  desc: "ER, inpatient, and preventive care patterns" },
    { id: "plan_perf",   icon: "⚖️", label: "Plan Performance",    desc: "HDHP vs PPO enrollment, OOP, and engagement" },
  ];
  
  export default STORY_TEMPLATES;