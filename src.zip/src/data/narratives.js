const NARRATIVES = {
    cost_trend: {
      headline: "Total costs rose 8.4% year-over-year, outpacing the industry benchmark by 2.1 points.",
      insight:  "The primary driver is specialty Rx spend, which grew 22% and now represents 31% of total pharmacy costs — up from 24% last year. Medical unit cost increases were modest at 3.1%, indicating the cost pressure is concentrated in the drug benefit.",
      so_what:  "Without intervention, specialty Rx is on pace to add $420K in incremental cost in 2026. A specialty drug management program or step-therapy protocol for the top 5 agents could recover 40–60% of that.",
      metrics: [
        { label: "Total PMPM",         value: "$487",   delta: "+8.4%",                  dir: "bad",     bench: "$461",  benchLabel: "Industry" },
        { label: "Medical PMPM",       value: "$352",   delta: "+3.8%",                  dir: "neutral", bench: "$344",  benchLabel: "Industry" },
        { label: "Rx PMPM",            value: "$135",   delta: "+18.2%",                 dir: "bad",     bench: "$117",  benchLabel: "Industry" },
        { label: "Trend vs Benchmark", value: "+2.1pp", delta: "Gap widened from 0.8pp", dir: "bad",     bench: "0.0pp", benchLabel: "Target"   },
      ],
      talking_points: [
        "Costs are rising faster than peers — the benchmark gap widened from 0.8 points last year to 2.1 points.",
        "Specialty Rx is the story this year, not medical utilization — this is a drug benefit conversation.",
        "We have a clear intervention path with estimated savings. This isn't just a 'costs are going up' conversation.",
      ],
      chart: {
        labels: ["Q1 '23","Q2 '23","Q3 '23","Q4 '23","Q1 '24","Q2 '24","Q3 '24","Q4 '24"],
        values: [421, 438, 429, 445, 452, 468, 459, 487],
        bench:  [415, 420, 418, 425, 435, 441, 438, 455],
      },
    },
    rx_story: {
      headline: "Generic dispensing rate is 74% — 8 points below the achievable benchmark of 82%.",
      insight:  "Brand drugs with available generic equivalents account for $1.2M in annual spend. The top 3 brand-to-generic conversion opportunities — Eliquis, Jardiance, and an Ozempic biosimilar — represent $640K. Mail-order utilization is also low at 18% of maintenance fills vs a 35% benchmark.",
      so_what:  "A targeted member outreach program and PBM formulary adjustment on the top conversion opportunities could yield $380–520K in annual savings. Mail-order expansion alone typically delivers $80–120 PMPM reduction on maintenance drugs.",
      metrics: [
        { label: "Generic Rate",      value: "74%",   delta: "-8pp vs benchmark",  dir: "bad",     bench: "82%", benchLabel: "Achievable" },
        { label: "Specialty % of Rx", value: "31%",   delta: "+7pp YoY",           dir: "bad",     bench: "24%", benchLabel: "Last Year"  },
        { label: "Mail Order Rate",   value: "18%",   delta: "-17pp vs benchmark", dir: "bad",     bench: "35%", benchLabel: "Benchmark"  },
        { label: "Conversion Opp.",   value: "$640K", delta: "Top 3 drugs",        dir: "neutral", bench: "",    benchLabel: ""           },
      ],
      talking_points: [
        "You're leaving meaningful money on the table in the drug benefit — and the fix is well-understood.",
        "This isn't about restricting access — it's directing members to equivalent, lower-cost options.",
        "We can size the savings with precision and model the member impact before any change is made.",
      ],
      chart: {
        labels: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
        values: [71, 72, 71, 73, 72, 74, 73, 75, 74, 74, 75, 74],
        bench:  [80, 80, 81, 81, 82, 82, 82, 82, 82, 82, 82, 82],
      },
    },
    high_cost: {
      headline: "18 members drove 34% of total medical spend in 2024 — a concentration ratio above industry norms.",
      insight:  "The top cost tier (claims >$100K) included 4 new entrants this year, 2 of whom had no prior utilization. Oncology (3 members), NICU (2 members), and musculoskeletal (4 members) account for the majority. Stop-loss attachment was triggered for 3 members, recovering $1.1M.",
      so_what:  "Predictive identification of rising-risk members before they become high-cost is the opportunity. Two new high-cost members had prior ER utilization patterns that are strong predictive signals. A care management program targeting the $25–100K spend band could flatten the curve.",
      metrics: [
        { label: "Members >$100K",      value: "18",    delta: "+4 vs 2023",    dir: "bad",     bench: "12",  benchLabel: "2023"      },
        { label: "Top Tier % of Spend", value: "34%",   delta: "+6pp YoY",      dir: "bad",     bench: "28%", benchLabel: "Last Year" },
        { label: "Stop-Loss Recovery",  value: "$1.1M", delta: "3 members",     dir: "neutral", bench: "",    benchLabel: ""          },
        { label: "Rising Risk Members", value: "41",    delta: "$25–100K band", dir: "neutral", bench: "",    benchLabel: ""          },
      ],
      talking_points: [
        "High-cost concentration is up — this is the number your CFO will ask about.",
        "Stop-loss is doing its job, but upstream prevention is the long-term lever.",
        "We can identify the 41 rising-risk members and engage them now, before they cross the threshold.",
      ],
      chart: {
        labels: ["2020","2021","2022","2023","2024"],
        values: [22, 19, 24, 14, 34],
        bench:  [26, 25, 27, 28, 28],
      },
    },
  };
  
  export default NARRATIVES;