import C from "../styles/colors";

export default function MetricTile({ m }) {
  const color = m.dir === "bad" ? C.red : m.dir === "good" ? C.green : C.amber;
  const bg    = m.dir === "bad" ? C.redBg : m.dir === "good" ? C.greenBg : C.amberBg;
  const arrow = m.dir === "bad" ? "↑" : m.dir === "good" ? "↓" : "→";

  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: "16px 18px", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: color, opacity: 0.5, borderRadius: "10px 10px 0 0" }} />
      <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 8, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>{m.label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, color: C.text, fontFamily: "'Lora', serif", letterSpacing: -0.5, lineHeight: 1 }}>{m.value}</div>
      {m.delta && (
        <div style={{ marginTop: 8, fontSize: 11.5, color: color, fontWeight: 600, background: bg, display: "inline-block", padding: "2px 7px", borderRadius: 4 }}>
          {m.dir !== "neutral" && arrow + " "}{m.delta}
        </div>
      )}
      {m.bench && (
        <div style={{ marginTop: 7, fontSize: 11, color: C.textMuted }}>
          {m.benchLabel}: <span style={{ color: C.textSoft, fontWeight: 500 }}>{m.bench}</span>
        </div>
      )}
    </div>
  );
}