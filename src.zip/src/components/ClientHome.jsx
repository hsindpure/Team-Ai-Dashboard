import C from "../styles/colors";
import STORY_TEMPLATES from "../data/storyTemplates";
import NARRATIVES from "../data/narratives";

export default function ClientHome({ client, onSelectStory }) {
  return (
    <div style={{ animation: "fadeUp 0.25s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 28, marginBottom: 32, borderBottom: `1px solid ${C.border}` }}>
        <div>
          <div style={{ fontSize: 11, color: C.amber, letterSpacing: 1.5, marginBottom: 10, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Client Brief</div>
          <div style={{ fontSize: 30, fontWeight: 700, color: C.text, fontFamily: "'Lora', serif", letterSpacing: -0.5, lineHeight: 1.2 }}>{client.name}</div>
          <div style={{ fontSize: 13, color: C.textSoft, marginTop: 8 }}>{client.members.toLocaleString()} members · {client.industry}</div>
        </div>
        <div style={{ background: C.amberBg, border: `1px solid ${C.amberBdr}`, borderRadius: 10, padding: "14px 20px", textAlign: "right" }}>
          <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 5, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Next Meeting</div>
          <div style={{ fontSize: 17, color: C.amber, fontWeight: 700, fontFamily: "'Lora', serif" }}>{client.meetingDate}</div>
          <div style={{ fontSize: 12, color: C.textSoft, marginTop: 4 }}>with {client.manager}</div>
        </div>
      </div>

      <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 16, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Choose a Story to Build</div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: 14 }}>
        {STORY_TEMPLATES.map(t => {
          const hasData = !!NARRATIVES[t.id];
          return (
            <div key={t.id} onClick={() => hasData && onSelectStory(t.id)}
              style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "22px 20px", cursor: hasData ? "pointer" : "default", opacity: hasData ? 1 : 0.4, transition: "all 0.15s", position: "relative" }}
              onMouseEnter={e => { if (hasData) { e.currentTarget.style.borderColor = C.borderHov; e.currentTarget.style.boxShadow = "0 4px 16px rgba(193,125,46,0.1)"; }}}
              onMouseLeave={e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.boxShadow = "none"; }}>
              <div style={{ fontSize: 24, marginBottom: 12 }}>{t.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 6, fontFamily: "'Lora', serif" }}>{t.label}</div>
              <div style={{ fontSize: 12.5, color: C.textSoft, lineHeight: 1.55 }}>{t.desc}</div>
              {hasData
                ? <div style={{ position: "absolute", bottom: 16, right: 18, fontSize: 12, color: C.amber, fontWeight: 600 }}>Build →</div>
                : <div style={{ position: "absolute", bottom: 16, right: 18, fontSize: 11, color: C.textMuted }}>No data</div>
              }
            </div>
          );
        })}
      </div>
    </div>
  );
}