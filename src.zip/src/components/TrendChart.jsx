import C from "../styles/colors";

const W = 440, H = 110, PX = 8, PY = 12;

export default function TrendChart({ data, bench, labels }) {
  const all   = [...data, ...(bench || [])];
  const mn    = Math.min(...all) * 0.95;
  const mx    = Math.max(...all) * 1.05;
  const range = mx - mn || 1;

  const px   = i => PX + (i / (data.length - 1)) * (W - PX * 2);
  const py   = v => H - PY - ((v - mn) / range) * (H - PY * 2);
  const dPts = data.map((v, i) => `${px(i)},${py(v)}`).join(" ");
  const bPts = bench?.map((v, i) => `${px(i)},${py(v)}`).join(" ");
  const area = `${PX},${H - PY} ${dPts} ${W - PX},${H - PY}`;
  const step = Math.ceil(labels.length / 5);

  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 110 }} preserveAspectRatio="none">
        <defs>
          <linearGradient id="wg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor={C.amber} stopOpacity="0.18" />
            <stop offset="100%" stopColor={C.amber} stopOpacity="0"    />
          </linearGradient>
        </defs>
        <polygon points={area} fill="url(#wg)" />
        {bPts && <polyline points={bPts} fill="none" stroke={C.border} strokeWidth="1.5" strokeDasharray="5 3" />}
        <polyline points={dPts} fill="none" stroke={C.amber} strokeWidth="2.5" strokeLinejoin="round" />
        {data.map((v, i) => (
          <circle key={i} cx={px(i)} cy={py(v)} r="3.5" fill={C.surface} stroke={C.amber} strokeWidth="2" />
        ))}
        {labels.map((l, i) =>
          i % step === 0 ? (
            <text key={i} x={px(i)} y={H} textAnchor="middle" fontSize="9.5" fill={C.textMuted} fontFamily="'DM Mono', monospace">{l}</text>
          ) : null
        )}
      </svg>
      <div style={{ display: "flex", gap: 18, marginTop: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: C.textMuted }}>
          <div style={{ width: 18, height: 2.5, background: C.amber, borderRadius: 2 }} /> Client
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: C.textMuted }}>
          <div style={{ width: 18, height: 0, borderTop: `2px dashed ${C.border}` }} /> Benchmark
        </div>
      </div>
    </div>
  );
}