import C from "../styles/colors";

export default function TalkingPoint({ text, saved, onToggle }) {
  return (
    <div onClick={onToggle} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "12px 14px", borderRadius: 8, cursor: "pointer", background: saved ? C.amberBg : "transparent", border: `1px solid ${saved ? C.amberBdr : "transparent"}`, transition: "all 0.15s", marginBottom: 6 }}>
      <div style={{ width: 20, height: 20, borderRadius: "50%", flexShrink: 0, marginTop: 2, border: `1.5px solid ${saved ? C.amber : C.border}`, background: saved ? C.amber : "transparent", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s" }}>
        {saved && <span style={{ color: "#fff", fontSize: 11, fontWeight: 700, lineHeight: 1 }}>✓</span>}
      </div>
      <div style={{ fontSize: 13.5, color: saved ? C.textMid : C.textSoft, lineHeight: 1.65 }}>{text}</div>
    </div>
  );
}