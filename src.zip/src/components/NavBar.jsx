import C from "../styles/colors";
import CLIENTS from "../data/clients";

export default function NavBar({ client, exportCount, onClientChange }) {
  return (
    <div style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "0 32px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 58, position: "sticky", top: 0, zIndex: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 34, height: 34, background: C.amber, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: "#fff", fontSize: 16, fontWeight: 700, fontFamily: "'Lora', serif" }}>B</span>
        </div>
        <span style={{ color: C.text, fontWeight: 600, fontSize: 15 }}>Brief</span>
        <span style={{ color: C.border, fontSize: 18 }}>|</span>
        <span style={{ color: C.textSoft, fontSize: 13 }}>Client Intelligence</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        {exportCount > 0 && (
          <div style={{ fontSize: 11.5, color: C.green, background: C.greenBg, padding: "4px 10px", borderRadius: 6, fontWeight: 600 }}>
            ✓ {exportCount} exported
          </div>
        )}
        <span style={{ fontSize: 11, color: C.textMuted, fontFamily: "'DM Mono', monospace" }}>CLIENT</span>
        <select value={client.id} onChange={e => onClientChange(e.target.value)}
          style={{ fontSize: 13, color: C.text, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 7, padding: "6px 12px", cursor: "pointer", fontFamily: "inherit" }}>
          {CLIENTS.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
    </div>
  );
}