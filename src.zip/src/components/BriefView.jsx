import { useState } from "react";
import C from "../styles/colors";
import NARRATIVES from "../data/narratives";
import STORY_TEMPLATES from "../data/storyTemplates";
import MetricTile from "./MetricTile";
import TalkingPoint from "./TalkingPoint";
import TrendChart from "./TrendChart";

export default function BriefView({ client, storyId, onBack, onExport }) {
  const n    = NARRATIVES[storyId];
  const tmpl = STORY_TEMPLATES.find(t => t.id === storyId);

  const [saved,      setSaved]      = useState({});
  const [customNote, setCustomNote] = useState("");
  const [noteAdded,  setNoteAdded]  = useState(false);
  const [exported,   setExported]   = useState(false);

  const toggle   = i => setSaved(p => ({ ...p, [i]: !p[i] }));
  const addNote  = () => { if (!customNote.trim()) return; setNoteAdded(true); setCustomNote(""); setTimeout(() => setNoteAdded(false), 2000); };
  const doExport = () => { setExported(true); onExport?.(); setTimeout(() => setExported(false), 2500); };
  const selectedCount = Object.values(saved).filter(Boolean).length;

  return (
    <div style={{ animation: "fadeUp 0.25s ease" }}>
      {/* Breadcrumb */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 28, fontSize: 12, color: C.textMuted }}>
        <button onClick={onBack} style={{ color: C.amber, background: "none", border: "none", cursor: "pointer", fontSize: 12, padding: 0, fontFamily: "inherit" }}>← Client Prep</button>
        <span>/</span><span>{client.name}</span><span>/</span>
        <span style={{ color: C.textMid, fontWeight: 500 }}>{tmpl.label}</span>
      </div>

      {/* Headline */}
      <div style={{ marginBottom: 26, paddingBottom: 24, borderBottom: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 11, color: C.amber, letterSpacing: 1.5, marginBottom: 10, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>
          {tmpl.icon} {tmpl.label} · {client.name}
        </div>
        <div style={{ fontSize: 21, fontWeight: 700, color: C.text, fontFamily: "'Lora', serif", lineHeight: 1.45, maxWidth: 680 }}>
          "{n.headline}"
        </div>
      </div>

      {/* Metrics */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(185px, 1fr))", gap: 12, marginBottom: 26 }}>
        {n.metrics.map((m, i) => <MetricTile key={i} m={m} />)}
      </div>

      {/* Chart + Insight row */}
      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 16, marginBottom: 20 }}>
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 20 }}>
          <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 14, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Trend</div>
          <TrendChart data={n.chart.values} bench={n.chart.bench} labels={n.chart.labels} />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 18, flex: 1 }}>
            <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 10, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>What's Driving It</div>
            <div style={{ fontSize: 13, color: C.textSoft, lineHeight: 1.75 }}>{n.insight}</div>
          </div>
          <div style={{ background: C.amberBg, border: `1px solid ${C.amberBdr}`, borderRadius: 10, padding: 18 }}>
            <div style={{ fontSize: 10.5, color: C.amber, letterSpacing: 0.8, marginBottom: 10, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>So What / Action</div>
            <div style={{ fontSize: 13, color: C.textMid, lineHeight: 1.75, fontWeight: 500 }}>{n.so_what}</div>
          </div>
        </div>
      </div>

      {/* Talking points */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: 22, marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Talking Points</div>
          <div style={{ fontSize: 11.5, color: selectedCount > 0 ? C.amber : C.textMuted, fontWeight: selectedCount > 0 ? 600 : 400 }}>
            {selectedCount > 0 ? `${selectedCount} selected for export` : "Click to select"}
          </div>
        </div>
        {n.talking_points.map((pt, i) => <TalkingPoint key={i} text={pt} saved={!!saved[i]} onToggle={() => toggle(i)} />)}
        <div style={{ marginTop: 16, paddingTop: 16, borderTop: `1px solid ${C.border}` }}>
          <div style={{ fontSize: 10.5, color: C.textMuted, letterSpacing: 0.8, marginBottom: 8, fontFamily: "'DM Mono', monospace", textTransform: "uppercase" }}>Add Your Own</div>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={customNote} onChange={e => setCustomNote(e.target.value)} onKeyDown={e => e.key === "Enter" && addNote()}
              placeholder="Add a talking point specific to this client..."
              style={{ flex: 1, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 7, padding: "9px 13px", fontSize: 13, color: C.text, fontFamily: "inherit", outline: "none" }} />
            <button onClick={addNote} style={{ padding: "9px 18px", background: noteAdded ? C.green : C.amber, color: "#fff", border: "none", borderRadius: 7, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: "background 0.2s", whiteSpace: "nowrap", fontFamily: "inherit" }}>
              {noteAdded ? "✓ Added" : "Add"}
            </button>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
        <button onClick={onBack} style={{ padding: "10px 20px", background: "none", border: `1px solid ${C.border}`, borderRadius: 8, color: C.textSoft, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>← Back</button>
        <button onClick={doExport} style={{ padding: "10px 26px", background: exported ? C.green : C.amber, color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: "background 0.2s", fontFamily: "inherit" }}>
          {exported ? "✓ Exported to PowerPoint" : "Export to PowerPoint →"}
        </button>
      </div>
    </div>
  );
}