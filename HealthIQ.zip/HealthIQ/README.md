# ClaimsIQ v3.0 — Marsh Philippines HMO Claims Analytics

## Quick Start

```bash
# 1. Backend
cd backend
npm install
cp .env .env          # edit MongoDB URI, Databricks creds, OpenRouter key
# Place your Excel at: backend/dataFile/Insurence.xlsx
npm run dev           # http://localhost:3001

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev           # http://localhost:3000
```

## Data Sources (priority order)

1. **Excel** — `backend/dataFile/Insurence.xlsx` (default, auto-detects claim columns)
2. **Databricks** — set `FORCE_DATABRICKS=true` or remove Excel file
3. **MongoDB Atlas** — auto-fallback cache if no Excel and Databricks down

## .env Keys

| Key | Purpose |
|-----|---------|
| `XLSX_FILE` | Path to Excel (default: `dataFile/Insurence.xlsx`) |
| `FORCE_DATABRICKS` | `true` to skip Excel |
| `DATABRICKS_TOKEN` | Personal access token |
| `DATABRICKS_SERVER_HOSTNAME` | e.g. `dbc-xxx.cloud.databricks.com` |
| `DATABRICKS_HTTP_PATH` | e.g. `/sql/1.0/warehouses/xxx` |
| `DATABRICKS_TABLE` | `catalog.schema.table` |
| `MONGODB_URI` | Atlas connection string |
| `MONGODB_DB` | Database name (default: `healthiqDev`) |
| `MONGO_PERSIST` | `true` to auto-save after each load |
| `OPENROUTER_API_KEY` | Free key from openrouter.ai |

## Folder Structure (matches screenshots)

```
CLAIMSIQ-TS/
├── backend/
│   ├── dataFile/
│   │   └── Insurence.xlsx          ← place your claims Excel here
│   ├── src/
│   │   ├── aiAnalyzer.ts           ← AI narrative generator
│   │   ├── claimsCalculator.ts     ← all KPI calculations (zero hardcoding)
│   │   ├── databricksConnector.ts  ← Databricks SQL connection
│   │   ├── dataParser.ts           ← Excel parser
│   │   ├── mongoConnector.ts       ← MongoDB Atlas persistence (NEW)
│   │   ├── server.ts               ← Express API
│   │   └── types.ts                ← TypeScript interfaces
│   └── .env
└── frontend/
    └── src/
        ├── app/
        │   ├── components/
        │   │   ├── analysis-view/  ← 6 story analytics view
        │   │   ├── client-brief/   ← story selector page
        │   │   ├── landing-page/   ← portfolio dashboard
        │   │   └── navbar-ciq/     ← navigation
        │   ├── contexts/           ← recently visited
        │   ├── models/             ← TypeScript models
        │   ├── services/           ← API service layer
        │   ├── utils/              ← format, risk-color, enrich
        │   └── app.tsx
        └── styles/
            ├── _variables.scss
            └── global.scss
```

## API Endpoints

```
GET  /api/health              Health + data source status
GET  /api/all                 All clients + stories + meta
GET  /api/clients             Client list
GET  /api/client/:id          Single client with full analytics
GET  /api/source              Active data source info
POST /api/reload              Reload active source
POST /api/reload/excel        Force reload from Excel
POST /api/reload/databricks   Force reload from Databricks
GET  /api/databricks/status   Test Databricks connection
GET  /api/mongo/status        Test MongoDB connection
GET  /api/mongo/history       Load history log
POST /api/ai/analyze          Generate AI narrative
GET  /api/ai/cache            AI cache status
DELETE /api/ai/cache          Clear AI cache
GET  /api/debug/columns       Column introspection
```

## Dynamic KPI Engine

All KPIs computed dynamically from raw claim rows — no hardcoded values:

- **PMPM/PMPY** = totalApproved / uniqueMembers / numMonths
- **YoY Trend** = (currYear - prevYear) / prevYear × 100
- **Risk Score** = chronic(35%) + trend(25%) + highCost(25%) + utilisation(15%)
- **Chronic Rate** = claims matching 20+ chronic keywords / total claims
- **High-Cost** = members with spend ≥ 50% of MBL (MBL read from data)
- **Age bands** = built dynamically from age/age_group column
- **Member cost bands** = dynamic ranges based on actual MBL value
