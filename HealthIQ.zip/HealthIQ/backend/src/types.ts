// @ts-nocheck
/**
 * types.ts -- Shared TypeScript interfaces for ClaimsIQ backend
 * All fields are dynamic -- nothing hardcoded per client.
 */

export interface ClaimRow {
  entity?: string;
  policy_year?: string | number;
  month?: string | number;
  month_name?: string;
  month_year?: string;
  quarter?: string;
  fund?: string;
  claim_type?: string;
  member_type?: string;
  relationship?: string;
  icd_code?: string;
  illness?: string;
  illness_group?: string;
  facility?: string;
  facility_type?: string;
  case_tag?: string;
  case_count?: number;
  claim_no?: string;
  plan_level?: string;
  plan_description?: string;
  age?: number;
  age_group?: string;
  year_of_birth?: number;
  gender?: string;
  civil_status?: string;
  billed_amount?: number;
  covered_amount?: number;
  approved_amount?: number;
  member_id?: string;
  branch?: string;
  status?: string;
  mbl?: number;
  filename?: string;
  category?: string;
  [key: string]: unknown;
}

export interface MonthlyChart {
  labels: string[];
  pmpm: number[];
  count: number[];
}

export interface Analytics {
  // Core financials
  totalApproved: number;
  totalBilled: number;
  totalClaims: number;
  pmpm: number;
  pmpy: number;
  numMonths: number;
  latestPolicyYear: string;
  billedApprovedRatio: number;
  // Trend
  trendPct: number;
  costByPolicyYear: Record<string, number>;
  // Members
  members: number;
  claimsPerMember: number;
  // Charts
  monthlyChart: MonthlyChart;
  diagnosisChart: { labels: string[]; costs: number[]; counts: number[] };
  claimTypeChart: { labels: string[]; counts: number[]; costs: number[] };
  facilityChart:  { labels: string[]; counts: number[]; costs: number[] };
  memberCostChart:{ labels: string[]; counts: number[] };
  ageGroupChart:  { labels: string[]; counts: number[] };
  genderChart:    { labels: string[]; counts: number[] };
  planLevelChart: { labels: string[]; costs: number[]; counts: number[]; pmpm: number[] };
  quarterChart:   { labels: string[]; costs: number[]; counts: number[] };
  // Diagnostics
  top5Diagnoses: { name: string; cost: number; count: number; pct: number; topIllness: string }[];
  top10DiagnosesChart: { name: string; cost: number; count: number }[];
  // High-cost
  mbl: number;
  highCostMembers: number;
  highCostPct: number;
  topMemberCost: number;
  avgMemberCost: number;
  memberCostBands: Record<string, number>;
  // Demographics
  avgAge: number;
  ageGroups: Record<string, number>;
  genderCounts: Record<string, number>;
  malePct: number;
  femalePct: number;
  relCounts: Record<string, number>;
  employeeCount: number;
  dependentCount: number;
  dependentRatio: number;
  civilStatusCounts: Record<string, number>;
  // Plan / Fund
  planLevelCounts: Record<string, number>;
  planLevelCosts: Record<string, number>;
  planLevelPmpm: Record<string, number>;
  fundCounts: Record<string, number>;
  fundCosts: Record<string, number>;
  // Utilisation
  facilityTypeCounts: Record<string, number>;
  facilityCosts: Record<string, number>;
  claimTypeCosts: Record<string, number>;
  claimTypeCounts: Record<string, number>;
  // Quarterly
  quarterCosts: Record<string, number>;
  quarterCounts: Record<string, number>;
  // Chronic
  chronicClaims: number;
  chronicPct: number;
  // Org
  category: string;
  memberType: string;
  branches: string[];
}

export interface Client {
  id: string;
  name: string;
  members: number;
  pmpy: number;
  pmpm: number;
  trendPct: number;
  chronicPct: number;
  riskScore: number;
  totalCost: number;
  totalBilled: number;
  totalClaims: number;
  avgAge: number;
  industry: string;
  country: string;
  currency: string;
  meetingDate: string;
  manager: string;
  renewalDate: string;
  renewalOverdue: boolean;
  planType?: string;
  analytics?: Analytics;
  [key: string]: unknown;
}

export interface Story {
  id: string;
  icon: string;
  label: string;
  desc: string;
}

export interface MetricEntry {
  label: string;
  value: string;
  delta?: string;
  bench?: string;
  benchLabel?: string;
  dir: string;
}

export interface Narrative {
  headline: string;
  insight: string;
  so_what: string;
  talking_points: string[];
  metrics: MetricEntry[];
  chart: { labels: string[]; values: number[]; bench?: number[] };
  chartColor: string;
}

export interface CacheMeta {
  sheetNames: string[];
  primaryKey: string;
  parsedAt: string;
  filePath: string;
  totalClients: number;
  totalClaims: number | null;
  dataFormat: 'hmo-claims-level' | 'summarised';
  source?: string;
  currency: string;
}

export interface DataCache {
  clients: Client[];
  stories: Story[];
  narratives: Record<string, Narrative>;
  claimsData: ClaimRow[] | null;
  sheets: Record<string, Record<string, unknown>[]>;
  meta: CacheMeta;
}

export interface AiAnalysis {
  headline: string;
  so_what: string;
  talking_points: string[];
  kpis: { label: string; value: string; dir: string; delta?: string }[];
  confidence: string;
  fromCache: boolean;
}
