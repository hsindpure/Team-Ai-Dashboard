// @ts-nocheck
/**
 * claimsCalculator.ts -- Dynamic HMO Claims Analytics Engine
 * ----------------------------------------------------------
 * Single source of truth for ALL KPI calculations.
 * Zero hardcoding: every metric derived from real claim rows.
 * Works with Excel AND Databricks data via shared normalizer.
 */

// ── KEY NORMALIZER ──────────────────────────────────────────────
const KEY_MAP = {
  // Time
  "policy_year":"policy_year","policyyear":"policy_year",
  "month":"month","month_name":"month_name","monthname":"month_name",
  "month_year":"month_year","monthyear":"month_year",
  "new_quarter":"quarter","newquarter":"quarter","quarter":"quarter",
  // Fund
  "fund":"fund","insurer":"fund",
  // Claim type
  "final_claim_type":"claim_type","finalclaimtype":"claim_type",
  "claim_type":"claim_type","claimtype":"claim_type",
  "claim_type__group_":"claim_type","claim_type_group":"claim_type",
  "claim_definition":"claim_type",
  // Member
  "member_type":"member_type","membertype":"member_type",
  "provider_category":"member_type",
  "relationship":"relationship","relationship__group_":"relationship",
  // Diagnosis
  "icd_code2":"icd_code","icdcode2":"icd_code","icd_code":"icd_code","icd_9":"icd_code",
  "illness":"illness","diagnosis_major":"illness",
  "illness_group":"illness_group","illnessgroup":"illness_group",
  "grouped_diagnosis_updated_":"illness_group","grouped_diagnosis_updated":"illness_group",
  "grouped_diagnosis":"illness_group",
  // Facility
  "facility":"facility","provider_name":"facility","providers__hospitals_":"facility",
  "type_of_facility":"facility_type","typeoffacility":"facility_type",
  "facility_type":"facility_type","provider_type":"facility_type",
  // Case
  "case_tag":"case_tag","casetag":"case_tag",
  "case_count":"case_count","casecount":"case_count",
  "claim_no":"claim_no","claimno":"claim_no","claim_id":"claim_no",
  // Plan
  "plan_level":"plan_level","planlevel":"plan_level",
  "plan_description":"plan_description","plandescription":"plan_description",
  // Demographics
  "age":"age","age_group":"age_group","agegroup":"age_group",
  "age_band":"age_group","age_band__group_":"age_group",
  "year_of_birth":"year_of_birth","yearofbirth":"year_of_birth",
  "gender":"gender","gender__group_":"gender",
  "civil_status":"civil_status","civilstatus":"civil_status","fili_status":"civil_status",
  // Amounts
  "billed_amount":"billed_amount","billedamount":"billed_amount",
  "submitted_claim_amount":"billed_amount",
  "covered_amount":"covered_amount","coveredamount":"covered_amount",
  "approvedamount":"approved_amount","approved_amount":"approved_amount",
  "paid_claim":"approved_amount",
  // Member IDs
  "maskedmemberid + icd":"member_icd_tag",
  "masked_employee_id":"member_id","maskedemployeeid":"member_id",
  "masked_member_id":"member_id","maskedmemberid":"member_id",
  "masked memner id":"member_id","masked_memner_id":"member_id","maskedmemnerid":"member_id",
  "member_id":"member_id","employee_id":"member_id",
  // Entity
  "entity":"entity","organization":"entity","company":"entity",
  "account":"entity","client_name_updated_":"entity","client_name":"entity",
  "client_id":"entity",
  // Location
  "branch":"branch","provider_location":"branch",
  "category":"category","industry1":"category","industry__group_":"category","industry":"category",
  // Status
  "status":"status","claim_status":"status",
  "mbl":"mbl","max_benefit_limit":"mbl",
  "filename":"filename",
};

function normalizeRow(row) {
  const normalized = {};
  for (const [rawKey, val] of Object.entries(row)) {
    const lk = String(rawKey).trim().toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g,"");
    const canonical = KEY_MAP[lk] || lk;
    normalized[canonical] = val;
  }
  return normalized;
}

function isClaimsLevelData(rows) {
  if (!rows || rows.length < 2) return false;
  const norm = normalizeRow(rows[0]);
  const keys = Object.keys(norm).join(" ");
  const signals = ["illness","facility_type","claim_no","approved_amount",
    "icd_code","member_id","claim_type","plan_level","illness_group"];
  return signals.filter(f => keys.includes(f)).length >= 3;
}

const MONTH_NUM = {
  jan:"01",feb:"02",mar:"03",apr:"04",may:"05",jun:"06",
  jul:"07",aug:"08",sep:"09",oct:"10",nov:"11",dec:"12",
};
function monthSortKey(row) {
  const name = String(row.month_name || "").toLowerCase().slice(0, 3);
  const yr   = String(row.month_year || row.policy_year || "2022").slice(0, 4);
  const mn   = MONTH_NUM[name] || String(row.month || "01").padStart(2, "0");
  return `${yr}-${mn}`;
}

function buildAgeGroups(rows) {
  const bands = { "0-20":0, "21-30":0, "31-35":0, "36-40":0, "41-50":0, "51-60":0, "61+":0 };
  rows.forEach(r => {
    const ag = String(r.age_group || "").trim();
    if (ag && bands[ag] !== undefined) { bands[ag]++; return; }
    const a = Number(r.age) || 0;
    if      (a === 0) return;
    else if (a <= 20) bands["0-20"]++;
    else if (a <= 30) bands["21-30"]++;
    else if (a <= 35) bands["31-35"]++;
    else if (a <= 40) bands["36-40"]++;
    else if (a <= 50) bands["41-50"]++;
    else if (a <= 60) bands["51-60"]++;
    else              bands["61+"]++;
  });
  return bands;
}

function num(val) {
  if (val === null || val === undefined) return 0;
  const n = Number(String(val).replace(/[₱$,%\s]/g, "").replace(/,/g, ""));
  return isNaN(n) ? 0 : n;
}

// ── CHRONIC GROUPS (dynamic -- not hardcoded to any client) ─────
const CHRONIC_GROUP_MAP: Record<string, string[]> = {
  "Cardiovascular":      ["cardiovascular","cardiac","hypertension","heart","coronary","angina","arrhythmia","stroke","cerebrovascular"],
  "Diabetes & Metabolic":["diabetes","endocrine","metabolic","insulin","glycem","hyperglycemi","thyroid","obesity"],
  "Cancer & Neoplasms":  ["neoplasm","tumor","cancer","oncol","carcinoma","malignant","lymphoma","leukemia"],
  "Musculoskeletal":     ["musculoskeletal","arthri","musculo","osteo","gout","spinal","lumbar","cervical","scolio"],
  "Respiratory":         ["respiratory","asthma","copd","pulmonar","bronchit","emphysema","pneumonia","tuberculosis"],
  "Mental Health":       ["mental","psychi","depress","anxiety","bipolar","schizo","neurolog","parkinson","dementia","alzheimer"],
  "Renal & Digestive":   ["kidney","renal","digestive","liver","hepat","gastroint","ulcer","colitis","crohn","gallblad"],
  "Autoimmune":          ["autoimmune","lupus","rheumatoid","multiple sclerosis","inflammatory"],
};

// Flat list for backward-compat chronicPct calculation
const CHRONIC_KEYWORDS = Object.values(CHRONIC_GROUP_MAP).flat();
// ── RISK SCORE (fully dynamic formula) ─────────────────────────
function computeRiskScore({ chronicPct, trendPct, highCostPct, claimsPerMember }) {
  // Weights: chronic disease burden 35%, trend pressure 25%, high-cost exposure 25%, utilisation 15%
  const chronicScore   = Math.min(100, chronicPct * 1.67);
  const trendScore     = Math.min(100, Math.max(0, trendPct) * 3.33);
  const highCostScore  = Math.min(100, highCostPct * 5);
  const utilScore      = Math.min(100, claimsPerMember * 10);
  return Math.min(100, Math.round(
    chronicScore  * 0.35 +
    trendScore    * 0.25 +
    highCostScore * 0.25 +
    utilScore     * 0.15
  ));
}

// ── MAIN AGGREGATOR ─────────────────────────────────────────────
function aggregateClaimsToClients(rawClaimRows) {
  const claimRows = rawClaimRows.map(normalizeRow);

  // Group by entity
  const byEntity = {};
  for (const row of claimRows) {
    const entity = String(row.entity || "Unknown").trim();
    if (!entity || entity === "null" || entity === "Unknown") continue;
    if (!byEntity[entity]) byEntity[entity] = [];
    byEntity[entity].push(row);
  }

  const clients = [];

  for (const [entityName, rows] of Object.entries(byEntity)) {

    // ── 1. TOTALS ─────────────────────────────────────────────
    const totalClaims   = rows.length;
    const totalApproved = rows.reduce((s, r) => s + num(r.approved_amount || r.covered_amount), 0);
    const totalBilled   = rows.reduce((s, r) => s + num(r.billed_amount), 0);

    // ── 2. UNIQUE MEMBERS ─────────────────────────────────────
    const memberIdSet = new Set(
      rows.map(r => String(r.member_id || "").trim()).filter(Boolean)
    );
    const members = memberIdSet.size || Math.ceil(totalClaims / 4.2) || 1;

    // ── 3. MONTHLY PERIODS ────────────────────────────────────
    const monthKeys = new Set(rows.map(r => monthSortKey(r)).filter(k => k && k !== "-"));
    const numMonths = Math.max(monthKeys.size, 1);

    // ── 4. PMPM / PMPY ────────────────────────────────────────
    const pmpm = Math.round(totalApproved / members / numMonths);
    const pmpy = pmpm * 12;

    // ── 5. YoY COST TREND (vs prior policy year) ─────────────
    const byPolicyYear = {};
    rows.forEach(r => {
      const yr = String(r.policy_year || r.month_year || "").slice(0, 7);
      if (!yr) return;
      byPolicyYear[yr] = (byPolicyYear[yr] || 0) + num(r.approved_amount);
    });
    const pYears = Object.keys(byPolicyYear).sort();
    let trendPct = 0;
    if (pYears.length >= 2) {
      const prev = byPolicyYear[pYears[pYears.length - 2]] || 1;
      const curr = byPolicyYear[pYears[pYears.length - 1]] || 0;
      trendPct   = parseFloat(((curr - prev) / prev * 100).toFixed(1));
    }

    // ── 6. MONTHLY CHART (last 18 months) ────────────────────
    const monthlyMap = {};
    rows.forEach(r => {
      const key = monthSortKey(r);
      if (!key || key === "-") return;
      if (!monthlyMap[key]) monthlyMap[key] = { total: 0, label: "", count: 0 };
      monthlyMap[key].total += num(r.approved_amount);
      monthlyMap[key].count += 1;
      monthlyMap[key].label = `${r.month_name || ""} ${r.month_year || ""}`.trim() || key;
    });
    const sortedMonths = Object.keys(monthlyMap).sort().slice(-18);
    const chartLabels  = sortedMonths.map(k => monthlyMap[k].label);
    const chartValues  = sortedMonths.map(k => Math.round(monthlyMap[k].total / members));
    const chartCounts  = sortedMonths.map(k => monthlyMap[k].count);

    // ── 7. CLAIM TYPE ─────────────────────────────────────────
    const claimTypeCosts = {}, claimTypeCounts = {};
    rows.forEach(r => {
      const t = String(r.claim_type || "Other").trim();
      claimTypeCosts[t]  = (claimTypeCosts[t]  || 0) + num(r.approved_amount);
      claimTypeCounts[t] = (claimTypeCounts[t] || 0) + 1;
    });

    // ── 8. TOP ILLNESS GROUPS ─────────────────────────────────
    const illnessCostMap = {};
    rows.forEach(r => {
      const grp = String(r.illness_group || r.illness || r.icd_code || "Other").trim();
      if (!illnessCostMap[grp]) illnessCostMap[grp] = { cost:0, count:0, illnesses: new Set() };
      illnessCostMap[grp].cost  += num(r.approved_amount);
      illnessCostMap[grp].count += 1;
      if (r.illness) illnessCostMap[grp].illnesses.add(String(r.illness).trim());
    });
    const top5Diagnoses = Object.entries(illnessCostMap)
      .sort((a, b) => b[1].cost - a[1].cost).slice(0, 5)
      .map(([name, d]) => ({
        name, cost: Math.round(d.cost), count: d.count,
        pct: parseFloat((d.count / totalClaims * 100).toFixed(1)),
        topIllness: [...d.illnesses][0] || name,
      }));
    const top10DiagnosesChart = Object.entries(illnessCostMap)
      .sort((a, b) => b[1].cost - a[1].cost).slice(0, 10)
      .map(([name, d]) => ({ name, cost: Math.round(d.cost), count: d.count }));

    // ── 9. FACILITY UTILISATION ───────────────────────────────
    const facilityTypeCounts = {}, facilityCosts = {};
    rows.forEach(r => {
      const ft = String(r.facility_type || "Other").trim();
      facilityTypeCounts[ft] = (facilityTypeCounts[ft] || 0) + 1;
      facilityCosts[ft]      = (facilityCosts[ft]      || 0) + num(r.approved_amount);
    });

    // ── 10. HIGH-COST CLAIMANTS ───────────────────────────────
    const memberCostMap = {};
    rows.forEach(r => {
      const mid = String(r.member_id || "").trim();
      if (!mid) return;
      memberCostMap[mid] = (memberCostMap[mid] || 0) + num(r.approved_amount);
    });
    // MBL: use actual value from data, fallback 400000
    const mbl             = num(rows.find(r => r.mbl)?.mbl) || 400000;
    const allMemberCosts  = Object.values(memberCostMap).sort((a, b) => b - a);
    const highCostThresh  = mbl * 0.50;
    const highCostMembers = allMemberCosts.filter(c => c >= highCostThresh).length;
    const highCostPct     = members ? parseFloat((highCostMembers / members * 100).toFixed(1)) : 0;
    const topMemberCost   = allMemberCosts[0] || 0;
    const avgMemberCost   = members ? Math.round(totalApproved / members) : 0;
    const memberCostBands = {};
    // Dynamic bands based on MBL
    const b1 = Math.round(mbl * 0.125), b2 = Math.round(mbl * 0.25),
          b3 = Math.round(mbl * 0.5),   b4 = mbl;
    const fmt = n => `₱${n >= 1000 ? (n/1000).toFixed(0)+'k' : n}`;
    memberCostBands[`Below ${fmt(b1)}`]      = allMemberCosts.filter(c => c < b1).length;
    memberCostBands[`${fmt(b1)}-${fmt(b2)}`] = allMemberCosts.filter(c => c >= b1 && c < b2).length;
    memberCostBands[`${fmt(b2)}-${fmt(b3)}`] = allMemberCosts.filter(c => c >= b2 && c < b3).length;
    memberCostBands[`${fmt(b3)}-${fmt(b4)}`] = allMemberCosts.filter(c => c >= b3 && c < b4).length;
    memberCostBands[`${fmt(b4)}+ (MBL)`]     = allMemberCosts.filter(c => c >= b4).length;

    // ── 11. DEMOGRAPHICS ─────────────────────────────────────
    const ages   = rows.map(r => num(r.age)).filter(a => a > 0 && a < 100);
    const avgAge = ages.length ? Math.round(ages.reduce((s, a) => s + a, 0) / ages.length) : 0;

    const genderCounts = {};
    rows.forEach(r => {
      const g = String(r.gender || "Unknown").trim();
      genderCounts[g] = (genderCounts[g] || 0) + 1;
    });
    // Dynamic gender lookup -- handles Male/MALE/M etc
    const maleCount   = Object.entries(genderCounts).filter(([k]) => /^m(ale)?$/i.test(k)).reduce((s,[,v])=>s+v, 0);
    const femaleCount = Object.entries(genderCounts).filter(([k]) => /^f(emale)?$/i.test(k)).reduce((s,[,v])=>s+v, 0);
    const malePct     = totalClaims ? parseFloat((maleCount   / totalClaims * 100).toFixed(1)) : 0;
    const femalePct   = totalClaims ? parseFloat((femaleCount / totalClaims * 100).toFixed(1)) : 0;

    const relCounts = {};
    rows.forEach(r => {
      const rel = String(r.relationship || "Employee").trim();
      relCounts[rel] = (relCounts[rel] || 0) + 1;
    });
    const employeeCount  = Object.entries(relCounts).filter(([k]) => /^employee/i.test(k)).reduce((s,[,v])=>s+v, 0);
    const dependentCount = Object.entries(relCounts).filter(([k]) => !/^employee/i.test(k)).reduce((s,[,v])=>s+v, 0);
    const dependentRatio = employeeCount ? parseFloat((dependentCount / employeeCount).toFixed(2)) : 0;

    const civilStatusCounts = {};
    rows.forEach(r => {
      const cs = String(r.civil_status || "Unknown").trim();
      civilStatusCounts[cs] = (civilStatusCounts[cs] || 0) + 1;
    });

    // ── 12. PLAN LEVELS ───────────────────────────────────────
    const planLevelCounts = {}, planLevelCosts = {};
    rows.forEach(r => {
      const pl = String(r.plan_level || "Unknown").trim();
      planLevelCounts[pl] = (planLevelCounts[pl] || 0) + 1;
      planLevelCosts[pl]  = (planLevelCosts[pl]  || 0) + num(r.approved_amount);
    });
    const planLevelPmpm = {};
    Object.entries(planLevelCosts).forEach(([plan, cost]) => {
      const cnt = planLevelCounts[plan] || 1;
      planLevelPmpm[plan] = Math.round(cost / cnt / numMonths);
    });

    // ── 13. FUND ──────────────────────────────────────────────
    const fundCounts = {}, fundCosts = {};
    rows.forEach(r => {
      const f = String(r.fund || "HMO").trim();
      fundCounts[f] = (fundCounts[f] || 0) + 1;
      fundCosts[f]  = (fundCosts[f]  || 0) + num(r.approved_amount);
    });

    // ── 14. QUARTERLY ─────────────────────────────────────────
    const quarterCosts = {}, quarterCounts = {};
    rows.forEach(r => {
      const q = String(r.quarter || "").trim();
      if (!q) return;
      quarterCosts[q]  = (quarterCosts[q]  || 0) + num(r.approved_amount);
      quarterCounts[q] = (quarterCounts[q] || 0) + 1;
    });

    // ── 15. CHRONIC RATE (dynamic keyword matching) ───────────
    const chronicClaims = rows.filter(r =>
      CHRONIC_KEYWORDS.some(kw =>
        String(r.illness_group || r.illness || "").toLowerCase().includes(kw)
      )
    ).length;
    const chronicPct = totalClaims ? parseFloat((chronicClaims / totalClaims * 100).toFixed(1)) : 0;



 // ── CHRONIC GROUPING (ICD10 → named categories) ──────────
    const chronicGroupCounts: Record<string, number> = {};
    const chronicGroupCosts:  Record<string, number> = {};
    rows.forEach(r => {
      const txt = String(r.illness_group || r.illness || r.icd_code || "").toLowerCase();
      for (const [groupName, keywords] of Object.entries(CHRONIC_GROUP_MAP)) {
        if (keywords.some(kw => txt.includes(kw))) {
          chronicGroupCounts[groupName] = (chronicGroupCounts[groupName] || 0) + 1;
          chronicGroupCosts[groupName]  = (chronicGroupCosts[groupName]  || 0) + num(r.approved_amount);
          break; // assign to first matching group only
        }
      }
    });
    const chronicGroups = Object.entries(chronicGroupCounts)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => ({
        name,
        count,
        cost: Math.round(chronicGroupCosts[name] || 0),
        pct:  parseFloat((count / Math.max(totalClaims, 1) * 100).toFixed(1)),
      }));

    // ── RISK STRATIFICATION ───────────────────────────────────
    // Stratify each unique member into Low / Medium / High / Critical
    const memberRiskMap: Record<string, { cost: number; claims: number; chronic: boolean }> = {};
    rows.forEach(r => {
      const mid = String(r.member_id || "").trim();
      if (!mid) return;
      if (!memberRiskMap[mid]) memberRiskMap[mid] = { cost: 0, claims: 0, chronic: false };
      memberRiskMap[mid].cost   += num(r.approved_amount);
      memberRiskMap[mid].claims += 1;
      const txt = String(r.illness_group || r.illness || "").toLowerCase();
      if (CHRONIC_KEYWORDS.some(kw => txt.includes(kw))) memberRiskMap[mid].chronic = true;
    });

    const memberValues = Object.values(memberRiskMap);
    const totalMembers = memberValues.length || 1;
    const avgCostPerMember = memberValues.reduce((s, m) => s + m.cost, 0) / totalMembers;

    let riskCritical = 0, riskHigh = 0, riskMedium = 0, riskLow = 0;
    memberValues.forEach(m => {
      const costRatio = m.cost / Math.max(avgCostPerMember, 1);
      if      (m.chronic && costRatio >= 3) riskCritical++;
      else if (m.chronic || costRatio >= 2) riskHigh++;
      else if (costRatio >= 1.2)            riskMedium++;
      else                                  riskLow++;
    });

    const riskStratification = {
      critical: { count: riskCritical, pct: parseFloat((riskCritical / totalMembers * 100).toFixed(1)) },
      high:     { count: riskHigh,     pct: parseFloat((riskHigh     / totalMembers * 100).toFixed(1)) },
      medium:   { count: riskMedium,   pct: parseFloat((riskMedium   / totalMembers * 100).toFixed(1)) },
      low:      { count: riskLow,      pct: parseFloat((riskLow      / totalMembers * 100).toFixed(1)) },
    };

    // ── HIGH-COST SPEND CONCENTRATION ────────────────────────
    // Top 5% of members by cost → what % of total spend do they represent
    const allMemberCostsSorted = Object.values(memberRiskMap)
      .map(m => m.cost).sort((a, b) => b - a);
    const top5PctCount  = Math.max(1, Math.ceil(allMemberCostsSorted.length * 0.05));
    const top5PctSpend  = allMemberCostsSorted.slice(0, top5PctCount).reduce((s, v) => s + v, 0);
    const top5SpendPct  = totalApproved
      ? parseFloat((top5PctSpend / totalApproved * 100).toFixed(1)) : 0;
    // top10 for additional context
    const top10PctCount = Math.max(1, Math.ceil(allMemberCostsSorted.length * 0.10));
    const top10PctSpend = allMemberCostsSorted.slice(0, top10PctCount).reduce((s, v) => s + v, 0);
    const top10SpendPct = totalApproved
      ? parseFloat((top10PctSpend / totalApproved * 100).toFixed(1)) : 0;


    // ── 16. BILLED vs APPROVED ────────────────────────────────



    const billedApprovedRatio = totalBilled
      ? parseFloat((totalApproved / totalBilled * 100).toFixed(1)) : 100;

    // ── 17. RISK SCORE (dynamic) ──────────────────────────────
    const claimsPerMember = totalClaims / Math.max(members, 1);
    const riskScore = computeRiskScore({ chronicPct, trendPct, highCostPct, claimsPerMember });

    // ── 18. META ──────────────────────────────────────────────
    const latestPolicyYear = pYears[pYears.length - 1] || "";
    const branches   = [...new Set(rows.map(r => r.branch).filter(Boolean))];
    const category   = String(rows.find(r => r.category)?.category || "Staff").trim();
    const memberType = String(rows.find(r => r.member_type)?.member_type || "Employees").trim();

    const clientId = entityName.toLowerCase()
      .replace(/[^a-z0-9]/g, "_").replace(/_+/g, "_")
      .replace(/^_|_$/g, "").slice(0, 40);

    clients.push({
      id: clientId, name: entityName,
      members, pmpy, pmpm, trendPct, chronicPct, riskScore,
      totalCost: Math.round(totalApproved),
      totalBilled: Math.round(totalBilled),
      totalClaims, avgAge,
      industry: "HMO / Corporate Health",
      country: "Philippines", currency: "₱",
      meetingDate: "", manager: "", renewalDate: "", renewalOverdue: false,
      analytics: {
        totalApproved: Math.round(totalApproved),
        totalBilled:   Math.round(totalBilled),
        billedApprovedRatio, pmpm, pmpy, trendPct,
        numMonths, members, totalClaims,
        claimsPerMember: parseFloat(claimsPerMember.toFixed(1)),
        latestPolicyYear,
        costByPolicyYear: byPolicyYear,
        monthlyChart: { labels: chartLabels, pmpm: chartValues, count: chartCounts },
        claimTypeCosts, claimTypeCounts,
        claimTypeChart: {
          labels: Object.keys(claimTypeCounts),
          counts: Object.values(claimTypeCounts),
          costs:  Object.values(claimTypeCosts).map(Math.round),
        },
        top5Diagnoses, top10DiagnosesChart,
        diagnosisChart: {
          labels: top10DiagnosesChart.map(d => d.name),
          costs:  top10DiagnosesChart.map(d => d.cost),
          counts: top10DiagnosesChart.map(d => d.count),
        },
        mbl, highCostMembers, highCostPct,
        topMemberCost: Math.round(topMemberCost),
        avgMemberCost, memberCostBands,
        memberCostChart: {
          labels: Object.keys(memberCostBands),
          counts: Object.values(memberCostBands),
        },
        avgAge, ageGroups: buildAgeGroups(rows),
        ageGroupChart: {
          labels: Object.keys(buildAgeGroups(rows)),
          counts: Object.values(buildAgeGroups(rows)),
        },
        genderCounts, malePct, femalePct,
        genderChart: { labels: Object.keys(genderCounts), counts: Object.values(genderCounts) },
        relCounts, employeeCount, dependentCount, dependentRatio,
        civilStatusCounts, planLevelCounts, planLevelCosts, planLevelPmpm,
        planLevelChart: {
          labels: Object.keys(planLevelCosts),
          costs:  Object.values(planLevelCosts).map(Math.round),
          counts: Object.keys(planLevelCounts).map(k => planLevelCounts[k]),
          pmpm:   Object.keys(planLevelPmpm).map(k => planLevelPmpm[k]),
        },
        category, memberType, branches,
        facilityTypeCounts, facilityCosts,
        facilityChart: {
          labels: Object.keys(facilityTypeCounts),
          counts: Object.values(facilityTypeCounts),
          costs:  Object.keys(facilityCosts).map(k => Math.round(facilityCosts[k])),
        },
        fundCounts, fundCosts, chronicClaims, chronicPct,
        quarterCosts, quarterCounts,
        quarterChart: {
          labels: Object.keys(quarterCosts).sort(),
          costs:  Object.keys(quarterCosts).sort().map(k => Math.round(quarterCosts[k])),
          counts: Object.keys(quarterCounts).sort().map(k => quarterCounts[k]),
        },
        chronicGroups,
        riskStratification,
        top5SpendPct,
        top10SpendPct,
        top5PctCount,
      },
    });
  }

  clients.sort((a, b) => b.totalCost - a.totalCost);
  return clients;
}

module.exports = {
  normalizeRow, isClaimsLevelData, aggregateClaimsToClients,
  buildAgeGroups, monthSortKey,
};
