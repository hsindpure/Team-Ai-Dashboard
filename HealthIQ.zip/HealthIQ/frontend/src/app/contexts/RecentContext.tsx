import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { Client } from '../models/claims/client.model';

interface Ctx {
  recent: Client[];
  add: (c: Client) => void;
  clear: () => void;
}
const C = createContext<Ctx>({ recent: [], add: () => {}, clear: () => {} });
const KEY = 'ciq_recent_v3';

export function RecentProvider({ children }: { children: ReactNode }) {
  const [recent, setRecent] = useState<Client[]>(() => {
    try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
  });
  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(recent.slice(0, 8))); }, [recent]);
  const add = (c: Client) =>
    setRecent(p => [c, ...p.filter(r => r.id !== c.id)].slice(0, 8));
  const clear = () => setRecent([]);
  return <C.Provider value={{ recent, add, clear }}>{children}</C.Provider>;
}
export const useRecent = () => useContext(C);
