export { default } from './analysis-view';
