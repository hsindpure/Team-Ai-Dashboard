import type { Client } from './client.model';
import type { Story, Narrative } from './story.model';

export type DataSource = 'excel' | 'databricks' | 'mongodb';

export interface AppData {
  clients: Client[];
  stories: Story[];
  narratives: Record<string, Narrative>;
  dataSource?: DataSource;
  meta?: { source: DataSource; loadedAt: string; totalClients?: number };
}
