// ClaimsIQ Client Models -- fully dynamic, zero hardcoded fields

export interface RiskColor {
  bg: string;
  border: string;
  badge: string;
  label: 'High' | 'Medium' | 'Low';
  glow: string;
}

export interface DiagnosisEntry {
  name: string;
  count: number;
  pct: number;
  cost?: number;
  topIllness?: string;
}

export interface Analytics {
  // Core financials (all computed dynamically from claim rows)
  totalApproved: number;
  totalBilled?: number;
  totalClaims: number;
  pmpm: number;
  pmpy: number;
  numMonths?: number;
  avgAge: number;
  trendPct: number;
  billedApprovedRatio?: number;
  latestPolicyYear?: string;
  claimsPerMember?: number;

  // Chronic / risk
 chronicPct?: number;
  chronicClaims?: number;

  // Chronic condition groups (ICD10 mapped)
  chronicGroups?: {
    name: string;
    count: number;
    cost: number;
    pct: number;
  }[];

  // Risk stratification tiers
  riskStratification?: {
    critical: { count: number; pct: number };
    high:     { count: number; pct: number };
    medium:   { count: number; pct: number };
    low:      { count: number; pct: number };
  };

  // High-cost spend concentration
  top5SpendPct?:  number;
  top10SpendPct?: number;
  top5PctCount?:  number;

  // Demographics
  femalePct?: number;
  malePct?: number;
  dependentRatio?: number;
  employeeCount?: number;
  dependentCount?: number;
  genderCounts?: Record<string, number>;
  ageGroups?: Record<string, number>;
  civilStatusCounts?: Record<string, number>;
  relCounts?: Record<string, number>;
  category?: string;
  memberType?: string;
  branches?: string[];

  // High-cost
  highCostMembers?: number;
  highCostPct?: number;
  topMemberCost?: number;
  avgMemberCost?: number;
  mbl?: number;
  memberCostBands?: Record<string, number>;

  // Plans / fund
  planLevelCounts?: Record<string, number>;
  planLevelCosts?: Record<string, number>;
  planLevelPmpm?: Record<string, number>;
  fundCounts?: Record<string, number>;
  fundCosts?: Record<string, number>;

  // Facility / utilisation
  facilityTypeCounts?: Record<string, number>;
  facilityCosts?: Record<string, number>;

  // Claim type
  claimTypeCosts: Record<string, number>;
  claimTypeCounts?: Record<string, number>;

  // Quarterly
  quarterCosts?: Record<string, number>;
  quarterCounts?: Record<string, number>;

  // Policy year trend
  costByPolicyYear?: Record<string, number>;

  // Top diagnoses
  top5Diagnoses: DiagnosisEntry[];

  // Charts (all pre-built by calculator for direct rendering)
  monthlyChart:    { labels: string[]; pmpm: number[]; count: number[] };
  diagnosisChart?: { labels: string[]; costs: number[]; counts: number[] };
  claimTypeChart?: { labels: string[]; counts: number[]; costs: number[] };
  facilityChart?:  { labels: string[]; counts: number[]; costs: number[] };
  memberCostChart?:{ labels: string[]; counts: number[] };
  ageGroupChart?:  { labels: string[]; counts: number[] };
  genderChart?:    { labels: string[]; counts: number[] };
  planLevelChart?: { labels: string[]; costs: number[]; counts: number[]; pmpm: number[] };
  quarterChart?:   { labels: string[]; costs: number[]; counts: number[] };
  top10DiagnosesChart?: { name: string; cost: number; count: number }[];
}

export interface Client {
  id: string;
  name: string;
  members: number;
  pmpy: number;
  pmpm?: number;
  trendPct: number;
  chronicPct: number;
  riskScore: number;
  totalCost: number;
  totalClaims?: number;
  industry: string;
  country: string;
  currency: string;
  meetingDate?: string;
  manager?: string;
  renewalDate?: string;
  renewalOverdue?: boolean;
  planType?: string;
  analytics?: Analytics;
  [key: string]: unknown;
}
