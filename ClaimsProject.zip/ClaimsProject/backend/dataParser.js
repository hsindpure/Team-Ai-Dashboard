/**
 * dataParser.js — HMO Claims Data Parser & Aggregator
 * ─────────────────────────────────────────────────────
 *
 * Designed for Philippine HMO insurance claim-level data with fields:
 *   Policy_Year, Month, Fund, Final_Claim_Type, Member_Type, Relationship,
 *   ICD_Code2, Illness, Illness_Group, Facility, Type_of_Facility,
 *   Case_Tag, Case_Count, Plan_Level, Age, Billed_Amount, Covered_Amount,
 *   APPROVEDAMOUNT, Entity, Branch, Claim_No, Masked_Employee_ID,
 *   Masked_Member_ID, Admission_Date, Discharge_Date, Year_of_Birth,
 *   Gender, Civil_Status, Status, MBL, FileName, Age_Group,
 *   Plan_Description, Category, Month_Name, Month_Year, New_Quarter
 *
 * Each row = one claim. Aggregated by "Entity" (company name)
 * to produce one client record per company with rich analytics.
 *
 * Exports:
 *   parseXlsx(filePath)  → populates cache, returns it
 *   getCache()           → { clients, stories, narratives, claimsData, meta }
 *   clearCache()
 *   startWatcher(path)
 */

const path       = require("path");
const XLSX       = require("xlsx");
const chokidar   = require("chokidar");
const {
  aggregateClaimsToClients,
  isClaimsLevelData,
  normalizeRow,
} = require("./claimsCalculator");

let cache = null;

// ─────────────────────────────────────────────────────────────
// LOW-LEVEL HELPERS
// ─────────────────────────────────────────────────────────────

function sanitizeKey(key) {
  return String(key).trim().toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "");
}

function castValue(val) {
  if (val === null || val === undefined || val === "") return null;
  if (typeof val === "number") return val;
  const str = String(val).trim();
  const num = Number(str.replace(/[₱$,%]/g, "").replace(/,/g, ""));
  if (!isNaN(num) && str !== "") return num;
  return str;
}

function readSheet(workbook, sheetName) {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) return [];
  const raw = XLSX.utils.sheet_to_json(sheet, { defval: null, raw: false, header: 1 });
  if (raw.length < 2) return [];
  const headers = raw[0].map((h, i) => h ? sanitizeKey(h) : `col_${i}`);
  return raw.slice(1)
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => { obj[h] = castValue(row[i]); });
      return obj;
    })
    .filter(r => Object.values(r).some(v => v !== null && v !== ""));
}

// Detection, month keys, age groups, aggregation — all in claimsCalculator.js

// ─────────────────────────────────────────────────────────────
// BUILD NARRATIVES
// Reads optional sheets: narratives, metrics, chart_data
// Returns { [storyId]: { headline, insight, so_what, talking_points,
//                        metrics, chart, chartColor } }
// ─────────────────────────────────────────────────────────────
function buildNarratives(allSheets) {
  const narratives = {};

  // ── narratives sheet ─────────────────────────────────────
  const narRows = allSheets["narratives"] || allSheets["narrative"] || [];
  narRows.forEach(r => {
    const id = String(r.story_id || r.id || "").trim();
    if (!id) return;
    narratives[id] = {
      headline:       String(r.headline       || ""),
      insight:        String(r.insight        || ""),
      so_what:        String(r.so_what        || r.sowhat || ""),
      talking_points: String(r.talking_points || r.talkingpoints || "")
        .split("|").map(s => s.trim()).filter(Boolean),
      metrics:    [],
      chart:      { labels: [], values: [] },
      chartColor: String(r.chart_color || r.chartcolor || "#c8830a"),
    };
  });

  // ── metrics sheet ─────────────────────────────────────────
  const metRows = allSheets["metrics"] || allSheets["kpis"] || [];
  metRows.forEach(r => {
    const id = String(r.story_id || r.id || "").trim();
    if (!id || !narratives[id]) return;
    narratives[id].metrics.push({
      label: String(r.label || ""),
      value: String(r.value || ""),
      delta: r.delta != null ? String(r.delta) : undefined,
      bench: r.bench != null ? String(r.bench) : undefined,
      benchLabel: r.bench_label ? String(r.bench_label) : undefined,
      dir:   String(r.dir || "neutral"),
    });
  });

  // ── chart_data sheet ─────────────────────────────────────
  const chartRows = allSheets["chart_data"] || allSheets["chartdata"] || [];
  chartRows.forEach(r => {
    const id = String(r.story_id || r.id || "").trim();
    if (!id || !narratives[id]) return;
    narratives[id].chart.labels.push(String(r.label || r.period || ""));
    narratives[id].chart.values.push(Number(r.value || r.amount || 0));
    if (r.bench != null)
      (narratives[id].chart.bench = narratives[id].chart.bench || []).push(Number(r.bench));
  });

  return narratives;
}

// ─────────────────────────────────────────────────────────────
// MAIN PARSE
// ─────────────────────────────────────────────────────────────
function parseXlsx(filePath) {
  const absPath = path.resolve(filePath);
  console.log(`[parser] Reading: ${absPath}`);

  const workbook   = XLSX.readFile(absPath);
  const sheetNames = workbook.SheetNames;
  console.log(`[parser] Sheets: ${sheetNames.join(", ")}`);

  const allSheets = {};
  sheetNames.forEach(name => {
    allSheets[sanitizeKey(name)] = readSheet(workbook, name);
  });

  const KNOWN_PRIMARY = [
    "insurance_indicators","insuranceindicators","claims_data","claimsdata",
    "data","claims","sheet1","clients","client","accounts","insurance_data",
  ];
  const primaryKey  = KNOWN_PRIMARY.find(k => allSheets[k]) || sanitizeKey(sheetNames[0]);
  const primaryRows = allSheets[primaryKey] || [];

  console.log(`[parser] Primary: "${primaryKey}" | ${primaryRows.length} rows`);
  if (primaryRows.length > 0) {
    console.log(`[parser] Columns: ${Object.keys(primaryRows[0]).join(", ")}`);
    console.log(`[parser] Sample:  ${JSON.stringify(primaryRows[0]).slice(0, 350)}`);
  }

  let clients, claimsData = null;

  if (isClaimsLevelData(primaryRows)) {
    console.log(`[parser] 🔍 HMO claim-level data — aggregating by Entity...`);
    clients    = aggregateClaimsToClients(primaryRows);
    claimsData = primaryRows;
    console.log(`[parser] ✅ ${primaryRows.length} claims → ${clients.length} companies`);
  } else {
    console.log(`[parser] 📊 Pre-summarised client data`);
    const keys  = Object.keys(primaryRows[0] || {});
    const idCol = ["id","client_id","clientid","client_code","code"].find(k => keys.includes(k)) || keys[0];
    clients = primaryRows.map((r, i) => ({
      id: r[idCol] != null ? String(r[idCol]) : `client_${i}`,
      ...r,
    }));
  }

  const storyRows = allSheets["stories"] || allSheets["story_templates"] || [];
  const stories   = storyRows.map(r => ({
    id: String(r.id || r.story_id || ""), icon: String(r.icon || "📊"),
    label: String(r.label || ""), desc: String(r.desc || r.description || ""),
  }));

  const narratives = buildNarratives(allSheets);

  cache = {
    clients, stories, narratives, claimsData, sheets: allSheets,
    meta: {
      sheetNames, primaryKey,
      parsedAt:     new Date().toISOString(),
      filePath:     absPath,
      totalClients: clients.length,
      totalClaims:  claimsData ? claimsData.length : null,
      dataFormat:   claimsData ? "hmo-claims-level" : "summarised",
      currency:     "₱",
    },
  };

  console.log(`[parser] ✅ Done — ${clients.length} clients | format: ${cache.meta.dataFormat}`);
  return cache;
}

function getCache() {
  if (!cache) throw new Error("Data not loaded — call parseXlsx() first.");
  return cache;
}
function clearCache() { cache = null; console.log("[parser] Cache cleared."); }

function startWatcher(filePath) {
  const watcher = chokidar.watch(filePath, {
    persistent: true, ignoreInitial: true,
    awaitWriteFinish: { stabilityThreshold: 800, pollInterval: 100 },
  });
  watcher.on("change", () => {
    console.log("[watcher] 📄 Changed — reloading...");
    clearCache();
    try { parseXlsx(filePath); console.log("[watcher] ✅ Reloaded."); }
    catch (e) { console.error("[watcher] ❌", e.message); }
  });
  watcher.on("error", err => console.error("[watcher]", err));
  console.log(`[watcher] 👁  Watching: ${path.resolve(filePath)}`);
}

module.exports = { parseXlsx, getCache, clearCache, startWatcher };