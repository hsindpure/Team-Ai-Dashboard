/**
 * databricksConnector.js — Databricks SQL Data Source
 * ─────────────────────────────────────────────────────
 *
 * Fallback data source when Excel file is not available.
 * Connects to Databricks SQL Warehouse using @databricks/sql,
 * fetches claim-level data, and produces the same client analytics
 * structure as dataParser.js using the shared claimsCalculator.js.
 *
 * Connection (from .env or hardcoded fallback):
 *   DATABRICKS_TOKEN         = dap1ce60ce690556e760d3794abd7cd3800c
 *   DATABRICKS_SERVER_HOSTNAME = dbc-85bb0ad0-a3c5.cloud.databricks.com
 *   DATABRICKS_HTTP_PATH     = /sql/1.0/warehouses/0c6eb0dcfe64781d
 *   DATABRICKS_TABLE         = your_catalog.your_schema.claims_table
 *
 * Install dependency:
 *   npm install @databricks/sql
 *
 * Exports:
 *   isDatabricksConfigured()          → boolean
 *   fetchClaimsFromDatabricks()       → array of raw claim rows
 *   loadDatabricksData()              → { clients, stories, narratives, meta }
 *   testDatabricksConnection()        → { success, message, rowCount? }
 */

const { aggregateClaimsToClients, isClaimsLevelData, normalizeRow } = require("./claimsCalculator");

// ─────────────────────────────────────────────────────────────
// CONFIG — reads from .env, falls back to values from image
// ─────────────────────────────────────────────────────────────
const DB_CONFIG = {
  token:    process.env.DATABRICKS_TOKEN          || "dap1ce60ce690556e760d3794abd7cd3800c",
  host:     process.env.DATABRICKS_SERVER_HOSTNAME || "dbc-85bb0ad0-a3c5.cloud.databricks.com",
  path:     process.env.DATABRICKS_HTTP_PATH       || "/sql/1.0/warehouses/0c6eb0dcfe64781d",
  // Table to query — set DATABRICKS_TABLE in .env
  // Format: "catalog.schema.table_name"
  table:    process.env.DATABRICKS_TABLE           || null,
  // Optional: filter by policy year (e.g. "2022-23,2023-24")
  years:    process.env.DATABRICKS_POLICY_YEARS    || null,
  // Max rows to fetch per query (large datasets: use 500000+)
  maxRows:  parseInt(process.env.DATABRICKS_MAX_ROWS || "500000"),
};

// ─────────────────────────────────────────────────────────────
// DATABRICKS SQL CLIENT LOADER
// Lazy-loads @databricks/sql so the server starts even if the
// package is not yet installed (Excel-only mode still works).
// ─────────────────────────────────────────────────────────────
let DBSQLClient = null;
function getDBClient() {
  if (!DBSQLClient) {
    try {
      DBSQLClient = require("@databricks/sql").DBSQLClient;
    } catch (e) {
      throw new Error(
        "@databricks/sql not installed. Run: npm install @databricks/sql\n" +
        "Then restart the server."
      );
    }
  }
  return new DBSQLClient();
}

// ─────────────────────────────────────────────────────────────
// CONFIG CHECKER
// ─────────────────────────────────────────────────────────────
function isDatabricksConfigured() {
  return !!(DB_CONFIG.token && DB_CONFIG.host && DB_CONFIG.path);
}

function isDatabricksTableSet() {
  return !!(DB_CONFIG.table);
}

// ─────────────────────────────────────────────────────────────
// QUERY BUILDER
// Builds the SQL query for the claims table.
// Handles large datasets by using efficient column selection.
// ─────────────────────────────────────────────────────────────
function buildClaimsQuery(tableName, options = {}) {
  const { years, limit } = options;

  // Core columns matching our known HMO claims schema
  // Uses COALESCE to handle different column naming conventions
  const columns = `
    Policy_Year,
    Month,
    Month_Name,
    Month_Year,
    New_Quarter,
    Fund,
    Final_Claim_Type,
    Member_Type,
    Relationship,
    ICD_Code2,
    Illness,
    Illness_Group,
    Facility,
    Type_of_Facility,
    Case_Count,
    Plan_Level,
    Plan_Description,
    Age,
    Age_Group,
    Billed_Amount,
    Covered_Amount,
    APPROVEDAMOUNT,
    Entity,
    Branch,
    Claim_No,
    Masked_Employee_ID,
    Masked_Member_ID,
    Year_of_Birth,
    Gender,
    Civil_Status,
    Status,
    MBL,
    Category
  `.trim();

  let sql = `SELECT ${columns} FROM ${tableName}`;

  // Filter by policy years if specified
  if (years && years.length > 0) {
    const yearList = years.map(y => `'${y}'`).join(", ");
    sql += ` WHERE Policy_Year IN (${yearList})`;
  }

  // Always order for consistent pagination
  sql += ` ORDER BY Entity, Policy_Year, Month`;

  if (limit) {
    sql += ` LIMIT ${limit}`;
  }

  return sql;
}

// ─────────────────────────────────────────────────────────────
// SCHEMA DISCOVERY
// When DATABRICKS_TABLE is not set, try to find the claims table
// ─────────────────────────────────────────────────────────────
async function discoverClaimsTable(session) {
  console.log("[databricks] 🔍 Discovering available tables...");
  try {
    const op = await session.executeStatement("SHOW TABLES", { runAsync: true, maxRows: 100 });
    const tables = await op.fetchAll();
    await op.close();

    const tableNames = tables.map(t =>
      `${t.catalog || t.database || ""}.${t.namespace || t.schema || ""}.${t.tableName || t.name || ""}`.replace(/^\.+|\.+$/g, "")
    );

    // Look for a table with 'claims' or 'insurance' in the name
    const claimsTable = tableNames.find(t =>
      /claims|insurance|hmo|indicators/i.test(t)
    );

    if (claimsTable) {
      console.log(`[databricks] ✅ Discovered table: ${claimsTable}`);
      return claimsTable;
    }

    console.log("[databricks] Tables found:", tableNames.slice(0, 10));
    return tableNames[0] || null;
  } catch (e) {
    console.warn("[databricks] Table discovery failed:", e.message);
    return null;
  }
}

// ─────────────────────────────────────────────────────────────
// FETCH CLAIMS DATA FROM DATABRICKS
// Connects, queries, normalizes, returns raw claim rows
// ─────────────────────────────────────────────────────────────
async function fetchClaimsFromDatabricks() {
  if (!isDatabricksConfigured()) {
    throw new Error("Databricks not configured. Set DATABRICKS_TOKEN, DATABRICKS_SERVER_HOSTNAME, DATABRICKS_HTTP_PATH in .env");
  }

  console.log("[databricks] 🔌 Connecting to:", DB_CONFIG.host);

  const client = getDBClient();
  await client.connect({
    token:  DB_CONFIG.token,
    host:   DB_CONFIG.host,
    path:   DB_CONFIG.path,
  });

  const session = await client.openSession();
  console.log("[databricks] ✅ Session opened");

  try {
    // Discover table if not set
    let tableName = DB_CONFIG.table;
    if (!tableName) {
      tableName = await discoverClaimsTable(session);
      if (!tableName) {
        throw new Error(
          "No table found. Set DATABRICKS_TABLE=catalog.schema.table_name in backend/.env"
        );
      }
    }

    // Parse policy year filter
    const years = DB_CONFIG.years
      ? DB_CONFIG.years.split(",").map(y => y.trim())
      : null;

    const sql = buildClaimsQuery(tableName, { years, limit: DB_CONFIG.maxRows });
    console.log(`[databricks] 📊 Querying: ${tableName}`);
    console.log(`[databricks] SQL: ${sql.slice(0, 200)}...`);

    const queryOp = await session.executeStatement(sql, {
      runAsync:  true,
      maxRows:   DB_CONFIG.maxRows,
    });

    const rawRows = await queryOp.fetchAll();
    await queryOp.close();

    console.log(`[databricks] ✅ Fetched ${rawRows.length.toLocaleString()} rows`);
    return rawRows;

  } finally {
    await session.close();
    await client.close();
    console.log("[databricks] 🔌 Connection closed");
  }
}

// ─────────────────────────────────────────────────────────────
// LOAD AND AGGREGATE
// Full pipeline: connect → fetch → aggregate → return cache-ready object
// ─────────────────────────────────────────────────────────────
async function loadDatabricksData() {
  const startTime = Date.now();
  console.log("[databricks] 🚀 Starting data load...");

  const rawRows = await fetchClaimsFromDatabricks();

  if (!rawRows || rawRows.length === 0) {
    throw new Error("Databricks returned 0 rows. Check table name and filters.");
  }

  // Validate it's claim-level data
  const sample = rawRows.slice(0, 5);
  const normalized = sample.map(normalizeRow);
  if (!isClaimsLevelData(normalized)) {
    console.warn("[databricks] ⚠️  Data may not be HMO claim-level format — attempting aggregation anyway");
  }

  // Aggregate using shared calculator
  console.log(`[databricks] ⚙️  Aggregating ${rawRows.length.toLocaleString()} claims by Entity...`);
  const clients = aggregateClaimsToClients(rawRows);

  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log(`[databricks] ✅ Done — ${clients.length} clients from ${rawRows.length.toLocaleString()} claims in ${elapsed}s`);

  return {
    clients,
    stories:    [],
    narratives: {},
    claimsData: rawRows,   // keep raw for drill-downs
    sheets:     {},
    meta: {
      source:        "databricks",
      host:          DB_CONFIG.host,
      table:         DB_CONFIG.table || "auto-discovered",
      parsedAt:      new Date().toISOString(),
      totalClients:  clients.length,
      totalClaims:   rawRows.length,
      dataFormat:    "hmo-claims-level",
      currency:      "₱",
      loadTimeSeconds: parseFloat(elapsed),
    },
  };
}

// ─────────────────────────────────────────────────────────────
// CONNECTION TEST
// Lightweight ping — just connects and runs SELECT 1
// ─────────────────────────────────────────────────────────────
async function testDatabricksConnection() {
  if (!isDatabricksConfigured()) {
    return {
      success: false,
      message: "Databricks credentials not configured in .env",
      configured: false,
    };
  }

  try {
    const client = getDBClient();
    await client.connect({
      token: DB_CONFIG.token,
      host:  DB_CONFIG.host,
      path:  DB_CONFIG.path,
    });
    const session = await client.openSession();

    // Quick row count if table is known
    let rowCount = null;
    if (DB_CONFIG.table) {
      try {
        const op = await session.executeStatement(
          `SELECT COUNT(*) as cnt FROM ${DB_CONFIG.table}`,
          { runAsync: true, maxRows: 1 }
        );
        const result = await op.fetchAll();
        await op.close();
        rowCount = result[0]?.cnt || result[0]?.["count(1)"] || null;
      } catch (e) {
        console.warn("[databricks] Count query failed:", e.message);
      }
    }

    await session.close();
    await client.close();

    return {
      success:    true,
      message:    "Databricks connection successful",
      configured: true,
      host:       DB_CONFIG.host,
      table:      DB_CONFIG.table || "not set",
      rowCount,
    };
  } catch (e) {
    return {
      success:    false,
      message:    e.message,
      configured: true,
      hint: e.message.includes("@databricks/sql")
        ? "Run: npm install @databricks/sql in the backend folder"
        : "Check your Databricks credentials in backend/.env",
    };
  }
}

module.exports = {
  isDatabricksConfigured,
  isDatabricksTableSet,
  fetchClaimsFromDatabricks,
  loadDatabricksData,
  testDatabricksConnection,
  DB_CONFIG,
};