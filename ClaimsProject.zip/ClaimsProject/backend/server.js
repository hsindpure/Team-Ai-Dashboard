/**
 * server.js — Marsh ClaimsIQ API Server
 * ───────────────────────────────────────
 *
 * Data Sources (priority order):
 *   1. Excel (.xlsx) — primary, auto-detected at boot
 *   2. Databricks SQL — fallback if Excel not found or FORCE_DATABRICKS=true
 *
 * All KPI/chart calculations handled by claimsCalculator.js (shared)
 *
 * Routes:
 *   GET    /api/health
 *   GET    /api/source                  → which data source is active
 *   GET    /api/all                     → clients + stories + narratives + meta
 *   GET    /api/clients
 *   GET    /api/client/:id
 *   GET    /api/sheets
 *   POST   /api/reload                  → re-load from active source
 *   POST   /api/reload/excel            → force reload from Excel
 *   POST   /api/reload/databricks       → force reload from Databricks
 *   GET    /api/databricks/status       → test Databricks connection
 *   POST   /api/ai/analyze
 *   GET    /api/ai/cache
 *   DELETE /api/ai/cache
 *   GET    /api/debug/columns
 */

require("dotenv").config();

const express = require("express");
const cors    = require("cors");
const path    = require("path");
const fs      = require("fs");

const { parseXlsx, getCache, clearCache, startWatcher } = require("./dataParser");
const { generateAiAnalysis, clearAiCache, getAiCacheStatus, deleteAiCacheEntry } = require("./aiAnalyzer");
const { loadDatabricksData, testDatabricksConnection, isDatabricksConfigured } = require("./databricksConnector");

// ─────────────────────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────────────────────
const app       = express();
const PORT      = process.env.PORT        || 3001;
const XLSX_PATH = process.env.XLSX_FILE   || "dataFile/claimsiq_data.xlsx";
const FORCE_DB  = process.env.FORCE_DATABRICKS === "true";

// Active data source tracking
let activeSource    = "none";
let databricksCache = null;

// ─────────────────────────────────────────────────────────────
// MIDDLEWARE
// ─────────────────────────────────────────────────────────────
app.use(cors({
  origin: ["http://localhost:3000", "http://localhost:3001"],
  credentials: true,
}));
app.use(express.json());

if (process.env.NODE_ENV !== "production") {
  app.use((req, _res, next) => {
    console.log(`[${new Date().toTimeString().slice(0,8)}] ${req.method} ${req.url}`);
    next();
  });
}

// ─────────────────────────────────────────────────────────────
// DATA SOURCE HELPERS
// ─────────────────────────────────────────────────────────────

function getActiveCache() {
  if (activeSource === "databricks" && databricksCache) return databricksCache;
  return getCache();
}

function loadExcel() {
  const absPath = path.resolve(XLSX_PATH);
  if (!fs.existsSync(absPath)) return false;
  try {
    parseXlsx(XLSX_PATH);
    activeSource = "excel";
    console.log(`[boot] ✅ Excel loaded: ${absPath}`);
    return true;
  } catch (e) {
    console.error("[boot] Excel parse failed:", e.message);
    return false;
  }
}

async function loadDatabricks() {
  if (!isDatabricksConfigured()) {
    console.warn("[boot] Databricks not configured — skipping");
    return false;
  }
  try {
    databricksCache = await loadDatabricksData();
    activeSource = "databricks";
    console.log(`[boot] ✅ Databricks loaded: ${databricksCache.meta.totalClients} clients`);
    return true;
  } catch (e) {
    console.error("[boot] Databricks load failed:", e.message);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────
// ROUTES — System
// ─────────────────────────────────────────────────────────────

app.get("/api/health", (_req, res) => {
  res.json({ success: true, status: "ok", time: new Date().toISOString(), dataSource: activeSource });
});

app.get("/api/source", (_req, res) => {
  let meta = {};
  try { meta = getActiveCache().meta || {}; } catch (e) {}
  res.json({
    success: true, activeSource,
    xlsxAvailable:        fs.existsSync(path.resolve(XLSX_PATH)),
    databricksConfigured: isDatabricksConfigured(),
    meta,
  });
});

app.get("/api/databricks/status", async (_req, res) => {
  const result = await testDatabricksConnection();
  res.json(result);
});

// ─────────────────────────────────────────────────────────────
// ROUTES — Data
// ─────────────────────────────────────────────────────────────

app.get("/api/all", (_req, res) => {
  try {
    const { clients, stories, narratives, meta } = getActiveCache();
    res.json({ success: true, clients, stories, narratives, meta, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get("/api/clients", (_req, res) => {
  try {
    const { clients } = getActiveCache();
    res.json({ success: true, count: clients.length, data: clients, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get("/api/client/:id", (req, res) => {
  try {
    const { clients } = getActiveCache();
    const client = clients.find(c => String(c.id).toLowerCase() === req.params.id.toLowerCase());
    if (!client) return res.status(404).json({ success: false, error: `Client "${req.params.id}" not found.` });
    res.json({ success: true, data: client, dataSource: activeSource });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.get("/api/sheets", (_req, res) => {
  try {
    const { sheets } = getActiveCache();
    res.json({
      success: true, dataSource: activeSource,
      sheets: Object.keys(sheets).map(key => ({ key, count: sheets[key].length })),
    });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.post("/api/reload", async (req, res) => {
  try {
    clearAiCache();
    if (activeSource === "databricks") {
      databricksCache = null;
      await loadDatabricks();
    } else {
      clearCache();
      parseXlsx(XLSX_PATH);
    }
    res.json({ success: true, message: `Reloaded from ${activeSource}.`, meta: getActiveCache().meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post("/api/reload/excel", (req, res) => {
  try {
    clearCache(); clearAiCache();
    const ok = loadExcel();
    if (!ok) return res.status(404).json({ success: false, error: `Excel not found: ${path.resolve(XLSX_PATH)}` });
    res.json({ success: true, message: "Reloaded from Excel.", meta: getActiveCache().meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post("/api/reload/databricks", async (req, res) => {
  try {
    clearAiCache(); databricksCache = null;
    const ok = await loadDatabricks();
    if (!ok) return res.status(500).json({ success: false, error: "Databricks load failed — check logs." });
    res.json({ success: true, message: "Reloaded from Databricks.", meta: databricksCache.meta });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────
// ROUTES — AI Analysis
// ─────────────────────────────────────────────────────────────

app.post("/api/ai/analyze", async (req, res) => {
  const { clientId, storyId, forceRefresh = false } = req.body;
  if (!clientId || !storyId) {
    return res.status(400).json({ success: false, error: "Both clientId and storyId are required." });
  }

  let cacheData;
  try { cacheData = getActiveCache(); }
  catch (e) { return res.status(503).json({ success: false, error: e.message }); }

  const client = cacheData.clients.find(c => String(c.id).toLowerCase() === String(clientId).toLowerCase());
  if (!client) return res.status(404).json({ success: false, error: `Client "${clientId}" not found.` });

  const xlsxMetrics = cacheData.narratives?.[storyId]?.metrics || [];
  if (forceRefresh) deleteAiCacheEntry(`${clientId}_${storyId}`);

  try {
    const result = await generateAiAnalysis({ client, storyId, xlsxMetrics });
    res.json({ success: true, clientId, storyId, fromCache: result.fromCache, dataSource: activeSource, analysis: result });
  } catch (e) {
    console.error("[ai/analyze]", e.message);
    res.status(500).json({
      success: false, error: e.message,
      hint: e.message.includes("OPENROUTER_API_KEY")
        ? "Add your key to backend/.env — free at https://openrouter.ai"
        : "AI generation failed — check backend logs.",
    });
  }
});

app.get("/api/ai/cache", (_req, res) => res.json({ success: true, ...getAiCacheStatus() }));
app.delete("/api/ai/cache", (_req, res) => { clearAiCache(); res.json({ success: true, message: "AI cache cleared." }); });

// ─────────────────────────────────────────────────────────────
// DEBUG
// ─────────────────────────────────────────────────────────────
app.get("/api/debug/columns", (_req, res) => {
  try {
    const cache = getActiveCache();
    const result = {};
    Object.entries(cache.sheets || {}).forEach(([k, rows]) => {
      result[k] = { rowCount: rows.length, columns: rows.length ? Object.keys(rows[0]) : [], sample: rows[0] };
    });
    res.json({
      success: true, dataSource: activeSource,
      totalClients: cache.clients.length,
      firstClientName: cache.clients[0]?.name,
      firstClientAnalyticsKeys: cache.clients[0]?.analytics ? Object.keys(cache.clients[0].analytics) : [],
      sheets: result, meta: cache.meta,
    });
  } catch (e) {
    res.status(503).json({ success: false, error: e.message });
  }
});

app.use((req, res) => res.status(404).json({ success: false, error: `Route not found: ${req.method} ${req.url}` }));
app.use((err, _req, res, _next) => {
  console.error("[server]", err);
  res.status(500).json({ success: false, error: "Internal server error." });
});

// ─────────────────────────────────────────────────────────────
// BOOT
// ─────────────────────────────────────────────────────────────
async function boot() {
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("  Marsh ClaimsIQ — API Server");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

  const xlsxExists = fs.existsSync(path.resolve(XLSX_PATH));

  // ── RULE: If Excel file exists → always use it, Databricks is never
  //          touched. Only when Excel is absent (or FORCE_DATABRICKS=true)
  //          do we connect to Databricks.
  if (!FORCE_DB && xlsxExists) {
    // ── Excel path — Databricks completely skipped ───────
    console.log(`[boot] 📊 Excel file found — Databricks skipped`);
    console.log(`[boot]    ${path.resolve(XLSX_PATH)}`);

    const ok = loadExcel();
    if (!ok) {
      console.error("❌  Excel file found but failed to parse.");
      console.error(`    Check the file is a valid .xlsx: ${path.resolve(XLSX_PATH)}`);
      process.exit(1);
    }
    startWatcher(XLSX_PATH);

  } else {
    // ── Databricks path — only reached when Excel is absent ─
    if (FORCE_DB) {
      console.log("[boot] 🔁 FORCE_DATABRICKS=true — connecting Databricks");
    } else {
      console.log(`[boot] ⚠️  No Excel at: ${path.resolve(XLSX_PATH)}`);
      console.log("[boot] 🔄 Connecting to Databricks...");
    }
    const ok = await loadDatabricks();
    if (!ok) {
      console.error("❌  Databricks failed. No Excel file present either.");
      console.error(`    Option A: Place .xlsx at backend/${XLSX_PATH}`);
      console.error(`    Option B: Set DATABRICKS_TABLE in backend/.env`);
      process.exit(1);
    }
  }

  // AI key check
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey || apiKey === "your_openrouter_api_key_here") {
    console.warn("⚠️   OPENROUTER_API_KEY not set — AI analysis disabled");
    console.warn("    Get a free key at https://openrouter.ai\n");
  } else {
    console.log(`🤖  AI model: ${process.env.OPENROUTER_MODEL || "mistralai/mistral-7b-instruct"}`);
  }

  app.listen(PORT, () => {
    console.log(`\n✅  Server running → http://localhost:${PORT}`);
    console.log(`📦  Data source: ${activeSource.toUpperCase()}\n`);
    console.log("  Routes:");
    ["GET /api/health","GET /api/source","GET /api/all","GET /api/clients",
     "GET /api/client/:id","POST /api/reload","POST /api/reload/excel",
     "POST /api/reload/databricks","GET /api/databricks/status",
     "POST /api/ai/analyze","GET /api/ai/cache","DELETE /api/ai/cache"].forEach(r => {
      const [m, ...p] = r.split(" ");
      console.log(`    ${m.padEnd(7)} ${p.join(" ")}`);
    });
    console.log();
  });
}

boot();