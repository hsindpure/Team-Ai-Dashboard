import { useState, useEffect, useCallback, useRef } from "react";
import {
  ResponsiveContainer,
  LineChart, Line,
  BarChart, Bar,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import NavBar from "./NavBar";
import { fetchAiAnalysis } from "../api";

// ─────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────
const fmt = (n) => `₱${Number(n || 0).toLocaleString()}`;
const fmtK = (n) => {
  const v = Number(n || 0);
  if (v >= 1_000_000) return `₱${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000)     return `₱${(v / 1_000).toFixed(0)}k`;
  return `₱${v}`;
};

const CHART_COLORS = [
  "#000f47", "#1a56db", "#c8830a", "#b83020",
  "#2a6832", "#9c27b0", "#0097a7", "#e65100",
  "#4a148c", "#006064",
];

// ─────────────────────────────────────────────────────────────
// AI HOOK
// ─────────────────────────────────────────────────────────────
function useAiAnalysis(clientId, storyId) {
  const [analysis,     setAnalysis]     = useState(null);
  const [loading,      setLoading]      = useState(false);
  const [error,        setError]        = useState(null);
  const [regenerating, setRegenerating] = useState(false);
  const reqRef = useRef(0);

  const run = useCallback(async (forceRefresh = false) => {
    if (!clientId || !storyId) return;
    const id = ++reqRef.current;
    forceRefresh ? setRegenerating(true) : setLoading(true);
    setError(null);
    try {
      const result = await fetchAiAnalysis(clientId, storyId, forceRefresh);
      if (id === reqRef.current) setAnalysis(result);
    } catch (e) {
      if (id === reqRef.current) setError(e.message);
    } finally {
      if (id === reqRef.current) { setLoading(false); setRegenerating(false); }
    }
  }, [clientId, storyId]);

  useEffect(() => { setAnalysis(null); setError(null); run(false); }, [run]);
  return { analysis, loading, error, regenerating, regenerate: () => run(true) };
}

// ─────────────────────────────────────────────────────────────
// SKELETON
// ─────────────────────────────────────────────────────────────
function Skel({ width = "100%", height = 13, mb = 9 }) {
  return <div className="av-skeleton" style={{ width, height, marginBottom: mb }} />;
}

// ─────────────────────────────────────────────────────────────
// METRIC TILE
// ─────────────────────────────────────────────────────────────
function MetricTile({ m }) {
  const bad  = m.dir === "bad";
  const good = m.dir === "good";
  const arrow    = bad ? "↑" : good ? "↓" : "→";
  const deltaClr = bad ? "var(--red)" : good ? "var(--green)" : "var(--amber)";
  return (
    <div className="av-metric-tile">
      <div className="av-metric-bar" style={{ background: bad ? "var(--red)" : good ? "var(--green)" : "var(--amber)" }} />
      <div className="av-metric-label">{m.label}</div>
      <div className="av-metric-value">{m.value}</div>
      {m.delta && (
        <div className="av-metric-delta" style={{ color: deltaClr }}>
          {m.dir !== "neutral" ? `${arrow} ${m.delta}` : m.delta}
        </div>
      )}
      {m.bench && (
        <div className="av-metric-bench">{m.benchLabel || "Industry"}: {m.bench}</div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CUSTOM TOOLTIP (shared)
// ─────────────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label, currency = true }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="av-tooltip">
      <div className="av-tooltip-label">{label}</div>
      {payload.map((p, i) => (
        <div key={i} className="av-tooltip-row">
          <span className="av-tooltip-dot" style={{ background: p.color }} />
          <span>{p.name}: <strong>{currency ? fmtK(p.value) : p.value?.toLocaleString()}</strong></span>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Monthly PMPM Line (Cost Trend, Utilization)
// ─────────────────────────────────────────────────────────────
function MonthlyCostChart({ analytics, color = "#000f47" }) {
  const mc = analytics?.monthlyChart;
  const hasReal = mc?.labels?.length > 0;

  const data = hasReal
    ? mc.labels.map((l, i) => ({ period: l, PMPM: mc.pmpm?.[i] ?? 0 }))
    : ["Q1 22","Q2 22","Q3 22","Q4 22","Q1 23","Q2 23"].map((p, i) => ({
        period: p, PMPM: 320 + i * 26,
      }));

  return (
    <ResponsiveContainer width="100%" height={190}>
      <LineChart data={data} margin={{ top: 6, right: 10, left: -4, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" vertical={false} />
        <XAxis dataKey="period" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={42}
          tickFormatter={fmtK} />
        <Tooltip content={<ChartTooltip />} />
        <Line type="monotone" dataKey="PMPM" stroke={color} strokeWidth={2.5}
          dot={{ r: 4, fill: "#fff", stroke: color, strokeWidth: 2 }} activeDot={{ r: 6 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Horizontal Bar (Top Diagnoses)
// ─────────────────────────────────────────────────────────────
function DiagnosisBarChart({ analytics }) {
  const dc = analytics?.diagnosisChart;
  const hasReal = dc?.labels?.length > 0;

  const data = hasReal
    ? dc.labels.map((l, i) => ({ name: l.length > 18 ? l.slice(0, 18) + "…" : l, cost: dc.costs?.[i] ?? 0, count: dc.counts?.[i] ?? 0 }))
    : [
        { name: "Digestive",      cost: 450000, count: 312 },
        { name: "Respiratory",    cost: 380000, count: 201 },
        { name: "Musculoskeletal",cost: 290000, count: 178 },
        { name: "Cardiovascular", cost: 220000, count: 98  },
        { name: "Nervous",        cost: 180000, count: 87  },
      ];

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" horizontal={false} />
        <XAxis type="number" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false}
          tickFormatter={fmtK} />
        <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: "#333" }} axisLine={false}
          tickLine={false} width={110} />
        <Tooltip content={<ChartTooltip />} />
        <Bar dataKey="cost" radius={[0, 4, 4, 0]}>
          {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Claim Type Donut (Cost Trend, Plan Perf)
// ─────────────────────────────────────────────────────────────
function ClaimTypeDonut({ analytics }) {
  const ctc = analytics?.claimTypeCosts || {};
  const entries = Object.entries(ctc).sort((a, b) => b[1] - a[1]);
  const hasReal = entries.length > 0;

  const data = hasReal
    ? entries.map(([name, value]) => ({ name, value: Math.round(value) }))
    : [
        { name: "Dental", value: 45 },
        { name: "Medical", value: 38 },
        { name: "Optical", value: 10 },
        { name: "Maternity", value: 7 },
      ];

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
      <ResponsiveContainer width={160} height={160}>
        <PieChart>
          <Pie data={data} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={68}
            paddingAngle={2}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Pie>
          <Tooltip formatter={(v) => [fmtK(v), ""]} />
        </PieChart>
      </ResponsiveContainer>
      <div style={{ flex: 1, fontSize: 12 }}>
        {data.slice(0, 5).map((d, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: CHART_COLORS[i % CHART_COLORS.length], flexShrink: 0 }} />
            <span style={{ flex: 1, color: "#444", fontWeight: 500 }}>{d.name}</span>
            <span style={{ color: "#888" }}>{total ? ((d.value / total) * 100).toFixed(1) : 0}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Member Cost Distribution (High-Cost)
// ─────────────────────────────────────────────────────────────
function MemberCostBandChart({ analytics }) {
  const bands = analytics?.memberCostBands || {};
  const hasReal = Object.keys(bands).length > 0;

  const data = hasReal
    ? Object.entries(bands).map(([name, count]) => ({ name, count }))
    : [
        { name: "Below ₱50k",   count: 520 },
        { name: "₱50k–100k",    count: 180 },
        { name: "₱100k–200k",   count: 95  },
        { name: "₱200k–400k",   count: 42  },
        { name: "₱400k+ (MBL)", count: 8   },
      ];

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={data} margin={{ top: 4, right: 10, left: -4, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#888" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={34} />
        <Tooltip content={<ChartTooltip currency={false} />} />
        <Bar dataKey="count" radius={[4, 4, 0, 0]}>
          {data.map((d, i) => (
            <Cell key={i} fill={i === data.length - 1 ? "#b83020" : i >= data.length - 2 ? "#c87e00" : "#000f47"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Age Group Bar (Census)
// ─────────────────────────────────────────────────────────────
function AgeGroupChart({ analytics }) {
  const ag = analytics?.ageGroups || {};
  const hasReal = Object.keys(ag).length > 0;

  const data = hasReal
    ? Object.entries(ag).map(([name, count]) => ({ name, count }))
    : [
        { name: "0-20",   count: 12  },
        { name: "21-30",  count: 145 },
        { name: "31-35",  count: 310 },
        { name: "36-40",  count: 280 },
        { name: "41-50",  count: 198 },
        { name: "51-60",  count: 87  },
        { name: "61+",    count: 22  },
      ];

  return (
    <ResponsiveContainer width="100%" height={170}>
      <BarChart data={data} margin={{ top: 4, right: 10, left: -4, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={34} />
        <Tooltip content={<ChartTooltip currency={false} />} />
        <Bar dataKey="count" fill="#000f47" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Plan Level PMPM (Plan Performance)
// ─────────────────────────────────────────────────────────────
function PlanLevelChart({ analytics }) {
  const plpm = analytics?.planLevelPmpm || {};
  const plc  = analytics?.planLevelCounts || {};
  const hasReal = Object.keys(plpm).length > 0;

  const data = hasReal
    ? Object.entries(plpm).sort((a, b) => b[1] - a[1]).map(([plan, pmpm]) => ({
        name: plan.length > 20 ? plan.slice(0, 20) + "…" : plan,
        pmpm,
        members: plc[plan] || 0,
      }))
    : [
        { name: "Platinum 3", pmpm: 1450, members: 320 },
        { name: "Basic",      pmpm: 850,  members: 580 },
        { name: "Staff",      pmpm: 620,  members: 210 },
      ];

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={data} margin={{ top: 4, right: 10, left: -4, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={48}
          tickFormatter={fmtK} />
        <Tooltip content={<ChartTooltip />} />
        <Bar dataKey="pmpm" radius={[4, 4, 0, 0]}>
          {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Quarterly Cost Bar (Utilization / Plan Perf)
// ─────────────────────────────────────────────────────────────
function QuarterChart({ analytics }) {
  const qc = analytics?.quarterChart;
  const hasReal = qc?.labels?.length > 0;

  const data = hasReal
    ? qc.labels.map((l, i) => ({ name: l, cost: qc.costs?.[i] ?? 0, claims: qc.counts?.[i] ?? 0 }))
    : [
        { name: "Q1", cost: 320000, claims: 245 },
        { name: "Q2", cost: 290000, claims: 218 },
        { name: "Q3", cost: 410000, claims: 312 },
        { name: "Q4", cost: 380000, claims: 287 },
      ];

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={data} margin={{ top: 4, right: 10, left: -4, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 4" stroke="#e4e4ec" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#888" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={48}
          tickFormatter={fmtK} />
        <Tooltip content={<ChartTooltip />} />
        <Bar dataKey="cost" radius={[4, 4, 0, 0]}>
          {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ─────────────────────────────────────────────────────────────
// STORY CHART SELECTOR
// Returns the right chart component based on storyId + analytics
// ─────────────────────────────────────────────────────────────
function StoryChart({ storyId, analytics, color }) {
  switch (storyId) {
    case "cost_trend":
      return (
        <div>
          <div className="av-chart-sublabel">Monthly PMPM Trend (₱ per member per month)</div>
          <MonthlyCostChart analytics={analytics} color={color} />
          <div style={{ marginTop: 16 }}>
            <div className="av-chart-sublabel">Claim Type Breakdown</div>
            <ClaimTypeDonut analytics={analytics} />
          </div>
        </div>
      );
    case "top5_diagnosis":
      return (
        <div>
          <div className="av-chart-sublabel">Top Illness Groups by Approved Cost (₱)</div>
          <DiagnosisBarChart analytics={analytics} />
        </div>
      );
    case "high_cost":
      return (
        <div>
          <div className="av-chart-sublabel">Member Cost Distribution</div>
          <MemberCostBandChart analytics={analytics} />
          <div style={{ marginTop: 14 }}>
            <div className="av-chart-sublabel">Monthly PMPM</div>
            <MonthlyCostChart analytics={analytics} color="#b83020" />
          </div>
        </div>
      );
    case "census_analysis":
      return (
        <div>
          <div className="av-chart-sublabel">Age Group Distribution</div>
          <AgeGroupChart analytics={analytics} />
          <div style={{ marginTop: 14 }}>
            <div className="av-chart-sublabel">Gender Split</div>
            <GenderDonut analytics={analytics} />
          </div>
        </div>
      );
    case "utilization":
      return (
        <div>
          <div className="av-chart-sublabel">Quarterly Claim Spend (₱)</div>
          <QuarterChart analytics={analytics} />
          <div style={{ marginTop: 14 }}>
            <div className="av-chart-sublabel">Facility Type Breakdown</div>
            <FacilityDonut analytics={analytics} />
          </div>
        </div>
      );
    case "plan_perf":
      return (
        <div>
          <div className="av-chart-sublabel">PMPM by Plan Level (₱)</div>
          <PlanLevelChart analytics={analytics} />
          <div style={{ marginTop: 14 }}>
            <div className="av-chart-sublabel">Claim Type Split</div>
            <ClaimTypeDonut analytics={analytics} />
          </div>
        </div>
      );
    default:
      return <MonthlyCostChart analytics={analytics} color={color} />;
  }
}

// ─────────────────────────────────────────────────────────────
// CHART: Gender Donut (Census)
// ─────────────────────────────────────────────────────────────
function GenderDonut({ analytics }) {
  const gc = analytics?.genderCounts || {};
  const entries = Object.entries(gc).filter(([, v]) => v > 0);
  const data = entries.length > 0
    ? entries.map(([name, value]) => ({ name, value }))
    : [{ name: "Male", value: 55 }, { name: "Female", value: 45 }];
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
      <ResponsiveContainer width={130} height={130}>
        <PieChart>
          <Pie data={data} dataKey="value" cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={3}>
            {data.map((_, i) => <Cell key={i} fill={["#000f47", "#c8830a", "#2a6832", "#b83020"][i % 4]} />)}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div style={{ fontSize: 12 }}>
        {data.map((d, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: ["#000f47","#c8830a","#2a6832","#b83020"][i % 4], flexShrink: 0 }} />
            <span style={{ color: "#444", fontWeight: 500 }}>{d.name}</span>
            <span style={{ color: "#888", marginLeft: 4 }}>{total ? ((d.value / total) * 100).toFixed(1) : 0}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CHART: Facility Donut (Utilization)
// ─────────────────────────────────────────────────────────────
function FacilityDonut({ analytics }) {
  const fc = analytics?.facilityTypeCounts || {};
  const entries = Object.entries(fc).sort((a, b) => b[1] - a[1]);
  const data = entries.length > 0
    ? entries.map(([name, value]) => ({ name, value }))
    : [{ name: "Clinic", value: 65 }, { name: "Hospital", value: 28 }, { name: "Other", value: 7 }];
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
      <ResponsiveContainer width={130} height={130}>
        <PieChart>
          <Pie data={data} dataKey="value" cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={3}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div style={{ fontSize: 12 }}>
        {data.slice(0, 5).map((d, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: CHART_COLORS[i % CHART_COLORS.length], flexShrink: 0 }} />
            <span style={{ color: "#444", fontWeight: 500 }}>{d.name}</span>
            <span style={{ color: "#888", marginLeft: 4 }}>{total ? ((d.value / total) * 100).toFixed(1) : 0}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ANALYTICS SUMMARY STRIP
// Shows 4 live KPIs from real data at top of Analysis view
// ─────────────────────────────────────────────────────────────
function AnalyticsSummaryStrip({ client, storyId }) {
  const a = client?.analytics;
  if (!a) return null;

  const getKpis = () => {
    switch (storyId) {
      case "cost_trend":
        return [
          { label: "Total Approved", value: fmt(a.totalApproved), sub: "all claims" },
          { label: "PMPM",           value: fmt(a.pmpm),          sub: "per member/month" },
          { label: "YoY Trend",      value: `${a.trendPct > 0 ? "+" : ""}${a.trendPct}%`, sub: "vs prior year", bad: a.trendPct > 0 },
          { label: "Total Claims",   value: (a.totalClaims||0).toLocaleString(), sub: "claim count" },
        ];
      case "top5_diagnosis":
        return [
          { label: "Top Group",      value: a.top5Diagnoses?.[0]?.name || "—",     sub: "highest cost" },
          { label: "Top Group Cost", value: fmt(a.top5Diagnoses?.[0]?.cost || 0),  sub: "approved" },
          { label: "Top Group %",    value: `${a.top5Diagnoses?.[0]?.pct || 0}%`,  sub: "of all claims" },
          { label: "Illness Groups", value: Object.keys(a.illnessCostMap || {}).length, sub: "distinct groups" },
        ];
      case "high_cost":
        return [
          { label: "High-Cost Members", value: a.highCostMembers,              sub: "≥50% of MBL" },
          { label: "% of Members",      value: `${a.highCostPct}%`,            sub: "high-cost rate", bad: a.highCostPct > 5 },
          { label: "Top Member Cost",   value: fmt(a.topMemberCost),           sub: "single member" },
          { label: "MBL",               value: fmt(a.mbl),                     sub: "max benefit limit" },
        ];
      case "census_analysis":
        return [
          { label: "Avg Age",         value: `${a.avgAge} yrs`,      sub: "across members" },
          { label: "Dep. Ratio",      value: `${a.dependentRatio}:1`, sub: "dep per employee" },
          { label: "Female %",        value: `${a.femalePct}%`,      sub: "gender split" },
          { label: "Unique Members",  value: client.members.toLocaleString(), sub: "active" },
        ];
      case "utilization":
        return [
          { label: "Claims/Member",   value: a.claimsPerMember,     sub: "utilisation rate", bad: a.claimsPerMember > 5 },
          { label: "Clinic Claims",   value: (a.facilityTypeCounts?.["Clinic"] || 0).toLocaleString(), sub: "outpatient" },
          { label: "Hospital Claims", value: (a.facilityTypeCounts?.["Hospital"] || 0).toLocaleString(), sub: "inpatient" },
          { label: "Chronic %",       value: `${a.chronicPct}%`,    sub: "chronic illness", bad: a.chronicPct > 30 },
        ];
      case "plan_perf":
        return [
          { label: "Billed/Approved", value: `${a.billedApprovedRatio}%`, sub: "approval rate" },
          { label: "Total Billed",    value: fmt(a.totalBilled),  sub: "before approval" },
          { label: "Total Approved",  value: fmt(a.totalApproved), sub: "net approved" },
          { label: "Plan Levels",     value: Object.keys(a.planLevelCounts || {}).length, sub: "distinct plans" },
        ];
      default:
        return [
          { label: "Total Approved", value: fmt(a.totalApproved) },
          { label: "PMPM",           value: fmt(a.pmpm) },
          { label: "Members",        value: client.members.toLocaleString() },
          { label: "YoY Trend",      value: `${a.trendPct > 0 ? "+" : ""}${a.trendPct}%` },
        ];
    }
  };

  const kpis = getKpis();

  return (
    <div className="av-summary-strip">
      {kpis.map((k, i) => (
        <div key={i} className="av-summary-kpi">
          <div className="av-summary-label">{k.label}</div>
          <div className={`av-summary-value ${k.bad ? "av-summary-bad" : ""}`}>{k.value}</div>
          {k.sub && <div className="av-summary-sub">{k.sub}</div>}
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TALKING POINTS
// ─────────────────────────────────────────────────────────────
function TalkingPoints({ points = [], onExport }) {
  const [checked,  setChecked]  = useState({});
  const [custom,   setCustom]   = useState([]);
  const [note,     setNote]     = useState("");
  const [addedMsg, setAddedMsg] = useState(false);
  const [exported, setExported] = useState(false);
  const inputRef = useRef(null);

  const allPoints   = [...points, ...custom];
  const numSelected = Object.values(checked).filter(Boolean).length;
  const toggle = (i) => setChecked(p => ({ ...p, [i]: !p[i] }));

  const addNote = () => {
    const text = note.trim();
    if (!text) return;
    const idx = allPoints.length;
    setCustom(c => [...c, text]);
    setChecked(p => ({ ...p, [idx]: true }));
    setNote("");
    setAddedMsg(true);
    setTimeout(() => { setAddedMsg(false); inputRef.current?.focus(); }, 1800);
  };

  const handleExport = () => {
    setExported(true);
    const selected = allPoints.filter((_, i) => checked[i]);
    onExport?.(selected);
    setTimeout(() => setExported(false), 2500);
  };

  return (
    <div className="av-tp-card">
      <div className="av-tp-head">
        <span className="av-tp-title">TALKING POINTS</span>
        <span className="av-tp-hint">
          {numSelected > 0 ? `${numSelected} selected` : "Click to select"}
        </span>
      </div>
      <div className="av-tp-divider" />

      {allPoints.length === 0 && (
        <div className="av-tp-empty">AI is generating talking points — or add your own below.</div>
      )}
      {allPoints.map((pt, i) => (
        <div key={i} className={`av-tp-row ${checked[i] ? "av-tp-row-on" : ""}`} onClick={() => toggle(i)}>
          <div className={`av-tp-box ${checked[i] ? "av-tp-box-on" : ""}`}>
            {checked[i] && (
              <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
                <path d="M1 3.5L3.5 6L8 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </div>
          <span className="av-tp-text">
            {pt}
            {i >= points.length && <span className="av-tp-badge">custom</span>}
          </span>
        </div>
      ))}

      <div className="av-add-section">
        <div className="av-add-label">ADD YOUR OWN</div>
        <div className="av-add-row">
          <input
            ref={inputRef}
            className="av-add-input"
            value={note}
            onChange={e => setNote(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addNote()}
            placeholder="Add a talking point specific to this client…"
          />
          <button className={`av-add-btn ${addedMsg ? "av-add-btn-ok" : ""}`} onClick={addNote}>
            {addedMsg ? "✓ Added" : "Add"}
          </button>
        </div>
      </div>

      <div className="av-export-row">
        <span className="av-export-note">
          {numSelected > 0
            ? `${numSelected} point${numSelected > 1 ? "s" : ""} selected for export`
            : "Select talking points to include in your slide deck"}
        </span>
        <button className={`av-export-btn ${exported ? "av-export-btn-done" : ""}`} onClick={handleExport}>
          {exported ? "✓ Exported to PowerPoint" : "Export to PowerPoint →"}
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ANALYSIS VIEW — main export
// ─────────────────────────────────────────────────────────────
export default function AnalysisView({
  client, clients, storyId, narratives, stories, reloading,
  onBack, onClientChange, onReload, onLogoClick,
}) {
  const xlsxN  = narratives?.[storyId];
  const tmpl   = stories?.find(s => s.id === storyId);
  const { analysis, loading, error, regenerating, regenerate } = useAiAnalysis(client?.id, storyId);

  if (!client) return null;

  const isBusy = loading || regenerating;
  const analytics = client.analytics || null;

  const headline = analysis?.headline      || xlsxN?.headline || "";
  const insight  = analysis?.insight       || xlsxN?.insight  || "";
  const soWhat   = analysis?.so_what       || xlsxN?.so_what  || "";
  const tpPoints = analysis?.talking_points?.length
    ? analysis.talking_points : (xlsxN?.talking_points || []);
  const metrics  = analysis?.ai_metrics?.length
    ? analysis.ai_metrics : (xlsxN?.metrics || []);

  const storyLabel = tmpl?.label || storyId.replace(/_/g, " ");
  const storyIcon  = tmpl?.icon  || "📊";
  const chartColor = "#000f47";

  return (
    <div className="screen-shell">
      <NavBar
        client={client} clients={clients} reloading={reloading}
        onClientChange={onClientChange} onReload={onReload} onLogoClick={onLogoClick}
      />

      <div className="av-content anim-fade-up">

        {/* ── Breadcrumb ──────────────────────────────── */}
        <div className="av-breadcrumb">
          <button className="av-bc-btn" onClick={onBack}>← Client Prep</button>
          <span className="av-bc-sep">/</span>
          <span className="av-bc-item">{client.name}</span>
          <span className="av-bc-sep">/</span>
          <span className="av-bc-active">{storyLabel}</span>
        </div>

        {/* ── Story Tag ───────────────────────────────── */}
        <div className="av-story-tag">
          <span>{storyIcon}</span>
          <span className="av-story-tag-name">{storyLabel.toUpperCase()}</span>
          <span className="av-story-tag-sep">·</span>
          <span className="av-story-tag-client">{client.name.toUpperCase()}</span>
          {isBusy && <span className="av-ai-pill">⟳ AI generating…</span>}
          {analytics && <span className="av-data-pill">📊 Live Data</span>}
        </div>

        {/* ── Live KPI Summary Strip ───────────────────── */}
        {analytics && <AnalyticsSummaryStrip client={client} storyId={storyId} />}

        {/* ── Headline ────────────────────────────────── */}
        <div className="av-headline-wrap">
          {error ? (
            <div className="av-error-box">
              <span className="av-error-icon">⚠</span>
              <div>
                <div className="av-error-title">AI unavailable</div>
                <div className="av-error-body">{error}</div>
              </div>
              <button className="av-error-retry" onClick={regenerate}>↺ Retry</button>
            </div>
          ) : loading ? (
            <div><Skel width="86%" height={26} mb={10} /><Skel width="58%" height={26} mb={0} /></div>
          ) : (
            <div className="av-headline">"{headline}"</div>
          )}
          <button
            className={`av-regen-btn ${regenerating ? "spinning" : ""}`}
            onClick={regenerate}
            disabled={isBusy}
          >
            {regenerating ? "⟳ Regenerating…" : "⟳ Regenerate"}
          </button>
        </div>

        <div className="av-divider" />

        {/* ── Metric Tiles ────────────────────────────── */}
        <div className="av-metrics-grid">
          {loading
            ? [0,1,2,3].map(i => (
                <div key={i} className="av-metric-tile">
                  <div className="av-metric-bar" style={{ background: "var(--border)" }} />
                  <Skel width="55%" height={9} mb={10} />
                  <Skel width="45%" height={26} mb={8} />
                  <Skel width="38%" height={9} mb={6} />
                  <Skel width="52%" height={9} mb={0} />
                </div>
              ))
            : metrics.length > 0
              ? metrics.map((m, i) => <MetricTile key={i} m={m} />)
              : null
          }
        </div>

        {/* ── Chart + Insight Row ─────────────────────── */}
        <div className="av-main-row">

          {/* Story-specific chart using real analytics data */}
          <div className="av-chart-card">
            <div className="av-card-label">DATA VISUALISATION</div>
            <StoryChart storyId={storyId} analytics={analytics} color={chartColor} />
          </div>

          {/* Right: Insight + Action */}
          <div className="av-right-col">
            <div className="av-insight-card">
              <div className="av-card-label">WHAT'S DRIVING IT</div>
              {loading
                ? <><Skel /><Skel /><Skel width="72%" /></>
                : <p className="av-card-text">{insight || "Generating analysis…"}</p>
              }
            </div>

            <div className="av-action-card">
              <div className="av-card-label av-action-label">SO WHAT / ACTION</div>
              {loading
                ? <><Skel /><Skel /><Skel width="60%" /></>
                : <p className="av-card-text">{soWhat || "Generating recommendations…"}</p>
              }
            </div>
          </div>
        </div>

        {/* ── Talking Points ───────────────────────────── */}
        <TalkingPoints
          points={tpPoints}
          onExport={(pts) => console.log("[export] talking points:", pts)}
        />

        <div style={{ paddingBottom: 48 }}>
          <button className="av-back-btn" onClick={onBack}>← Back to Client Brief</button>
        </div>

      </div>
    </div>
  );
}