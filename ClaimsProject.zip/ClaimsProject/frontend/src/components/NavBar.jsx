export default function NavBar({
  client, clients = [], reloading,
  onClientChange, onReload, onLogoClick,
}) {
  return (
    <nav className="app-navbar">
      <div className="app-navbar-brand" onClick={onLogoClick}>
        <div className="app-logo">B</div>
        <span className="app-logo-name">Brief</span>
        <div className="app-logo-div" />
        <span className="app-logo-sub">Client Intelligence</span>
      </div>

      <div className="app-navbar-right">
        <button
          className={`btn-reload ${reloading ? "reloading" : ""}`}
          onClick={onReload}
          disabled={reloading}
          title="Reload data from Excel"
        >
          {reloading ? "⟳ Reloading…" : "⟳ Reload"}
        </button>

        <span className="navbar-client-label">CLIENT</span>

        <select
          className="navbar-select"
          value={client?.id || ""}
          onChange={e => onClientChange(e.target.value)}
        >
          {clients.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>
    </nav>
  );
}
