import { useState, useMemo, useRef, useEffect } from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell
} from "recharts";

// ── Helpers ───────────────────────────────────────────────────
function riskColor(score) {
  if (score >= 75) return { bg: "#fdf0ee", border: "#f5b8b2", badge: "#b83020", label: "High" };
  if (score >= 50) return { bg: "#fff8e6", border: "#f5d078", badge: "#c87e00", label: "Medium" };
  return               { bg: "#edf5e8", border: "#9dd085", badge: "#2a6832", label: "Low" };
}

// ── Searchable Client Dropdown ────────────────────────────────
function ClientDropdown({ clients, onChange }) {
  const [open,   setOpen]   = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef(null);

  const filtered = useMemo(() =>
    clients.filter(c =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.industry || "").toLowerCase().includes(search.toLowerCase())
    ), [clients, search]);

  useEffect(() => {
    const handler = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div className="client-dropdown" ref={ref}>
      <button className="client-dd-btn" onClick={() => setOpen(o => !o)}>
        Select Client &nbsp;<span className={`dd-arrow ${open ? "open" : ""}`}>▾</span>
      </button>

      {open && (
        <div className="client-dd-menu">
          <div className="client-dd-search-wrap">
            <span style={{ color: "var(--ink-muted)" }}>🔍</span>
            <input
              autoFocus
              className="client-dd-search"
              placeholder="Search name or industry…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="client-dd-list">
            {filtered.length === 0 && (
              <div className="client-dd-empty">No clients found</div>
            )}
            {filtered.map(c => {
              const rc = riskColor(c.riskScore);
              return (
                <div
                  key={c.id}
                  className="client-dd-item"
                  onClick={() => { onChange(c.id); setOpen(false); setSearch(""); }}
                >
                  <div>
                    <div className="client-dd-item-name">{c.name}</div>
                    <div className="client-dd-item-meta">{c.industry} · {c.country}</div>
                  </div>
                  <span className="risk-badge" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
                    {rc.label}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="client-dd-footer">{filtered.length} of {clients.length} clients</div>
        </div>
      )}
    </div>
  );
}

// ── Portfolio Bar Chart ───────────────────────────────────────
function PortfolioChart({ clients }) {
  const data = clients.slice(0, 12).map(c => ({
    name:  c.name.split(" ")[0],
    pmpy:  c.pmpy,
    score: c.riskScore,
  }));

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="chart-tooltip">
        <div className="chart-tooltip-label">{label}</div>
        <div>PMPY: <strong>₱{payload[0]?.value?.toLocaleString()}</strong></div>
      </div>
    );
  };

  return (
    <div className="chart-card">
      <div className="card-label">Portfolio PMPM Overview (₱ per member per month)</div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 4" stroke="#e8e0d4" vertical={false} />
          <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#a08c72" }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: "#a08c72" }} axisLine={false} tickLine={false} width={40}
            tickFormatter={v => `₱${(v/1000).toFixed(0)}k`} />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="pmpy" radius={[4, 4, 0, 0]}>
            {data.map((d, i) => (
              <Cell key={i} fill={d.score >= 75 ? "#b83020" : d.score >= 50 ? "#c87e00" : "#2a6832"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ── High Risk Tile ────────────────────────────────────────────
function HighRiskTile({ client, onClick }) {
  const rc     = riskColor(client.riskScore);
  const trendUp = client.trendPct > 0;
  return (
    <div
      className="risk-tile"
      style={{ borderTop: `3px solid ${rc.badge}` }}
      onClick={() => onClick(client.id)}
    >
      <div className="risk-tile-head">
        <div>
          <div className="risk-tile-name">{client.name}</div>
          <div className="risk-tile-meta">{client.industry} · {client.country}</div>
        </div>
        <span className="risk-badge" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
          Risk {client.riskScore}
        </span>
      </div>
      <div className="risk-tile-kpis">
        <div>
          <div className="kpi-mini-label">PMPY</div>
          <div className="kpi-mini-val">₱{client.pmpy.toLocaleString()}</div>
        </div>
        <div>
          <div className="kpi-mini-label">Trend</div>
          <div className="kpi-mini-val" style={{ color: trendUp ? "#b83020" : "#2a6832" }}>
            {trendUp ? "▲" : "▼"} {Math.abs(client.trendPct)}%
          </div>
        </div>
        <div>
          <div className="kpi-mini-label">Chronic</div>
          <div className="kpi-mini-val">{client.chronicPct}%</div>
        </div>
        <div>
          <div className="kpi-mini-label">Members</div>
          <div className="kpi-mini-val">{client.members.toLocaleString()}</div>
        </div>
        <div>
          <div className="kpi-mini-label">Claims</div>
          <div className="kpi-mini-val">{(client.totalClaims||0).toLocaleString()}</div>
        </div>
      </div>
      <div className="risk-tile-open">Open Brief →</div>
    </div>
  );
}

// ── Landing Page ──────────────────────────────────────────────
export default function LandingPage({ clients, onSelectClient, dataSource = "excel" }) {
  const [showHighRisk,  setShowHighRisk]  = useState(false);
  const [showRenewal,   setShowRenewal]   = useState(false);
  const highRiskRef = useRef(null);

  const highRiskList = clients.filter(c => c.riskScore >= 75);
  const renewalList  = clients.filter(c => c.renewalOverdue === true);

  const handleHighRisk = () => {
    setShowHighRisk(v => !v);
    setShowRenewal(false);
    setTimeout(() => highRiskRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
  };

  return (
    <div className="landing-shell">

      {/* ── Navbar ── */}
      <nav className="landing-navbar">
        <div className="landing-brand">
          <div className="landing-logo">M</div>
          <div>
            <div className="landing-brand-name">MARSH</div>
            <div className="landing-brand-sub">Global Claims Analytics</div>
          </div>
        </div>
        <div className="landing-navbar-right">
          <span className="landing-welcome">Welcome, Account Manager</span>
          <ClientDropdown clients={clients} onChange={onSelectClient} />
          <div className="avatar-badge">AM</div>
        </div>
      </nav>

      {/* ── Hero Band ── */}
      <div className="landing-hero">
        <div>
          <h1 className="landing-hero-title">Portfolio Overview</h1>
          <p className="landing-hero-sub">
            Global Employee Benefits Claims Analytics · {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
          </p>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <div className="live-badge">
            <span className="live-dot" /> Live Data
          </div>
          <div className="live-badge" style={{background: dataSource==="databricks" ? "#e8f0fe" : "#e8f5e8", color: dataSource==="databricks" ? "#1a56db" : "#2a6832", borderColor: dataSource==="databricks" ? "#a8c5fa" : "#9dd085"}}>
            {dataSource === "databricks" ? "⚡ Databricks" : "📊 Excel"}
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      <div className="landing-content">

        {/* KPI Cards */}
        <div className="kpi-row">
          {/* Total Clients */}
          <div className="kpi-card">
            <div className="kpi-card-accent" style={{ background: "var(--navy)" }} />
            <div className="kpi-icon" style={{ background: "rgba(15,36,99,0.08)" }}>🏢</div>
            <div>
              <div className="kpi-value">{clients.length}</div>
              <div className="kpi-label">Total Clients</div>
              <div className="kpi-sub">Under management</div>
            </div>
          </div>

          {/* High Risk */}
          <div className="kpi-card clickable" onClick={handleHighRisk}>
            <div className="kpi-card-accent" style={{ background: "var(--red)" }} />
            <div className="kpi-icon" style={{ background: "rgba(184,48,32,0.08)" }}>🔴</div>
            <div style={{ flex: 1 }}>
              <div className="kpi-value">{highRiskList.length}</div>
              <div className="kpi-label">High Risk Clients</div>
              <div className="kpi-sub">Risk score ≥ 75</div>
            </div>
            <div className="kpi-cta" style={{ color: "var(--red)" }}>
              {showHighRisk ? "Hide ▲" : "View ▼"}
            </div>
          </div>

          {/* Renewal Overdue */}
          <div className="kpi-card clickable" onClick={() => { setShowRenewal(v => !v); setShowHighRisk(false); }}>
            <div className="kpi-card-accent" style={{ background: "var(--amber)" }} />
            <div className="kpi-icon" style={{ background: "rgba(200,128,10,0.08)" }}>⚠️</div>
            <div style={{ flex: 1 }}>
              <div className="kpi-value">{renewalList.length}</div>
              <div className="kpi-label">Renewal Overdue</div>
              <div className="kpi-sub">Past renewal date</div>
            </div>
            <div className="kpi-cta" style={{ color: "var(--amber)" }}>
              {showRenewal ? "Hide ▲" : "View ▼"}
            </div>
          </div>
          {/* Total Claims */}
          <div className="kpi-card">
            <div className="kpi-card-accent" style={{ background: "var(--blue)" }} />
            <div className="kpi-icon" style={{ background: "rgba(0,15,71,0.06)" }}>📋</div>
            <div>
              <div className="kpi-value">{clients.reduce((s,c)=>s+(c.totalClaims||0),0).toLocaleString()}</div>
              <div className="kpi-label">Total Claims</div>
              <div className="kpi-sub">Across all clients</div>
            </div>
          </div>
        </div>

        {/* High Risk Panel */}
        {showHighRisk && (
          <div ref={highRiskRef} className="panel-section anim-fade-up">
            <div className="panel-header">
              <div>
                <div className="panel-title">🔴 High Risk Clients
                  <span className="panel-count">{highRiskList.length} clients</span>
                </div>
                <div className="panel-sub">Risk score ≥ 75 · Click any tile to open client brief</div>
              </div>
              <button className="btn-ghost" onClick={() => setShowHighRisk(false)}>Close ✕</button>
            </div>
            <div className="risk-tiles-grid">
              {highRiskList.map(c => (
                <HighRiskTile key={c.id} client={c} onClick={onSelectClient} />
              ))}
            </div>
          </div>
        )}

        {/* Renewal Overdue Panel */}
        {showRenewal && (
          <div className="panel-section anim-fade-up">
            <div className="panel-header">
              <div>
                <div className="panel-title">⚠️ Renewal Overdue
                  <span className="panel-count">{renewalList.length} clients</span>
                </div>
                <div className="panel-sub">Clients past renewal date</div>
              </div>
              <button className="btn-ghost" onClick={() => setShowRenewal(false)}>Close ✕</button>
            </div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Client</th><th>Industry</th><th>Country</th>
                    <th>Renewal</th><th>Risk</th><th>PMPY</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {renewalList.map(c => {
                    const rc = riskColor(c.riskScore);
                    return (
                      <tr key={c.id} onClick={() => onSelectClient(c.id)}>
                        <td><strong>{c.name}</strong></td>
                        <td>{c.industry}</td>
                        <td>{c.country}</td>
                        <td style={{ color: "var(--red)", fontWeight: 600 }}>⚠ {c.renewalDate}</td>
                        <td>
                          <span className="risk-badge" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
                            {c.riskScore}
                          </span>
                        </td>
                        <td>₱{c.pmpy.toLocaleString()}</td>
                        <td><span className="open-link">Open →</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Portfolio Chart + All Clients Table */}
        <div className="portfolio-bottom">
          <PortfolioChart clients={clients} />

          <div className="chart-card">
            <div className="card-label">All Clients — Portfolio Summary</div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Client</th><th>Country</th><th>Members</th>
                    <th>PMPM (₱)</th><th>Total Claims</th><th>Trend</th><th>Risk</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map(c => {
                    const rc  = riskColor(c.riskScore);
                    const up  = c.trendPct > 0;
                    return (
                      <tr key={c.id} onClick={() => onSelectClient(c.id)}>
                        <td><strong>{c.name}</strong></td>
                        <td>{c.country}</td>
                        <td>{c.members.toLocaleString()}</td>
                        <td>₱{(c.pmpm||0).toLocaleString()}</td>
                        <td>{(c.totalClaims||0).toLocaleString()}</td>
                        <td style={{ color: up ? "var(--red)" : "var(--green)", fontWeight: 600 }}>
                          {up ? "▲" : "▼"} {Math.abs(c.trendPct)}%
                        </td>
                        <td>
                          <span className="risk-badge" style={{ background: rc.bg, color: rc.badge, border: `1px solid ${rc.border}` }}>
                            {rc.label}
                          </span>
                        </td>
                        <td><span className="open-link">Open →</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}