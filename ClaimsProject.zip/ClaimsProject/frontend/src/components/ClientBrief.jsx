import NavBar from "./NavBar";

// ── Analytics formatter ───────────────────────────────────────
const fmt = (n) => `₱${Number(n||0).toLocaleString()}`;

// ── Story definitions ─────────────────────────────────────────
// premium: true  → only clickable for premium users
// premium: false → always clickable for all users
const DEFAULT_STORIES = [
  {
    id:      "cost_trend",
    icon:    "📈",
    label:   "Cost Trend",
    desc:    "How costs moved vs prior year and benchmark",
    premium: false,
  },
  {
    id:      "top5_diagnosis",
    icon:    "🩺",
    label:   "Top 5 Diagnosis",
    desc:    "Leading diagnosis categories driving claim spend",
    premium: false,
  },
  {
    id:      "high_cost",
    icon:    "🔴",
    label:   "High-Cost Claimants",
    desc:    "Top cost drivers and impact on total spend",
    premium: false,
  },
  {
    id:      "census_analysis",
    icon:    "📊",
    label:   "Census Analysis",
    desc:    "Member demographics, age bands and dependency trends",
    premium: false,
  },
  {
    id:      "utilization",
    icon:    "🏥",
    label:   "Utilization Shifts",
    desc:    "ER, inpatient, and preventive care patterns",
    premium: true,   // 🔒 Premium only
  },
  {
    id:      "plan_perf",
    icon:    "⚖️",
    label:   "Plan Performance",
    desc:    "HDHP vs PPO enrollment, OOP, and engagement",
    premium: true,   // 🔒 Premium only
  },
];

// ── Premium tier check ────────────────────────────────────────
// Replace this logic with your real auth/subscription check.
// For now: pass isPremium as a prop, or hard-code false to test locked state.
const DEFAULT_IS_PREMIUM = false;

// ── Live Analytics Summary Strip ─────────────────────────────
function AnalyticsStrip({ client }) {
  const a = client?.analytics;
  if (!a) return null;
  return (
    <div className="cb-analytics-strip">
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">TOTAL CLAIMS</div>
        <div className="cb-ak-value">{(a.totalClaims||0).toLocaleString()}</div>
      </div>
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">TOTAL APPROVED</div>
        <div className="cb-ak-value">{fmt(a.totalApproved)}</div>
      </div>
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">PMPM</div>
        <div className="cb-ak-value">{fmt(a.pmpm)}</div>
      </div>
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">YoY TREND</div>
        <div className={`cb-ak-value ${a.trendPct > 0 ? "cb-ak-bad" : "cb-ak-good"}`}>
          {a.trendPct > 0 ? "▲" : "▼"} {Math.abs(a.trendPct)}%
        </div>
      </div>
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">AVG AGE</div>
        <div className="cb-ak-value">{a.avgAge} yrs</div>
      </div>
      <div className="cb-analytics-kpi">
        <div className="cb-ak-label">TOP DIAGNOSIS</div>
        <div className="cb-ak-value cb-ak-diagnosis">{a.top5Diagnoses?.[0]?.name || "—"}</div>
      </div>
    </div>
  );
}

export default function ClientBrief({
  client, clients, stories, narratives, reloading,
  onSelectStory, onClientChange, onReload, onLogoClick,
  isPremium = DEFAULT_IS_PREMIUM,
}) {
  if (!client) {
    return (
      <div className="loading-screen">
        <div style={{ fontSize: 44 }}>📋</div>
        <p style={{ fontSize: 18, fontWeight: 700, color: "var(--ink)" }}>No client selected</p>
        <p style={{ color: "var(--ink-muted)" }}>Select a client from the dropdown above</p>
      </div>
    );
  }

  // Merge xlsx story list with defaults — xlsx takes priority if present
  const storyList = (Array.isArray(stories) && stories.length > 0)
    ? stories
    : DEFAULT_STORIES;

  const hasMeeting = client.meetingDate && String(client.meetingDate).trim();
  const hasManager = client.manager     && String(client.manager).trim();

  return (
    <div className="screen-shell">
      <NavBar
        client={client} clients={clients} reloading={reloading}
        onClientChange={onClientChange} onReload={onReload} onLogoClick={onLogoClick}
      />

      <div className="screen-content anim-fade-up">

        {/* ════════════════════════════════════════════
            CLIENT HEADER
        ════════════════════════════════════════════ */}
        <div className="cb-header-row">
          <div className="cb-header-left">
            <div className="cb-eyebrow">
              <span className="cb-eyebrow-bar" />
              CLIENT BRIEF
            </div>
            <h1 className="cb-client-name">{client.name}</h1>
            <p className="cb-client-meta">
              {client.members?.toLocaleString()} members
              {client.industry ? ` · ${client.industry}` : ""}
              {client.country  ? ` · ${client.country}`  : ""}
            </p>
          </div>

          {(hasMeeting || hasManager) && (
            <div className="cb-meeting-badge">
              <div className="cb-meeting-label">NEXT MEETING</div>
              {hasMeeting && <div className="cb-meeting-date">{client.meetingDate}</div>}
              {hasManager && <div className="cb-meeting-with">with {client.manager}</div>}
            </div>
          )}
        </div>

        <div className="cb-divider" />

        {/* ── Live Analytics Summary ──────────────── */}
        <AnalyticsStrip client={client} />

        {/* ════════════════════════════════════════════
            SECTION HEADER — label + premium badge
        ════════════════════════════════════════════ */}
        <div className="cb-stories-head">
          <span className="cb-section-label">CHOOSE A STORY TO BUILD</span>
          {!isPremium && (
            <span className="cb-premium-notice">
              🔒 Some stories require a Premium plan
            </span>
          )}
        </div>

        {/* ════════════════════════════════════════════
            STORY GRID
        ════════════════════════════════════════════ */}
        <div className="cb-story-grid">
          {storyList.map((t, idx) => {
            // A card is locked when the story requires premium AND user is not premium
            const isLocked   = t.premium && !isPremium;
            // hasXlsxData only changes the CTA label
            const hasXlsxData = !!narratives?.[t.id];

            return (
              <div
                key={t.id}
                className={`cb-story-card ${isLocked ? "cb-story-locked" : "cb-story-active"}`}
                style={{ animationDelay: `${idx * 0.04}s` }}
                onClick={() => !isLocked && onSelectStory(t.id)}
                title={isLocked ? "Upgrade to Premium to unlock this story" : ""}
              >
                {/* Top accent bar — gold for active, muted for locked */}
                <div className={`cb-card-topbar ${isLocked ? "cb-card-topbar-locked" : "cb-card-topbar-active"}`} />

                {/* Icon row — lock badge overlaid for premium cards */}
                <div className="cb-icon-row">
                  <span className="cb-story-icon">{t.icon || "📊"}</span>
                  {isLocked && (
                    <span className="cb-lock-badge" title="Premium feature">
                      🔒
                    </span>
                  )}
                  {t.premium && isPremium && (
                    <span className="cb-premium-badge">PREMIUM</span>
                  )}
                </div>

                {/* Label + description */}
                <div className={`cb-story-title ${isLocked ? "cb-story-title-locked" : ""}`}>
                  {t.label}
                </div>
                <div className="cb-story-desc">{t.desc}</div>

                {/* Footer */}
                <div className="cb-story-footer">
                  {isLocked ? (
                    <span className="cb-story-upgrade">Upgrade to unlock →</span>
                  ) : (
                    <span className="cb-story-cta">
                      {hasXlsxData ? "Build →" : "AI Brief →"}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Fallback raw data table when no narratives at all */}
        {storyList === DEFAULT_STORIES && Object.keys(narratives || {}).length === 0 && (
          <div style={{ marginTop: 32 }}>
            <div className="cb-section-label">CLIENT DATA FROM EXCEL</div>
            <div className="raw-data-card">
              <table className="data-table">
                <thead><tr><th>Field</th><th>Value</th></tr></thead>
                <tbody>
                  {Object.entries(client)
                    .filter(([k]) => !["id"].includes(k))
                    .map(([k, v]) => (
                      <tr key={k}>
                        <td style={{ fontWeight: 600, textTransform: "capitalize", color: "var(--navy)" }}>
                          {k.replace(/_/g, " ")}
                        </td>
                        <td>{v !== null && v !== undefined ? String(v) : "—"}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}