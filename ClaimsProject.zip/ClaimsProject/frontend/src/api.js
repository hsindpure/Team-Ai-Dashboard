/**
 * api.js — All backend fetch calls
 */

const BASE = "/api";

async function apiFetch(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || body.hint || `HTTP ${res.status}`);
  }
  return res.json();
}

export const fetchAll     = ()  => apiFetch("/all");
export const fetchClients = ()  => apiFetch("/clients").then(r => r.data);
export const fetchSource  = ()  => apiFetch("/source");

export const reloadData         = ()  => apiFetch("/reload",              { method: "POST" });
export const reloadExcel        = ()  => apiFetch("/reload/excel",        { method: "POST" });
export const reloadDatabricks   = ()  => apiFetch("/reload/databricks",   { method: "POST" });
export const testDatabricks     = ()  => apiFetch("/databricks/status");

export const fetchAiAnalysis = (clientId, storyId, forceRefresh = false) =>
  apiFetch("/ai/analyze", {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ clientId, storyId, forceRefresh }),
  }).then(r => r.analysis);