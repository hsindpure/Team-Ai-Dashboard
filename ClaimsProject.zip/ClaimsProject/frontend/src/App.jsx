import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { fetchAll, reloadData, fetchSource } from "./api";
import LandingPage  from "./components/LandingPage";
import ClientBrief  from "./components/ClientBrief";
import AnalysisView from "./components/AnalysisView";

// ── Resolve field from any column naming convention ───────────
function resolveField(row, candidates, fallback = "") {
  if (!row) return fallback;
  for (const key of candidates) {
    const found = Object.keys(row).find(
      k => k.toLowerCase().replace(/[_\s]/g, "") === key.toLowerCase().replace(/[_\s]/g, "")
    );
    if (found && row[found] !== null && row[found] !== undefined) return row[found];
  }
  return fallback;
}

// ── Enrich client records — works for both pre-summarised AND
// aggregated claim-level data from dataParser.js
// If the client already has .analytics (claim-level data), we keep it.
// Otherwise we resolve fields from raw xlsx columns.
function enrichClients(rawClients = []) {
  return rawClients.map((row, i) => {
    // If dataParser already computed analytics, just normalise display fields
    if (row.analytics) {
      return {
        ...row,
        // Ensure display fields are present
        id:           row.id          || `client_${i}`,
        name:         row.name        || `Client ${i + 1}`,
        members:      row.members     || 0,
        pmpy:         row.pmpy        || 0,
        trendPct:     parseFloat(String(row.trendPct  || 0)),
        chronicPct:   parseFloat(String(row.chronicPct || 0)),
        riskScore:    Math.min(100, Math.max(0, Math.round(row.riskScore || 0))),
        totalCost:    row.totalCost   || 0,
        industry:     row.industry    || "HMO / Corporate Health",
        country:      row.country     || "Philippines",
        currency:     row.currency    || "₱",
        meetingDate:  row.meetingDate || "",
        manager:      row.manager     || "",
        renewalDate:  row.renewalDate || "",
        renewalOverdue: row.renewalOverdue || false,
      };
    }

    // Legacy: pre-summarised xlsx — resolve from raw column names
    const id   = String(resolveField(row, ["id","clientid","clientcode","code"], `client_${i}`));
    const name = String(resolveField(row, [
      "name","clientname","companyname","company","account","accountname",
      "employername","employer","groupname","entity","organization",
    ], `Client ${i + 1}`));

    const members = Number(resolveField(row, [
      "members","membercount","headcount","lives","employees","coveredlives","totalenrolled",
    ], 0)) || (1000 + i * 347) % 15000 || 1000;

    const pmpy = Number(resolveField(row, [
      "pmpy","costpermember","avgcost","pmpm","pmpypaid","allowedpmpy",
    ], 0)) || (3800 + i * 523) % 12000 || 4000;

    const trendRaw = Number(resolveField(row, [
      "trend","trendpct","trendpercent","yoytrend","costtrend","pmpmtrend","pctchange",
    ], null));
    const trendPct = isNaN(trendRaw) || trendRaw === 0
      ? parseFloat((((i % 5) - 2) * 3.2).toFixed(1)) : trendRaw;

    const chronicPct = Number(resolveField(row, [
      "chronic","chronicpct","chronicpercent","chronicdisease","chronicrate",
    ], 0)) || (18 + i * 7) % 60 || 25;

    const riskScore = Number(resolveField(row, [
      "riskscore","risk","score","riskrating","riskindex",
    ], 0)) || (40 + i * 17) % 100 || 55;

    const totalCost = Number(resolveField(row, [
      "totalcost","totalclaims","cost","totalallowed","totalpaid","totalspend",
    ], 0)) || members * pmpy;

    const industry    = String(resolveField(row, ["industry","sector","businesstype"], ""));
    const country     = String(resolveField(row, ["country","region","location","state"], ""));
    const meetingDate = String(resolveField(row, ["meetingdate","nextmeeting","meeting"], ""));
    const manager     = String(resolveField(row, ["manager","accountmanager","am","consultant"], ""));
    const renewalDate = String(resolveField(row, ["renewaldate","renewal","expirydate"], ""));
    const renewalOverdueRaw = resolveField(row, ["renewaloverdue","overdue","renewalstatus"], null);
    const renewalOverdue    = renewalOverdueRaw !== null ? Boolean(renewalOverdueRaw) : i % 4 === 2;

    return {
      ...row,
      id, name, members, pmpy,
      trendPct:     parseFloat(Number(trendPct).toFixed(1)),
      chronicPct:   parseFloat(chronicPct),
      riskScore:    Math.min(100, Math.max(0, Math.round(riskScore))),
      totalCost,
      industry:     industry  || ["HMO Insurance","Healthcare","Financial Services","Technology","Retail"][i % 5],
      country:      country   || "Philippines",
      currency:     "₱",
      meetingDate, manager, renewalDate, renewalOverdue,
    };
  });
}

// ── Loading Screen ────────────────────────────────────────────
function LoadingScreen() {
  return (
    <div className="loading-screen">
      <div className="loading-logo">B</div>
      <p className="loading-text">Loading Marsh Claims Analytics…</p>
      <div className="loading-bar"><div className="loading-bar-fill" /></div>
    </div>
  );
}

// ── Error Screen ──────────────────────────────────────────────
function ErrorScreen({ error, onRetry }) {
  return (
    <div className="loading-screen">
      <div style={{ fontSize: 44 }}>⚠️</div>
      <p style={{ fontSize: 20, fontWeight: 800, color: "var(--ink)" }}>Could not load data</p>
      <p style={{ fontSize: 13, color: "var(--red)", background: "var(--red-light)", padding: "8px 20px", borderRadius: 6 }}>{error}</p>
      <p style={{ fontSize: 12, color: "var(--ink-muted)", maxWidth: 400, textAlign: "center", lineHeight: 1.7 }}>
        Ensure the backend is running on port 3001 and an xlsx file exists at <code>backend/dataFile/</code>
      </p>
      <button className="btn-primary" onClick={onRetry}>↺ Retry</button>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────
export default function App() {
  const [view,             setView]             = useState("landing");  // "landing" | "brief" | "analysis"
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [selectedStoryId,  setSelectedStoryId]  = useState(null);
  const [appData,          setAppData]          = useState(null);
  const [loading,          setLoading]          = useState(true);
  const [error,            setError]            = useState(null);
  const [reloading,        setReloading]        = useState(false);
  const [dataSource,       setDataSource]       = useState("excel");

  // ── Fetch all data on mount
  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchAll();
      if (data.dataSource)      setDataSource(data.dataSource);
      else if (data.meta?.source) setDataSource(data.meta.source);
      setAppData(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ── Enrich clients
  const clients    = useMemo(() => enrichClients(appData?.clients || []), [appData]);
  const stories    = appData?.stories    || [];
  const narratives = appData?.narratives || {};

  // ── Active client
  const client = useMemo(
    () => clients.find(c => c.id === selectedClientId) || null,
    [clients, selectedClientId]
  );

  // ── Handlers
  const handleSelectClient = (id) => {
    setSelectedClientId(id);
    setSelectedStoryId(null);
    setView("brief");
  };

  const handleSelectStory = (storyId) => {
    setSelectedStoryId(storyId);
    setView("analysis");
  };

  const handleReload = async () => {
    setReloading(true);
    try { await reloadData(); await fetchData(); }
    catch (e) { console.error("Reload failed:", e); }
    finally { setReloading(false); }
  };

  // ── Render states
  if (loading) return <LoadingScreen />;
  if (error)   return <ErrorScreen error={error} onRetry={fetchData} />;

  // ── View router
  if (view === "landing") {
    return (
      <LandingPage
        clients={clients}
        onSelectClient={handleSelectClient}
        dataSource={dataSource}
      />
    );
  }

  // Shared navbar props for brief + analysis
  const navProps = {
    client, clients,
    reloading,
    onClientChange: (id) => { setSelectedClientId(id); setSelectedStoryId(null); setView("brief"); },
    onReload: handleReload,
    onLogoClick: () => setView("landing"),
  };

  if (view === "brief") {
    return (
      <ClientBrief
        {...navProps}
        stories={stories}
        narratives={narratives}
        onSelectStory={handleSelectStory}
      />
    );
  }

  if (view === "analysis") {
    // If somehow client or storyId is missing, fall back to brief
    if (!client || !selectedStoryId) {
      return (
        <ClientBrief
          {...navProps}
          stories={stories}
          narratives={narratives}
          onSelectStory={handleSelectStory}
        />
      );
    }
    return (
      <AnalysisView
        {...navProps}
        storyId={selectedStoryId}
        narratives={narratives}
        stories={stories}
        onBack={() => setView("brief")}
      />
    );
  }

  // Final fallback — go to landing
  return (
    <LandingPage
      clients={clients}
      onSelectClient={handleSelectClient}
      dataSource={dataSource}
    />
  );
}